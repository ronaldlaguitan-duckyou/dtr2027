-- Migration 0007: Support Weekly Rate and Weekly Paid salary type
DO $$
BEGIN
  ALTER TYPE public.salary_type ADD VALUE IF NOT EXISTS 'WEEKLY';
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

ALTER TABLE public.employees
  ADD COLUMN IF NOT EXISTS weekly_rate numeric(12,2) NOT NULL DEFAULT 0 CHECK (weekly_rate >= 0);

ALTER TABLE public.employee_salary_history
  ADD COLUMN IF NOT EXISTS previous_weekly_rate numeric(12,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS new_weekly_rate numeric(12,2) NOT NULL DEFAULT 0;
