-- 0006_earnings_and_colorful_theme.sql
-- Adds 'colorful' theme option and preset compensation fields (OT 1, OT 2, SIL/SL/VL, PAID, Legal Holiday, Special Holiday)

ALTER TABLE public.company_settings
  DROP CONSTRAINT IF EXISTS company_settings_theme_check;

ALTER TABLE public.company_settings
  ADD CONSTRAINT company_settings_theme_check CHECK (theme IN ('light', 'dark', 'colorful'));

ALTER TABLE public.employees
  ADD COLUMN IF NOT EXISTS ot1_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (ot1_pay >= 0),
  ADD COLUMN IF NOT EXISTS ot2_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (ot2_pay >= 0),
  ADD COLUMN IF NOT EXISTS sil_sl_vl_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (sil_sl_vl_pay >= 0),
  ADD COLUMN IF NOT EXISTS paid_leave_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (paid_leave_pay >= 0),
  ADD COLUMN IF NOT EXISTS legal_holiday_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (legal_holiday_pay >= 0),
  ADD COLUMN IF NOT EXISTS special_holiday_pay numeric(12,2) NOT NULL DEFAULT 0 CHECK (special_holiday_pay >= 0);
