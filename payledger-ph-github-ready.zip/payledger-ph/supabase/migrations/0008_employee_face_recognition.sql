-- Store 128-D face recognition descriptors for employee enrollment & Kiosk verification

ALTER TABLE public.employees
  ADD COLUMN IF NOT EXISTS face_descriptor jsonb,
  ADD COLUMN IF NOT EXISTS face_enrolled_at timestamptz;

CREATE OR REPLACE FUNCTION public.list_enrolled_face_descriptors()
RETURNS jsonb
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    jsonb_agg(
      jsonb_build_object(
        'employee_id', e.id,
        'employee_number', e.employee_number,
        'full_name', e.full_name,
        'position', e.position,
        'department', e.department,
        'photo_url', e.photo_url,
        'face_descriptor', e.face_descriptor
      )
      ORDER BY e.employee_number
    ),
    '[]'::jsonb
  )
  FROM public.employees e
  WHERE e.is_active = true
    AND e.employment_status = 'ACTIVE'
    AND e.face_descriptor IS NOT NULL
    AND jsonb_typeof(e.face_descriptor) = 'array'
    AND jsonb_array_length(e.face_descriptor) = 128;
$$;

REVOKE ALL ON FUNCTION public.list_enrolled_face_descriptors() FROM PUBLIC;
GRANT EXECUTE ON FUNCTION public.list_enrolled_face_descriptors() TO anon, authenticated;
