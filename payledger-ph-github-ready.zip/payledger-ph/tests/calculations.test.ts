import { describe, expect, it } from 'vitest';
import { calculateAttendanceMetrics } from '../src/lib/attendance/calculator';
import { buildManilaTimestamp, deriveWorkDate } from '../src/lib/date/manila';
import { computeEmployeePayroll, DEFAULT_MULTIPLIERS } from '../src/lib/payroll/calculator';
import type { AttendanceRecord, Employee, Holiday, OvertimeRequest, Schedule } from '../src/types/database';

const standardSchedule: Schedule = {
  id: 'sched-1',
  name: 'Standard 8-5',
  time_in: '08:00:00',
  time_out: '17:00:00',
  lunch_break_minutes: 60,
  grace_period_minutes: 0,
  regular_hours: 8,
  is_flexible: false,
  is_overnight: false,
  is_default: true,
};

const overnightSchedule: Schedule = {
  id: 'sched-night',
  name: 'Overnight 10PM-7AM',
  time_in: '22:00:00',
  time_out: '07:00:00',
  lunch_break_minutes: 60,
  grace_period_minutes: 0,
  regular_hours: 8,
  is_flexible: false,
  is_overnight: true,
  is_default: false,
};

const baseEmployee: Employee = {
  id: 'emp-1',
  employee_number: 'EMP-2026-0001',
  full_name: 'Juan Dela Cruz',
  photo_url: null,
  position: 'Technician',
  department: 'Operations',
  contact_number: '09170000001',
  address: 'Manila',
  email: 'juan@company.ph',
  date_hired: '2025-01-01',
  employment_type: 'REGULAR',
  employment_status: 'ACTIVE',
  schedule_id: 'sched-1',
  rest_days: [0], // Sunday
  salary_type: 'DAILY',
  daily_rate: 800,
  hourly_rate: 100,
  monthly_rate: 0,
  overtime_rate: 100,
  meal_allowance: 500,
  transport_allowance: 300,
  other_allowances: 0,
  default_deductions: 200,
  is_active: true,
  deactivated_at: null,
  created_at: '2026-01-01T00:00:00+08:00',
  updated_at: '2026-01-01T00:00:00+08:00',
};

describe('Attendance Rules & Asia/Manila Time Calculations', () => {
  const workDate = '2026-11-16'; // Monday

  it('treats 7:59 AM as Early Arrival (On Time, not automatic OT)', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: standardSchedule,
      actualTimeIn: buildManilaTimestamp(workDate, '07:59:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '17:00:00'),
      restDays: [0],
    });
    expect(res.status).toBe('ON_TIME');
    expect(res.earlyArrivalMinutes).toBe(1);
    expect(res.lateMinutes).toBe(0);
    expect(res.regularHours).toBe(8);
    expect(res.approvedOvertimeHours).toBe(0);
  });

  it('treats 8:00 AM and 5:00 PM as exact On Time with 8 regular hours after 1hr lunch deduction', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: standardSchedule,
      actualTimeIn: buildManilaTimestamp(workDate, '08:00:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '17:00:00'),
      restDays: [0],
    });
    expect(res.status).toBe('ON_TIME');
    expect(res.lateMinutes).toBe(0);
    expect(res.undertimeMinutes).toBe(0);
    expect(res.regularHours).toBe(8);
  });

  it('treats 8:01 AM as Late (1 minute) when grace period is 0', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: standardSchedule,
      actualTimeIn: buildManilaTimestamp(workDate, '08:01:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '17:00:00'),
      restDays: [0],
    });
    expect(res.status).toBe('LATE');
    expect(res.lateMinutes).toBe(1);
  });

  it('respects configured grace period', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: { ...standardSchedule, grace_period_minutes: 10 },
      actualTimeIn: buildManilaTimestamp(workDate, '08:09:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '17:00:00'),
      restDays: [0],
    });
    expect(res.status).toBe('ON_TIME');
    expect(res.lateMinutes).toBe(0);
  });

  it('treats 4:59 PM as Undertime (1 minute)', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: standardSchedule,
      actualTimeIn: buildManilaTimestamp(workDate, '08:00:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '16:59:00'),
      restDays: [0],
    });
    expect(res.undertimeMinutes).toBe(1);
  });

  it('treats 5:01 PM as potential overtime without making it payable until approved', () => {
    const res = calculateAttendanceMetrics({
      workDate,
      schedule: standardSchedule,
      actualTimeIn: buildManilaTimestamp(workDate, '08:00:00'),
      actualTimeOut: buildManilaTimestamp(workDate, '18:00:00'),
      restDays: [0],
      approvedOvertimeHours: 0,
    });
    expect(res.potentialOvertimeHours).toBe(1);
    expect(res.approvedOvertimeHours).toBe(0);
    expect(res.paidHours).toBe(8);
  });

  it('handles overnight shift work-date derivation across midnight', () => {
    const outTimestamp = buildManilaTimestamp('2026-11-17', '07:00:00');
    const derived = deriveWorkDate(outTimestamp, overnightSchedule, true);
    expect(derived).toBe('2026-11-16');

    const res = calculateAttendanceMetrics({
      workDate: '2026-11-16',
      schedule: overnightSchedule,
      actualTimeIn: buildManilaTimestamp('2026-11-16', '22:00:00'),
      actualTimeOut: buildManilaTimestamp('2026-11-17', '07:00:00'),
      restDays: [0],
    });
    expect(res.regularHours).toBe(8);
    expect(res.undertimeMinutes).toBe(0);
  });
});

describe('Holiday, Rest Day & Payroll Computations', () => {
  it('treats Sunday as a working day when employee rest day is Wednesday', () => {
    const wednesdayRestEmp = { ...baseEmployee, rest_days: [3] };
    const sunday = '2026-11-15'; // Sunday
    const att: AttendanceRecord = {
      id: 'att-sun',
      employee_id: wednesdayRestEmp.id,
      work_date: sunday,
      schedule_id: standardSchedule.id,
      scheduled_time_in: buildManilaTimestamp(sunday, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(sunday, '17:00:00'),
      actual_time_in: buildManilaTimestamp(sunday, '08:00:00'),
      actual_time_out: buildManilaTimestamp(sunday, '17:00:00'),
      early_arrival_minutes: 0,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 8,
      actual_hours: 8,
      paid_hours: 8,
      approved_overtime_hours: 0,
      status: 'ON_TIME',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: '',
      updated_at: '',
    };

    const pay = computeEmployeePayroll({
      payrollPeriodId: 'pp-1',
      startDate: sunday,
      endDate: sunday,
      employee: wednesdayRestEmp,
      schedule: standardSchedule,
      attendances: [att],
      overtimeRequests: [],
      leaveRequests: [],
      holidays: [],
      multipliers: DEFAULT_MULTIPLIERS,
    });

    expect(pay.basic_pay).toBe(800);
    expect(pay.rest_day_pay).toBe(0);
  });

  it('computes Regular Holiday + Rest Day + Approved OT accurately', () => {
    const holidayDate = '2026-11-29'; // Sunday
    const holiday: Holiday = {
      id: 'hol-1',
      holiday_date: holidayDate,
      name: 'Special Regular Holiday Test',
      holiday_type: 'REGULAR',
      description: 'Test',
      is_verified: true,
      source: 'MANUAL',
      created_at: '',
    };
    const att: AttendanceRecord = {
      id: 'att-hol',
      employee_id: baseEmployee.id,
      work_date: holidayDate,
      schedule_id: standardSchedule.id,
      scheduled_time_in: buildManilaTimestamp(holidayDate, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(holidayDate, '17:00:00'),
      actual_time_in: buildManilaTimestamp(holidayDate, '08:00:00'),
      actual_time_out: buildManilaTimestamp(holidayDate, '19:00:00'),
      early_arrival_minutes: 0,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 8,
      actual_hours: 10,
      paid_hours: 10,
      approved_overtime_hours: 2,
      status: 'OVERTIME',
      day_classification: 'REGULAR_HOLIDAY_REST_DAY',
      is_rest_day: true,
      holiday_id: holiday.id,
      is_corrected: false,
      notes: null,
      created_at: '',
      updated_at: '',
    };
    const ot: OvertimeRequest = {
      id: 'ot-1',
      attendance_id: att.id,
      employee_id: baseEmployee.id,
      work_date: holidayDate,
      scheduled_time_in: att.scheduled_time_in,
      actual_time_in: att.actual_time_in,
      scheduled_time_out: att.scheduled_time_out,
      actual_time_out: att.actual_time_out,
      decision: 'YES',
      requested_hours: 2,
      verified_hours: 2,
      approved_hours: 2,
      overtime_rate_applied: 338,
      approved_amount: 676,
      reason: 'Holiday coverage',
      status: 'APPROVED',
      admin_remarks: 'Approved',
      reviewed_by: 'admin-1',
      reviewed_at: '',
      created_at: '',
    };

    const pay = computeEmployeePayroll({
      payrollPeriodId: 'pp-2',
      startDate: holidayDate,
      endDate: holidayDate,
      employee: baseEmployee,
      schedule: standardSchedule,
      attendances: [att],
      overtimeRequests: [ot],
      leaveRequests: [],
      holidays: [holiday],
      multipliers: DEFAULT_MULTIPLIERS,
    });

    // 800 * 2.60 = 2080; OT: 2 hrs * 100 * 3.38 = 676; Allowances: 800; Deductions: 200
    expect(pay.holiday_rest_day_pay).toBe(2080);
    expect(pay.holiday_overtime_pay).toBe(676);
    expect(pay.gross_pay).toBe(3556);
    expect(pay.net_pay).toBe(3356);
  });

  it('computes Weekly Paid employee payroll with Weekly Rate and absence deduction cleanly', () => {
    const weeklyEmployee: Employee = {
      ...baseEmployee,
      salary_type: 'WEEKLY',
      daily_rate: 800,
      hourly_rate: 100,
      weekly_rate: 4800,
      monthly_rate: 17600,
      meal_allowance: 0,
      transport_allowance: 0,
      default_deductions: 0,
    };

    // Mon 2026-11-16 through Sun 2026-11-22 (6 workdays + 1 Sunday rest day)
    // Present 5 days (Mon-Fri), absent Saturday
    const presentDates = ['2026-11-16', '2026-11-17', '2026-11-18', '2026-11-19', '2026-11-20'];
    const atts: AttendanceRecord[] = presentDates.map((d, idx) => ({
      id: `att-wk-${idx}`,
      employee_id: weeklyEmployee.id,
      work_date: d,
      schedule_id: standardSchedule.id,
      scheduled_time_in: buildManilaTimestamp(d, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(d, '17:00:00'),
      actual_time_in: buildManilaTimestamp(d, '08:00:00'),
      actual_time_out: buildManilaTimestamp(d, '17:00:00'),
      early_arrival_minutes: 0,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 8,
      actual_hours: 8,
      paid_hours: 8,
      approved_overtime_hours: 0,
      status: 'ON_TIME',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: '',
      updated_at: '',
    }));

    const pay = computeEmployeePayroll({
      payrollPeriodId: 'pp-wk-1',
      startDate: '2026-11-16',
      endDate: '2026-11-22',
      employee: weeklyEmployee,
      schedule: standardSchedule,
      attendances: atts,
      overtimeRequests: [],
      leaveRequests: [],
      holidays: [],
      multipliers: DEFAULT_MULTIPLIERS,
    });

    expect(pay.basic_pay).toBe(4800);
    expect(pay.absence_deductions).toBe(800);
    expect(pay.gross_pay).toBe(4800);
    expect(pay.net_pay).toBe(4000);
    expect(pay.rate_snapshot.weekly_rate).toBe(4800);
  });
});
