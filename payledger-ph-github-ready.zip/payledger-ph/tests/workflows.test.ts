import { beforeEach, describe, expect, it, vi } from 'vitest';
import { euclideanDistance, findBestFaceMatch } from '../src/lib/attendance/faceRecognition';
import { buildEmployeeQrPayload, extractEmployeeNumberFromQr } from '../src/lib/attendance/qr';
import { formatManilaTime, toManilaTime24 } from '../src/lib/date/manila';
import { dataService } from '../src/services/dataService';

// Simple in-memory localStorage mock for Node test environment
const store = new Map<string, string>();
vi.stubGlobal('localStorage', {
  getItem: (k: string) => store.get(k) ?? null,
  setItem: (k: string, v: string) => store.set(k, v),
  removeItem: (k: string) => store.delete(k),
  clear: () => store.clear(),
});
vi.stubGlobal('navigator', { userAgent: 'vitest-agent', onLine: true });

describe('Employee Number Attendance, Credentials, Overtime & Payroll Locking Workflows', () => {
  beforeEach(() => {
    store.clear();
  });

  it('shows employee name on lookup and toggles IN -> OUT -> IN -> OUT with zero delay', async () => {
    const admin = await dataService.signInWithPassword('superadmin@payledger.ph', 'PreviewAdmin123!');
    expect(admin.role).toBe('SUPER_ADMIN');

    const emp = await dataService.createEmployee(admin, {
      employee_number: 'EMP-2026-0099',
      full_name: 'Elena Reyes',
      photo_url: null,
      position: 'Accountant',
      department: 'Finance',
      contact_number: '09171234567',
      address: 'Makati',
      email: 'elena@payledger.ph',
      date_hired: '2026-11-01',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: '11111111-1111-4111-8111-111111111101',
      rest_days: [0],
      salary_type: 'DAILY',
      daily_rate: 1000,
      hourly_rate: 125,
      monthly_rate: 0,
      overtime_rate: 125,
      meal_allowance: 200,
      transport_allowance: 200,
      other_allowances: 0,
      default_deductions: 100,
    });
    expect(emp.employee_number).toBe('EMP-2026-0099');

    // Lookup shows employee name and next event = TIME_IN
    const beforeFirst = await dataService.lookupEmployeeByNumber('EMP-2026-0099');
    expect(beforeFirst.found).toBe(true);
    expect(beforeFirst.full_name).toBe('Elena Reyes');
    expect(beforeFirst.next_event).toBe('TIME_IN');

    // 1st punch -> TIME IN
    const punch1 = await dataService.punchAttendanceByEmployeeNumber('EMP-2026-0099', { source: 'KIOSK' });
    expect(punch1.success).toBe(true);
    expect(punch1.event_type).toBe('TIME_IN');

    // Lookup immediately shows next event = TIME_OUT
    const afterFirst = await dataService.lookupEmployeeByNumber('EMP-2026-0099');
    expect(afterFirst.next_event).toBe('TIME_OUT');

    // 2nd punch immediately with NO delay -> TIME OUT
    const punch2 = await dataService.punchAttendanceByEmployeeNumber('EMP-2026-0099', { source: 'KIOSK' });
    expect(punch2.success).toBe(true);
    expect(punch2.event_type).toBe('TIME_OUT');

    // 3rd punch immediately with NO delay -> TIME IN again
    const punch3 = await dataService.punchAttendanceByEmployeeNumber('EMP-2026-0099', { source: 'KIOSK' });
    expect(punch3.success).toBe(true);
    expect(punch3.event_type).toBe('TIME_IN');

    // 4th punch immediately with NO delay -> TIME OUT again
    const punch4 = await dataService.punchAttendanceByEmployeeNumber('EMP-2026-0099', { source: 'KIOSK' });
    expect(punch4.success).toBe(true);
    expect(punch4.event_type).toBe('TIME_OUT');

    // Revoking Employee Number credential blocks punching
    await dataService.updateEmployeeCredential(admin, emp.id, {
      credential_status: 'REVOKED',
      revoked_reason: 'Lost ID card',
    });
    const revokedPunch = await dataService.punchAttendanceByEmployeeNumber('EMP-2026-0099', { source: 'KIOSK' });
    expect(revokedPunch.success).toBe(false);
    expect(revokedPunch.error_code).toBe('REVOKED_CREDENTIAL');
  });

  it('locks finalized payroll snapshot so subsequent salary updates do not alter historical payroll', async () => {
    const admin = await dataService.signInWithPassword('superadmin@payledger.ph', 'PreviewAdmin123!');
    const state = await dataService.loadWorkspaceData(admin);
    const targetEmp = state.employees[2]; // Daily paid EMP-2026-0003

    const { period, records } = await dataService.generatePayrollPeriod(
      admin,
      {
        period_name: 'Nov 1-16 Cutoff',
        start_date: '2026-11-01',
        end_date: '2026-11-16',
        pay_date: '2026-11-20',
        payroll_schedule: 'SEMI_MONTHLY',
      },
      state
    );

    const empRecordBefore = records.find((r) => r.employee_id === targetEmp.id)!;
    const lockedNetBefore = empRecordBefore.net_pay;

    // Finalize & Lock
    await dataService.updatePayrollPeriodStatus(admin, period, 'FINALIZED');

    // Update employee salary AFTER finalization
    await dataService.updateEmployeeSalary(admin, targetEmp, {
      salary_type: 'DAILY',
      daily_rate: 1500,
      hourly_rate: 187.5,
      monthly_rate: 0,
      overtime_rate: 187.5,
      meal_allowance: 1000,
      transport_allowance: 800,
      other_allowances: 0,
      default_deductions: 650,
      effective_date: '2026-11-17',
      reason: 'Promotion',
    });

    const refreshed = await dataService.loadWorkspaceData(admin);
    const lockedRecordAfter = refreshed.payrollRecords.find((r) => r.id === empRecordBefore.id)!;
    expect(lockedRecordAfter.is_locked).toBe(true);
    expect(lockedRecordAfter.net_pay).toBe(lockedNetBefore);
    expect(refreshed.salaryHistory.length).toBeGreaterThanOrEqual(2);
  });

  it('parses Employee Number QR payloads and formats Manila kiosk clock in 24-hour format', () => {
    expect(buildEmployeeQrPayload(' emp-2026-0001 ')).toBe('EMP-2026-0001');
    expect(extractEmployeeNumberFromQr('emp-2026-0001')).toBe('EMP-2026-0001');
    expect(extractEmployeeNumberFromQr('PAYLEDGER:emp-2026-0002')).toBe('EMP-2026-0002');
    expect(extractEmployeeNumberFromQr('{"employee_number":"emp-2026-0003"}')).toBe('EMP-2026-0003');
    expect(extractEmployeeNumberFromQr('https://kiosk.example.com/?employee_number=emp-2026-0004')).toBe('EMP-2026-0004');
    expect(extractEmployeeNumberFromQr('   ')).toBeNull();

    // 14:35:09 in Asia/Manila (06:35:09Z)
    expect(toManilaTime24('2026-11-16T06:35:09Z')).toBe('14:35:09');
    expect(formatManilaTime('2026-11-16T06:35:09Z')).toBe('14:35');
    // 00:05:00 in Asia/Manila (16:05:00Z prior UTC day)
    expect(toManilaTime24('2026-11-16T16:05:00Z')).toBe('00:05:00');
  });

  it('stores 128-D face descriptor during registration and matches enrolled employees accurately', async () => {
    const admin = await dataService.signInWithPassword('superadmin@payledger.ph', 'PreviewAdmin123!');
    const enrolledDescriptor = Array.from({ length: 128 }, (_, i) => (i % 2 === 0 ? 0.12 : -0.08));
    const strangerDescriptor = Array.from({ length: 128 }, (_, i) => (i % 2 === 0 ? -0.45 : 0.45));

    await dataService.createEmployee(admin, {
      employee_number: 'EMP-2026-0777',
      full_name: 'Carlos M. Navarro',
      photo_url: null,
      position: 'Supervisor',
      department: 'Operations',
      contact_number: '09170007777',
      address: 'Pasig',
      email: 'carlos@payledger.ph',
      date_hired: '2026-11-16',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: '11111111-1111-4111-8111-111111111101',
      rest_days: [0],
      salary_type: 'DAILY',
      daily_rate: 950,
      hourly_rate: 118.75,
      monthly_rate: 0,
      overtime_rate: 118.75,
      meal_allowance: 0,
      transport_allowance: 0,
      other_allowances: 0,
      default_deductions: 0,
      face_descriptor: enrolledDescriptor,
      face_enrolled_at: '2026-11-16T10:00:00.000Z',
    });

    const enrolled = await dataService.listEnrolledFaces();
    expect(enrolled.some((e) => e.employee_number === 'EMP-2026-0777')).toBe(true);

    // Slightly noisy probe of the same person matches
    const probe = enrolledDescriptor.map((v, i) => v + (i % 3 === 0 ? 0.01 : -0.01));
    expect(euclideanDistance(probe, enrolledDescriptor)).toBeLessThan(0.2);
    const match = findBestFaceMatch(probe, enrolled);
    expect(match?.employee_number).toBe('EMP-2026-0777');
    expect(match?.confidencePercent).toBeGreaterThan(80);

    // Unrelated face descriptor does not match
    expect(findBestFaceMatch(strangerDescriptor, enrolled)).toBeNull();
  });
});
