const MODEL_URI = '/models';

type FaceApiModule = typeof import('@vladmandic/face-api');

let faceApiPromise: Promise<FaceApiModule> | null = null;
let modelsPromise: Promise<void> | null = null;

async function getFaceApi(): Promise<FaceApiModule> {
  if (!faceApiPromise) {
    faceApiPromise = import('@vladmandic/face-api');
  }
  return faceApiPromise;
}

export interface FaceDetectionResult {
  descriptor: number[];
  score: number;
  box: { x: number; y: number; width: number; height: number };
}

export interface EnrolledFaceCandidate {
  employee_id?: string;
  employee_number: string;
  full_name: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  face_descriptor: number[];
}

export interface FaceMatchResult {
  employee_number: string;
  full_name: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  distance: number;
  confidencePercent: number;
}

/**
 * Loads TinyFaceDetector, FaceLandmark68TinyNet, and FaceRecognitionNet from /models once.
 */
export async function loadFaceModels(): Promise<void> {
  if (!modelsPromise) {
    modelsPromise = (async () => {
      const faceapi = await getFaceApi();
      await Promise.all([
        faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URI),
        faceapi.nets.faceLandmark68TinyNet.loadFromUri(MODEL_URI),
        faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URI),
      ]);
    })().catch((err) => {
      modelsPromise = null;
      throw err;
    });
  }
  return modelsPromise;
}

/**
 * Detects a single prominent face and computes a 128-D face descriptor.
 */
export async function detectFaceDescriptor(
  source: HTMLVideoElement | HTMLImageElement | HTMLCanvasElement
): Promise<FaceDetectionResult | null> {
  await loadFaceModels();
  const faceapi = await getFaceApi();
  const detection = await faceapi
    .detectSingleFace(
      source,
      new faceapi.TinyFaceDetectorOptions({
        inputSize: 320,
        scoreThreshold: 0.45,
      })
    )
    .withFaceLandmarks(true)
    .withFaceDescriptor();

  if (!detection) return null;

  return {
    descriptor: Array.from(detection.descriptor),
    score: Number(detection.detection.score.toFixed(4)),
    box: {
      x: detection.detection.box.x,
      y: detection.detection.box.y,
      width: detection.detection.box.width,
      height: detection.detection.box.height,
    },
  };
}

export function euclideanDistance(a: number[], b: number[]): number {
  if (a.length === 0 || a.length !== b.length) return Number.POSITIVE_INFINITY;
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const diff = a[i] - b[i];
    sum += diff * diff;
  }
  return Math.sqrt(sum);
}

/**
 * Matches a 128-D face descriptor against enrolled employees using Euclidean distance.
 */
export function findBestFaceMatch(
  probeDescriptor: number[],
  candidates: EnrolledFaceCandidate[],
  maxDistance = 0.54
): FaceMatchResult | null {
  let best: FaceMatchResult | null = null;

  for (const cand of candidates) {
    if (!Array.isArray(cand.face_descriptor) || cand.face_descriptor.length !== probeDescriptor.length) {
      continue;
    }
    const distance = euclideanDistance(probeDescriptor, cand.face_descriptor);
    if (distance <= maxDistance && (!best || distance < best.distance)) {
      const confidencePercent = Math.max(1, Math.min(99, Math.round((1 - distance / 0.9) * 100)));
      best = {
        employee_number: cand.employee_number,
        full_name: cand.full_name,
        position: cand.position,
        department: cand.department,
        photo_url: cand.photo_url,
        distance: Number(distance.toFixed(4)),
        confidencePercent,
      };
    }
  }

  return best;
}

export function loadImageElement(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = () => reject(new Error('Failed to load image for face scan.'));
    img.src = src;
  });
}
