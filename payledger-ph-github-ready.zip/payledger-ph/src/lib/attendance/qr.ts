/**
 * Builds the canonical QR payload for an employee's attendance badge.
 */
export function buildEmployeeQrPayload(employeeNumber: string): string {
  return employeeNumber.trim().toUpperCase();
}

/**
 * Extracts a normalized Employee Number from scanned QR code text.
 * Supports:
 * - Plain employee number: "EMP-2026-0001"
 * - Prefixed codes: "PAYLEDGER:EMP-2026-0001", "EMP:EMP-2026-0001"
 * - JSON payloads: {"employee_number":"EMP-2026-0001"} or {"employeeNumber":"..."}
 * - URL query params: https://.../kiosk?employee_number=EMP-2026-0001 or ?emp=...
 */
export function extractEmployeeNumberFromQr(rawText: string): string | null {
  const trimmed = rawText.trim();
  if (!trimmed) return null;

  // 1. JSON payload
  if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
    try {
      const parsed = JSON.parse(trimmed) as Record<string, unknown>;
      const candidate =
        parsed.employee_number ??
        parsed.employeeNumber ??
        parsed.emp_no ??
        parsed.empNo ??
        parsed.code;
      if (typeof candidate === 'string' && candidate.trim()) {
        return candidate.trim().toUpperCase();
      }
    } catch {
      // fall through
    }
  }

  // 2. URL with query parameters
  if (/^https?:\/\//i.test(trimmed)) {
    try {
      const url = new URL(trimmed);
      const param =
        url.searchParams.get('employee_number') ??
        url.searchParams.get('employeeNumber') ??
        url.searchParams.get('emp');
      if (param && param.trim()) {
        return param.trim().toUpperCase();
      }
    } catch {
      // fall through
    }
  }

  // 3. Prefixed format like PAYLEDGER:EMP-2026-0001 or EMP:EMP-2026-0001
  const prefixMatch = trimmed.match(/^(?:PAYLEDGER|EMP|EMPLOYEE|ID)\s*:\s*(.+)$/i);
  if (prefixMatch?.[1]) {
    const val = prefixMatch[1].trim().toUpperCase();
    return val || null;
  }

  // 4. Plain single-line Employee Number token
  const cleaned = trimmed.replace(/\s+/g, '');
  if (cleaned.length >= 2 && cleaned.length <= 64) {
    return cleaned.toUpperCase();
  }

  return null;
}
