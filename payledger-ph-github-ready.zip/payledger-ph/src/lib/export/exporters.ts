import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import QRCode from 'qrcode';
import type { CompanySettings, Employee, PayrollPeriod, PayrollRecord } from '../../types/database';
import { buildEmployeeQrPayload } from '../attendance/qr';
import { formatManilaDate } from '../date/manila';
import { buildPayslipTemplateData, formatSlipNum } from '../payroll/payslipFormat';

export function exportToExcel(filename: string, sheetName: string, rows: Record<string, string | number>[]) {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, sheetName.slice(0, 31));
  XLSX.writeFile(workbook, filename.endsWith('.xlsx') ? filename : `${filename}.xlsx`);
}

export function exportToCsv(filename: string, rows: Record<string, string | number>[]) {
  const worksheet = XLSX.utils.json_to_sheet(rows);
  const csv = XLSX.utils.sheet_to_csv(worksheet);
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename.endsWith('.csv') ? filename : `${filename}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

export function exportTableToPdf(
  filename: string,
  title: string,
  subtitle: string,
  columns: string[],
  bodyRows: (string | number)[][]
) {
  const doc = new jsPDF({ orientation: columns.length > 7 ? 'landscape' : 'portrait', unit: 'pt', format: 'a4' });
  doc.setFontSize(14);
  doc.setTextColor(15, 23, 42);
  doc.text(title, 40, 40);
  doc.setFontSize(9);
  doc.setTextColor(100, 116, 139);
  doc.text(subtitle, 40, 56);

  autoTable(doc, {
    head: [columns],
    body: bodyRows,
    startY: 70,
    styles: { fontSize: 8, cellPadding: 5, textColor: [15, 23, 42] },
    headStyles: { fillColor: [30, 64, 175], textColor: [255, 255, 255], fontStyle: 'bold' },
    alternateRowStyles: { fillColor: [248, 250, 252] },
  });

  doc.save(filename.endsWith('.pdf') ? filename : `${filename}.pdf`);
}

function drawPayslipBoxOnDoc(
  doc: jsPDF,
  record: PayrollRecord,
  period: PayrollPeriod,
  company: CompanySettings,
  x: number,
  y: number,
  widthMm: number,
  heightMm: number
) {
  const d = buildPayslipTemplateData(record, period, company);

  const headerH = heightMm * 0.085;
  const noteH = heightMm * 0.055;
  const tableTop = y + headerH;
  const rowsCount = 24;
  const rowH = (heightMm - headerH - noteH) / rowsCount;

  // Outer frame
  doc.setFillColor(255, 255, 255);
  doc.setDrawColor(0, 0, 0);
  doc.setLineWidth(0.35);
  doc.rect(x, y, widthMm, heightMm, 'FD');

  // Header band with logo mark + company name
  doc.setFillColor(30, 64, 175);
  const logoSize = Math.min(4.2, headerH * 0.6);
  const logoX = x + widthMm * 0.14;
  const logoY = y + (headerH - logoSize) / 2;
  doc.roundedRect(logoX, logoY, logoSize * 1.3, logoSize, 0.5, 0.5, 'F');
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(Math.max(4.5, widthMm * 0.055));
  doc.text('PL', logoX + logoSize * 0.65, logoY + logoSize * 0.72, { align: 'center' });

  doc.setTextColor(29, 78, 216);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(Math.max(6, widthMm * 0.088));
  doc.text(d.companyName, logoX + logoSize * 1.7, y + headerH * 0.66, {
    maxWidth: widthMm - (logoX - x) - logoSize * 2,
  });

  // Column x coordinates
  const nameSplitX = x + widthMm * 0.34;
  const midSplitX = x + widthMm * 0.45;
  const valSplitX = x + widthMm * 0.66;
  const rightEdge = x + widthMm;
  const fontSize = Math.max(4.8, widthMm * 0.068);
  const smallFontSize = Math.max(4.1, widthMm * 0.055);

  doc.setLineWidth(0.18);
  doc.setDrawColor(0, 0, 0);

  const drawRowBgAndBorders = (
    rowIdx: number,
    opts?: { splitType?: 'name' | 'three' | 'two'; fillYellowRight?: boolean }
  ) => {
    const ry = tableTop + rowIdx * rowH;
    if (opts?.fillYellowRight) {
      doc.setFillColor(255, 255, 0);
      doc.rect(valSplitX, ry, rightEdge - valSplitX, rowH, 'F');
      // Highlight behind NET PAY label
      doc.rect(x + 0.6, ry + 0.25, widthMm * 0.24, rowH - 0.5, 'F');
    }
    doc.line(x, ry, rightEdge, ry);
    if (opts?.splitType === 'name') {
      doc.line(nameSplitX, ry, nameSplitX, ry + rowH);
    } else if (opts?.splitType === 'three') {
      doc.line(midSplitX, ry, midSplitX, ry + rowH);
      doc.line(valSplitX, ry, valSplitX, ry + rowH);
    } else {
      doc.line(valSplitX, ry, valSplitX, ry + rowH);
    }
    return ry;
  };

  const textY = (ry: number) => ry + rowH * 0.72;

  // 0: Name
  let ry = drawRowBgAndBorders(0, { splitType: 'name' });
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(0, 0, 0);
  doc.setFontSize(fontSize);
  doc.text('Name:', x + 1, textY(ry));
  doc.setFont('helvetica', 'bold');
  doc.text(d.employeeName, nameSplitX + 1.2, textY(ry), { maxWidth: rightEdge - nameSplitX - 2 });

  // 1: Pay Period
  ry = drawRowBgAndBorders(1, { splitType: 'name' });
  doc.setFont('helvetica', 'normal');
  doc.text('Pay Period:', x + 1, textY(ry));
  doc.text(d.payPeriodLabel, nameSplitX + 1.2, textY(ry), { maxWidth: rightEdge - nameSplitX - 2 });

  // 2: New rate
  ry = drawRowBgAndBorders(2, { splitType: 'two' });
  doc.text('New rate', x + 1, textY(ry));
  doc.text(formatSlipNum(d.newRate), valSplitX - 1, textY(ry), { align: 'right' });

  // 3-5: Days, OT1, OT2
  const threeRows: [string, number, number][] = [
    ['Days', d.daysWorked, d.basicPay],
    ['OT1', d.ot1Hours, d.ot1Pay],
    ['OT2', d.ot2Hours, d.ot2Pay],
  ];
  threeRows.forEach(([label, qty, amt], idx) => {
    ry = drawRowBgAndBorders(3 + idx, { splitType: 'three' });
    doc.setFont('helvetica', 'normal');
    doc.text(label, x + 1, textY(ry));
    doc.text(formatSlipNum(qty), valSplitX - 1, textY(ry), { align: 'right' });
    doc.text(formatSlipNum(amt), rightEdge - 1, textY(ry), { align: 'right' });
  });

  // 6-9: OTL/SL, Usd, Legal Holiday, Special Holiday
  const twoColEarnings: [string, number][] = [
    ['OTL/SL', d.otlSl],
    ['Usd', d.usd],
    ['Legal Holiday', d.legalHoliday],
    ['Special Holiday', d.specialHoliday],
  ];
  twoColEarnings.forEach(([label, amt], idx) => {
    ry = drawRowBgAndBorders(6 + idx, { splitType: 'two' });
    doc.setFont('helvetica', 'normal');
    doc.text(label, x + 1, textY(ry));
    doc.text(formatSlipNum(amt), rightEdge - 1, textY(ry), { align: 'right' });
  });

  // 10: Gross Earn
  ry = drawRowBgAndBorders(10, { splitType: 'two' });
  doc.setFont('helvetica', 'bolditalic');
  doc.text('Gross Earn', x + 1, textY(ry));
  doc.text(formatSlipNum(d.grossEarn), rightEdge - 1, textY(ry), { align: 'right' });

  // 11: DEDUCTIONS:
  ry = drawRowBgAndBorders(11, { splitType: 'two' });
  doc.setFont('helvetica', 'bolditalic');
  doc.setTextColor(220, 38, 38);
  doc.text('DEDUCTIONS:', x + 1, textY(ry));

  // 12-21: Deductions rows
  const deductionRows: [string, string, number][] = [
    ['SSS Share', d.sssShareRemarks ? `(${d.sssShareRemarks})` : '', d.sssShare],
    ['PHIC Share', d.phicShareRemarks ? `(${d.phicShareRemarks})` : '', d.phicShare],
    ['PAG-IBIG Share', '', d.pagibigShare],
    ['SSS Loan', '', d.sssLoan],
    ['Pag-ibig Loan', '', d.pagibigLoan],
    ['Coop Share', '', d.coopShare],
    ['Coop Loan', '', d.coopLoan],
    ['Donation', '', d.donation],
    ['Cash advance', '', d.cashAdvance],
    ['Late', '', d.late],
  ];
  doc.setTextColor(0, 0, 0);
  deductionRows.forEach(([label, remark, amt], idx) => {
    ry = drawRowBgAndBorders(12 + idx, { splitType: 'two' });
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(fontSize);
    doc.text(label, x + 1, textY(ry));
    if (remark) {
      doc.setFontSize(smallFontSize);
      doc.text(remark, valSplitX - 1, textY(ry), { align: 'right', maxWidth: valSplitX - x - 18 });
      doc.setFontSize(fontSize);
    }
    doc.text(formatSlipNum(amt), rightEdge - 1, textY(ry), { align: 'right' });
  });

  // 22: Total Deductions:
  ry = drawRowBgAndBorders(22, { splitType: 'two' });
  doc.setFont('helvetica', 'bolditalic');
  doc.text('Total Deductions:', x + 1, textY(ry));
  doc.text(formatSlipNum(d.totalDeductions), rightEdge - 1, textY(ry), { align: 'right' });

  // 23: NET PAY: (Yellow highlight)
  ry = drawRowBgAndBorders(23, { splitType: 'two', fillYellowRight: true });
  doc.setFont('helvetica', 'bolditalic');
  doc.setTextColor(0, 0, 0);
  doc.text('NET PAY:', x + 1, textY(ry));
  doc.text(formatSlipNum(d.netPay), rightEdge - 1, textY(ry), { align: 'right' });

  // Bottom Note row
  const noteY = tableTop + rowsCount * rowH;
  doc.line(x, noteY, rightEdge, noteY);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(smallFontSize);
  doc.text(`NOTE: ${d.note}`, x + 1, noteY + noteH * 0.66, { maxWidth: widthMm - 2 });

  // Re-stroke crisp thick outer border
  doc.setLineWidth(0.4);
  doc.rect(x, y, widthMm, heightMm, 'S');
}

export function exportPayslipPdf(
  record: PayrollRecord,
  period: PayrollPeriod,
  company: CompanySettings
) {
  // Single payslip centered cleanly on A4
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  drawPayslipBoxOnDoc(doc, record, period, company, 35, 25, 140, 145);
  doc.save(`Payslip_${record.employee_number}_${period.start_date}.pdf`);
}

export function exportMassPayslips8UpPdf(
  records: PayrollRecord[],
  period: PayrollPeriod,
  company: CompanySettings,
  layout: '2x4' | '4x2' = '2x4'
) {
  if (records.length === 0) return;
  // Exact 80mm x 80mm (3 1/8" width) per slip, 8 slips per Legal/Folio sheet
  const isLandscape = layout === '4x2';
  const doc = new jsPDF({
    orientation: isLandscape ? 'landscape' : 'portrait',
    unit: 'mm',
    format: 'legal', // 215.9mm x 355.6mm fits 2x4 portrait or 4x2 landscape cleanly
  });

  const cols = isLandscape ? 4 : 2;
  const slipW = 80;
  const slipH = 80;
  const gap = 3;
  const pageW = isLandscape ? 355.6 : 215.9;
  const pageH = isLandscape ? 215.9 : 355.6;
  const gridW = cols * slipW + (cols - 1) * gap;
  const rows = isLandscape ? 2 : 4;
  const gridH = rows * slipH + (rows - 1) * gap;
  const startX = Math.max(4, (pageW - gridW) / 2);
  const startY = Math.max(5, (pageH - gridH) / 2);

  records.forEach((rec, index) => {
    const posInPage = index % 8;
    if (index > 0 && posInPage === 0) {
      doc.addPage('legal', isLandscape ? 'landscape' : 'portrait');
    }
    const col = posInPage % cols;
    const row = Math.floor(posInPage / cols);
    const x = startX + col * (slipW + gap);
    const y = startY + row * (slipH + gap);
    drawPayslipBoxOnDoc(doc, rec, period, company, x, y, slipW, slipH);
  });

  doc.save(`Mass_Payslips_8up_${period.start_date}.pdf`);
}

export async function exportEmployeeIdCardPdf(employee: Employee, company: CompanySettings) {
  // Exact 2" x 3" portrait ID Card (144pt x 216pt)
  const doc = new jsPDF({ orientation: 'portrait', unit: 'pt', format: [144, 216] });
  doc.setFillColor(255, 255, 255);
  doc.rect(0, 0, 144, 216, 'F');

  // Top Header
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, 144, 30, 'F');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text(company.company_name, 72, 14, { align: 'center', maxWidth: 128 });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(148, 163, 184);
  doc.text('OFFICIAL EMPLOYEE ID', 72, 24, { align: 'center' });

  // Employee Identity
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text(employee.full_name, 72, 44, { align: 'center', maxWidth: 128 });

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(6.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`${employee.position} · ${employee.department}`, 72, 55, { align: 'center', maxWidth: 128 });

  // BIG Centered QR Code in the Middle
  try {
    const qrDataUrl = await QRCode.toDataURL(buildEmployeeQrPayload(employee.employee_number), {
      width: 420,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: { dark: '#0f172a', light: '#ffffff' },
    });
    doc.setDrawColor(203, 213, 225);
    doc.setFillColor(255, 255, 255);
    doc.roundedRect(21, 63, 102, 102, 5, 5, 'FD');
    doc.addImage(qrDataUrl, 'PNG', 26, 67, 92, 92);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(5);
    doc.setTextColor(37, 99, 235);
    doc.text('SCAN AT ATTENDANCE KIOSK', 72, 162, { align: 'center' });
  } catch {
    // ignore QR fallback
  }

  // Employee Number Box
  doc.setFillColor(239, 246, 255);
  doc.setDrawColor(191, 219, 254);
  doc.roundedRect(14, 171, 116, 25, 4, 4, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(5.5);
  doc.setTextColor(37, 99, 235);
  doc.text('EMPLOYEE NUMBER', 72, 180, { align: 'center' });

  doc.setFont('courier', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(15, 23, 42);
  doc.text(employee.employee_number, 72, 192, { align: 'center' });

  // Footer
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(5.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Hired: ${formatManilaDate(employee.date_hired)} · ${employee.employment_type}`, 72, 207, {
    align: 'center',
    maxWidth: 130,
  });

  doc.save(`ID_Card_${employee.employee_number}.pdf`);
}

export async function downloadEmployeeIdCardPng(employee: Employee, company: CompanySettings) {
  // Exact 2x3 portrait ID card (600x900 px)
  const canvas = document.createElement('canvas');
  canvas.width = 600;
  canvas.height = 900;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Header bar
  ctx.fillStyle = '#0f172a';
  ctx.fillRect(0, 0, canvas.width, 120);

  ctx.textAlign = 'center';
  ctx.fillStyle = '#ffffff';
  ctx.font = 'bold 28px sans-serif';
  ctx.fillText(company.company_name, 300, 58, 540);

  ctx.fillStyle = '#94a3b8';
  ctx.font = '15px sans-serif';
  ctx.fillText('OFFICIAL EMPLOYEE IDENTIFICATION', 300, 90);

  // Employee Details
  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 30px sans-serif';
  ctx.fillText(employee.full_name, 300, 174, 530);

  ctx.fillStyle = '#475569';
  ctx.font = '20px sans-serif';
  ctx.fillText(`${employee.position} · ${employee.department}`, 300, 210, 530);

  // BIG Centered QR Code in the Middle
  try {
    const qrDataUrl = await QRCode.toDataURL(buildEmployeeQrPayload(employee.employee_number), {
      width: 420,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: { dark: '#0f172a', light: '#ffffff' },
    });
    const qrImg = new Image();
    await new Promise<void>((resolve) => {
      qrImg.onload = () => resolve();
      qrImg.onerror = () => resolve();
      qrImg.src = qrDataUrl;
    });
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(100, 246, 400, 412);
    ctx.strokeStyle = '#cbd5e1';
    ctx.lineWidth = 3;
    ctx.strokeRect(100, 246, 400, 412);
    ctx.drawImage(qrImg, 120, 260, 360, 360);
    ctx.fillStyle = '#2563eb';
    ctx.font = 'bold 14px sans-serif';
    ctx.fillText('SCAN AT ATTENDANCE KIOSK', 300, 644);
  } catch {
    // ignore QR fallback
  }

  // Employee Number Box
  ctx.fillStyle = '#eff6ff';
  ctx.fillRect(60, 682, 480, 108);
  ctx.strokeStyle = '#bfdbfe';
  ctx.lineWidth = 2;
  ctx.strokeRect(60, 682, 480, 108);

  ctx.fillStyle = '#2563eb';
  ctx.font = 'bold 14px sans-serif';
  ctx.fillText('EMPLOYEE NUMBER', 300, 716);

  ctx.fillStyle = '#0f172a';
  ctx.font = 'bold 34px monospace';
  ctx.fillText(employee.employee_number, 300, 764, 450);

  // Footer
  ctx.fillStyle = '#64748b';
  ctx.font = '15px sans-serif';
  ctx.fillText(`Hired: ${formatManilaDate(employee.date_hired)} · ${employee.employment_type}`, 300, 834, 540);
  ctx.font = '13px sans-serif';
  ctx.fillText(`${company.company_address} · ${company.contact_number}`, 300, 864, 540);

  const link = document.createElement('a');
  link.download = `ID_Card_${employee.employee_number}.png`;
  link.href = canvas.toDataURL('image/png');
  link.click();
}
