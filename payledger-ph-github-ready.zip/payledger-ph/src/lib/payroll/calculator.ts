import type {
  AttendanceRecord,
  DayClassification,
  Employee,
  Holiday,
  HolidayMultipliers,
  LeaveRequest,
  OvertimeRequest,
  PayrollRecord,
  Schedule,
} from '../../types/database';
import { enumerateDateRange, getManilaDayOfWeek } from '../date/manila';
import { classifyDay } from '../attendance/calculator';

export const DEFAULT_MULTIPLIERS: HolidayMultipliers = {
  ordinary: { first8: 1.0, overtime: 1.25 },
  rest_day: { first8: 1.3, overtime: 1.69 },
  special_holiday: { first8: 1.3, overtime: 1.69 },
  special_holiday_rest_day: { first8: 1.5, overtime: 1.95 },
  regular_holiday: { first8: 2.0, overtime: 2.6 },
  regular_holiday_rest_day: { first8: 2.6, overtime: 3.38 },
};

export interface ComputeEmployeePayrollInput {
  payrollPeriodId: string;
  startDate: string;
  endDate: string;
  employee: Employee;
  schedule: Schedule;
  attendances: AttendanceRecord[];
  overtimeRequests: OvertimeRequest[];
  leaveRequests: LeaveRequest[];
  holidays: Holiday[];
  multipliers: HolidayMultipliers;
  workingDaysPerMonth?: number;
}

function round2(n: number): number {
  return Number((Number.isFinite(n) ? n : 0).toFixed(2));
}

export function getEffectiveHourlyRate(
  employee: Employee,
  regularHoursPerDay = 8,
  workingDaysPerMonth = 22,
  workingDaysPerWeek = 6
): number {
  if (employee.salary_type === 'HOURLY') {
    return employee.hourly_rate > 0 ? employee.hourly_rate : employee.daily_rate / regularHoursPerDay;
  }
  if (employee.salary_type === 'DAILY') {
    return employee.hourly_rate > 0 ? employee.hourly_rate : employee.daily_rate / regularHoursPerDay;
  }
  if (employee.salary_type === 'WEEKLY') {
    const dailyEq = employee.daily_rate > 0 ? employee.daily_rate : (employee.weekly_rate ?? 0) / workingDaysPerWeek;
    return employee.hourly_rate > 0 ? employee.hourly_rate : dailyEq / regularHoursPerDay;
  }
  // MONTHLY: derive daily equivalent using configured working days per month (default 22)
  const dailyEq = employee.daily_rate > 0 ? employee.daily_rate : employee.monthly_rate / workingDaysPerMonth;
  return employee.hourly_rate > 0 ? employee.hourly_rate : dailyEq / regularHoursPerDay;
}

export function getEffectiveDailyRate(
  employee: Employee,
  regularHoursPerDay = 8,
  workingDaysPerMonth = 22,
  workingDaysPerWeek = 6
): number {
  if (employee.salary_type === 'DAILY') return employee.daily_rate;
  if (employee.salary_type === 'HOURLY') return employee.hourly_rate * regularHoursPerDay;
  if (employee.salary_type === 'WEEKLY') {
    return employee.daily_rate > 0 ? employee.daily_rate : (employee.weekly_rate ?? 0) / workingDaysPerWeek;
  }
  return employee.daily_rate > 0 ? employee.daily_rate : employee.monthly_rate / workingDaysPerMonth;
}

export function getMultipliersForClass(
  classification: DayClassification,
  multipliers: HolidayMultipliers
): { first8: number; overtime: number } {
  switch (classification) {
    case 'REST_DAY':
      return multipliers.rest_day;
    case 'SPECIAL_HOLIDAY':
      return multipliers.special_holiday;
    case 'SPECIAL_HOLIDAY_REST_DAY':
      return multipliers.special_holiday_rest_day;
    case 'REGULAR_HOLIDAY':
      return multipliers.regular_holiday;
    case 'REGULAR_HOLIDAY_REST_DAY':
      return multipliers.regular_holiday_rest_day;
    default:
      return multipliers.ordinary;
  }
}

export function computeEmployeePayroll(input: ComputeEmployeePayrollInput): Omit<PayrollRecord, 'id' | 'created_at' | 'updated_at'> {
  const {
    payrollPeriodId,
    startDate,
    endDate,
    employee,
    schedule,
    attendances,
    overtimeRequests,
    leaveRequests,
    holidays,
    multipliers,
    workingDaysPerMonth = 22,
  } = input;

  const workingDaysPerWeek = 6;
  const dates = enumerateDateRange(startDate, endDate);
  const regHoursPerDay = schedule.regular_hours || 8;
  const dailyRate = getEffectiveDailyRate(employee, regHoursPerDay, workingDaysPerMonth, workingDaysPerWeek);
  const hourlyRate = getEffectiveHourlyRate(employee, regHoursPerDay, workingDaysPerMonth, workingDaysPerWeek);

  const attendanceMap = new Map(attendances.map((a) => [a.work_date, a]));
  const holidayMap = new Map(holidays.filter((h) => h.is_verified).map((h) => [h.holiday_date, h]));
  const approvedOtMap = new Map<string, OvertimeRequest>();
  for (const ot of overtimeRequests) {
    if (ot.status === 'APPROVED' && ot.decision === 'YES') {
      approvedOtMap.set(ot.work_date, ot);
    }
  }

  const isDateOnApprovedLeave = (dateStr: string): LeaveRequest | undefined =>
    leaveRequests.find((l) => l.status === 'APPROVED' && dateStr >= l.start_date && dateStr <= l.end_date);

  let daysWorked = 0;
  let regularHoursTotal = 0;
  let approvedOtHoursTotal = 0;

  let basicPay = 0;
  let regularWorkdayPay = 0;
  let restDayPay = 0;
  let specialHolidayPay = 0;
  let regularHolidayPay = 0;
  let holidayRestDayPay = 0;
  let regularOvertimePay = 0;
  let restDayOvertimePay = 0;
  let holidayOvertimePay = 0;
  let absenceDeductions = 0;
  let undertimeDeductions = 0;

  const attendanceRefs: string[] = [];
  const overtimeRefs: string[] = [];

  let regularOtHoursTotal = 0;
  let premiumOtHoursTotal = 0;

  // For Monthly-paid employees: base period pay is half monthly (semi-monthly) or full monthly depending on range length
  const isFullMonth = dates.length >= 27;
  const monthlyBaseForPeriod = isFullMonth ? employee.monthly_rate : employee.monthly_rate / 2;

  if (employee.salary_type === 'MONTHLY') {
    basicPay = round2(monthlyBaseForPeriod);
  } else if (employee.salary_type === 'WEEKLY') {
    const resolvedWeeklyRate =
      (employee.weekly_rate ?? 0) > 0 ? Number(employee.weekly_rate) : dailyRate * workingDaysPerWeek;
    const scheduledWorkdaysInPeriod = dates.filter(
      (d) => !employee.rest_days.includes(getManilaDayOfWeek(d))
    ).length;
    basicPay = round2((scheduledWorkdaysInPeriod / workingDaysPerWeek) * resolvedWeeklyRate);
  }

  for (let i = 0; i < dates.length; i++) {
    const dateStr = dates[i];
    const att = attendanceMap.get(dateStr);
    const holiday = holidayMap.get(dateStr) ?? null;
    const { dayClassification, isRestDay } = classifyDay(dateStr, employee.rest_days, holiday);
    const mult = getMultipliersForClass(dayClassification, multipliers);
    const leave = isDateOnApprovedLeave(dateStr);

    if (att) attendanceRefs.push(att.id);

    const hasWorked = Boolean(att && att.actual_time_in && att.actual_time_out);
    const workedHours = hasWorked ? att!.regular_hours : 0;
    const dayRatio = workedHours > 0 ? Math.min(1, workedHours / regHoursPerDay) : 0;

    if (hasWorked) {
      daysWorked += 1;
      regularHoursTotal += workedHours;

      // Undertime deduction if worked < scheduled regular hours on ordinary workday
      if (att!.undertime_minutes > 0 && dayClassification === 'ORDINARY') {
        undertimeDeductions += (att!.undertime_minutes / 60) * hourlyRate;
      }

      if (employee.salary_type === 'HOURLY') {
        const pay = workedHours * hourlyRate * mult.first8;
        if (dayClassification === 'ORDINARY') {
          basicPay += workedHours * hourlyRate;
          regularWorkdayPay += pay;
        } else if (dayClassification === 'REST_DAY') {
          restDayPay += pay;
        } else if (dayClassification === 'SPECIAL_HOLIDAY') {
          specialHolidayPay += pay;
        } else if (dayClassification === 'REGULAR_HOLIDAY') {
          regularHolidayPay += pay;
        } else {
          holidayRestDayPay += pay;
        }
      } else if (employee.salary_type === 'DAILY') {
        const baseDay = dailyRate * dayRatio;
        if (dayClassification === 'ORDINARY') {
          basicPay += baseDay;
          regularWorkdayPay += baseDay;
        } else if (dayClassification === 'REST_DAY') {
          restDayPay += baseDay * mult.first8;
        } else if (dayClassification === 'SPECIAL_HOLIDAY') {
          specialHolidayPay += baseDay * mult.first8;
        } else if (dayClassification === 'REGULAR_HOLIDAY') {
          regularHolidayPay += baseDay * mult.first8;
        } else {
          holidayRestDayPay += baseDay * mult.first8;
        }
      } else if (employee.salary_type === 'WEEKLY') {
        // WEEKLY: basicPay already covers scheduled ordinary workdays in the period;
        // rest day work adds full mult.first8 (unworked rest days are not in scheduledWorkdaysInPeriod),
        // while holiday work on scheduled workdays adds only the incremental premium (mult.first8 - 1.0).
        if (dayClassification === 'ORDINARY') {
          regularWorkdayPay += dailyRate * dayRatio;
        } else if (dayClassification === 'REST_DAY') {
          restDayPay += dailyRate * dayRatio * mult.first8;
        } else if (dayClassification === 'SPECIAL_HOLIDAY') {
          specialHolidayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        } else if (dayClassification === 'REGULAR_HOLIDAY') {
          regularHolidayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        } else {
          holidayRestDayPay += dailyRate * dayRatio * mult.first8;
        }
      } else {
        // MONTHLY: basicPay already covers 100% of ordinary workdays & regular holidays;
        // add ONLY incremental premium (mult.first8 - 1.0) when working on rest days or holidays (avoid double counting!)
        if (dayClassification === 'ORDINARY') {
          regularWorkdayPay += dailyRate * dayRatio;
        } else if (dayClassification === 'REST_DAY') {
          restDayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        } else if (dayClassification === 'SPECIAL_HOLIDAY') {
          specialHolidayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        } else if (dayClassification === 'REGULAR_HOLIDAY') {
          regularHolidayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        } else {
          holidayRestDayPay += dailyRate * dayRatio * Math.max(0, mult.first8 - 1);
        }
      }

      // Approved Overtime
      const ot = approvedOtMap.get(dateStr);
      if (ot && ot.approved_hours > 0) {
        overtimeRefs.push(ot.id);
        approvedOtHoursTotal += ot.approved_hours;
        const otHourlyBase = employee.overtime_rate > 0 ? employee.overtime_rate : hourlyRate;
        const otPay = ot.approved_hours * otHourlyBase * mult.overtime;
        if (dayClassification === 'ORDINARY') {
          regularOvertimePay += otPay;
          regularOtHoursTotal += ot.approved_hours;
        } else if (dayClassification === 'REST_DAY') {
          restDayOvertimePay += otPay;
          premiumOtHoursTotal += ot.approved_hours;
        } else {
          holidayOvertimePay += otPay;
          premiumOtHoursTotal += ot.approved_hours;
        }
      }
    } else if (leave) {
      // Approved leave is NOT marked absent
      if (leave.is_paid && employee.salary_type === 'DAILY') {
        basicPay += dailyRate;
        regularWorkdayPay += dailyRate;
      }
    } else if (dayClassification === 'REGULAR_HOLIDAY' && holiday?.is_verified) {
      // Unworked Regular Holiday Pay: eligible if employee was present or on paid leave on preceding workday
      const prevDate = i > 0 ? dates[i - 1] : null;
      const prevAtt = prevDate ? attendanceMap.get(prevDate) : null;
      const prevLeave = prevDate ? isDateOnApprovedLeave(prevDate) : null;
      const eligible = !prevDate || Boolean(prevAtt?.actual_time_in) || Boolean(prevLeave?.is_paid);
      if (eligible && employee.salary_type === 'DAILY') {
        regularHolidayPay += dailyRate;
      }
    } else if (!isRestDay && (!holiday || holiday.holiday_type === 'SPECIAL_WORKING')) {
      // Unexcused absence on an ordinary workday
      const dow = getManilaDayOfWeek(dateStr);
      if (!employee.rest_days.includes(dow) && (employee.salary_type === 'MONTHLY' || employee.salary_type === 'WEEKLY')) {
        absenceDeductions += dailyRate;
      }
    }
  }

  // Monthly regularWorkdayPay display cap when basicPay is fixed monthly
  const presetOt1Pay = round2(employee.ot1_pay ?? 0);
  const presetOt2Pay = round2(employee.ot2_pay ?? 0);
  const presetSilSlVlPay = round2(employee.sil_sl_vl_pay ?? 0);
  const presetPaidLeavePay = round2(employee.paid_leave_pay ?? 0);
  const presetLegalHolidayPay = round2(employee.legal_holiday_pay ?? 0);
  const presetSpecialHolidayPay = round2(employee.special_holiday_pay ?? 0);

  regularOvertimePay = round2(regularOvertimePay + presetOt1Pay);
  restDayOvertimePay = round2(restDayOvertimePay + presetOt2Pay);
  regularHolidayPay = round2(regularHolidayPay + presetLegalHolidayPay);
  specialHolidayPay = round2(specialHolidayPay + presetSpecialHolidayPay);

  const allowancesTotal = round2(
    employee.meal_allowance +
      employee.transport_allowance +
      employee.other_allowances +
      presetSilSlVlPay +
      presetPaidLeavePay
  );
  const sssShare = round2(employee.sss_share ?? 0);
  const phicShare = round2(employee.phic_share ?? 0);
  const pagibigShare = round2(employee.pagibig_share ?? 0);
  const sssLoan = round2(employee.sss_loan ?? 0);
  const pagibigLoan = round2(employee.pagibig_loan ?? 0);
  const coopShare = round2(employee.coop_share ?? 0);
  const coopLoan = round2(employee.coop_loan ?? 0);
  const donation = round2(employee.donation ?? 0);
  const cashAdvance = round2(employee.cash_advance ?? 0);
  const itemizedSum = round2(
    sssShare + phicShare + pagibigShare + sssLoan + pagibigLoan + coopShare + coopLoan + donation + cashAdvance
  );
  const otherDeductions = itemizedSum > 0 ? itemizedSum : round2(employee.default_deductions);

  // Prevent double-counting: for DAILY/HOURLY, basicPay holds ordinary base pay while premiums hold rest/holiday pay;
  // for MONTHLY, basicPay holds fixed base salary while rest/holiday fields hold incremental premiums.
  const premiumPaySum =
    restDayPay + specialHolidayPay + regularHolidayPay + holidayRestDayPay;
  const otPaySum = regularOvertimePay + restDayOvertimePay + holidayOvertimePay;

  const grossPay = round2(basicPay + premiumPaySum + otPaySum + allowancesTotal);
  const totalDeductions = round2(absenceDeductions + undertimeDeductions + otherDeductions);
  const netPay = round2(Math.max(0, grossPay - totalDeductions));

  return {
    payroll_period_id: payrollPeriodId,
    employee_id: employee.id,
    employee_number: employee.employee_number,
    employee_name: employee.full_name,
    department: employee.department,
    position: employee.position,
    salary_type: employee.salary_type,
    rate_snapshot: {
      daily_rate: employee.daily_rate,
      hourly_rate: employee.hourly_rate,
      weekly_rate: employee.weekly_rate ?? round2(dailyRate * workingDaysPerWeek),
      monthly_rate: employee.monthly_rate,
      overtime_rate: employee.overtime_rate,
      meal_allowance: employee.meal_allowance,
      transport_allowance: employee.transport_allowance,
      other_allowances: employee.other_allowances,
      default_deductions: otherDeductions,
      ot1_pay: presetOt1Pay,
      ot2_pay: presetOt2Pay,
      sil_sl_vl_pay: presetSilSlVlPay,
      paid_leave_pay: presetPaidLeavePay,
      legal_holiday_pay: presetLegalHolidayPay,
      special_holiday_pay: presetSpecialHolidayPay,
      sss_share: sssShare,
      sss_share_remarks: employee.sss_share_remarks ?? '',
      phic_share: phicShare,
      phic_share_remarks: employee.phic_share_remarks ?? '',
      pagibig_share: pagibigShare,
      sss_loan: sssLoan,
      pagibig_loan: pagibigLoan,
      coop_share: coopShare,
      coop_loan: coopLoan,
      donation,
      cash_advance: cashAdvance,
      regular_ot_hours: round2(regularOtHoursTotal),
      premium_ot_hours: round2(premiumOtHoursTotal),
    },
    multipliers_snapshot: multipliers,
    days_worked: round2(daysWorked),
    regular_hours: round2(regularHoursTotal),
    approved_overtime_hours: round2(approvedOtHoursTotal),
    basic_pay: round2(basicPay),
    regular_workday_pay: round2(regularWorkdayPay),
    rest_day_pay: round2(restDayPay),
    special_holiday_pay: round2(specialHolidayPay),
    regular_holiday_pay: round2(regularHolidayPay),
    holiday_rest_day_pay: round2(holidayRestDayPay),
    regular_overtime_pay: round2(regularOvertimePay),
    rest_day_overtime_pay: round2(restDayOvertimePay),
    holiday_overtime_pay: round2(holidayOvertimePay),
    allowances_total: allowancesTotal,
    absence_deductions: round2(absenceDeductions),
    undertime_deductions: round2(undertimeDeductions),
    other_deductions: otherDeductions,
    adjustments_total: 0,
    gross_pay: grossPay,
    net_pay: netPay,
    attendance_refs: attendanceRefs,
    overtime_refs: overtimeRefs,
    is_locked: false,
  };
}
