import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  Maximize2,
  Minimize2,
  LogOut,
  Wifi,
  WifiOff,
  Database,
  CheckCircle2,
  XCircle,
  Delete,
  CornerDownLeft,
  Info,
  QrCode,
  Camera,
  Keyboard,
  RefreshCw,
  SwitchCamera,
  Sparkles,
  ScanFace,
} from 'lucide-react';
import jsQR from 'jsqr';
import QRCode from 'qrcode';
import { Avatar, StatusLabel } from '../../components/ui/Common';
import {
  detectFaceDescriptor,
  findBestFaceMatch,
  loadFaceModels,
  type EnrolledFaceCandidate,
  type FaceMatchResult,
} from '../../lib/attendance/faceRecognition';
import { buildEmployeeQrPayload, extractEmployeeNumberFromQr } from '../../lib/attendance/qr';
import { formatManilaDate, toManilaDateString, toManilaTime24 } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { AttendancePunchResult, CompanySettings } from '../../types/database';

type KioskMode = 'NUMBER' | 'QR' | 'CAMERA';

interface KioskLookupInfo {
  found: boolean;
  employee_number?: string;
  full_name?: string;
  position?: string;
  department?: string;
  photo_url?: string | null;
  is_active?: boolean;
  next_event?: 'TIME_IN' | 'TIME_OUT';
}

interface BarcodeDetectorLike {
  detect(source: HTMLVideoElement | HTMLCanvasElement): Promise<Array<{ rawValue?: string }>>;
}

declare global {
  interface Window {
    BarcodeDetector?: new (options?: { formats?: string[] }) => BarcodeDetectorLike;
  }
}

export function AttendanceKioskPage({
  company,
  onExitKiosk,
  onPunchRecorded,
}: {
  company: CompanySettings;
  onExitKiosk: () => void;
  onPunchRecorded: () => void;
}) {
  const [clock, setClock] = useState(() => new Date());
  const [mode, setMode] = useState<KioskMode>('NUMBER');
  const [employeeNumber, setEmployeeNumber] = useState('');
  const [pin, setPin] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [lookup, setLookup] = useState<KioskLookupInfo | null>(null);
  const [result, setResult] = useState<AttendancePunchResult | null>(null);
  const [resultSnapshot, setResultSnapshot] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(Boolean(document.fullscreenElement));
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [showGuide, setShowGuide] = useState(false);

  // Camera & QR scanner states
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'environment' | 'user'>('environment');
  const [videoDevices, setVideoDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [autoPunchQr, setAutoPunchQr] = useState(true);
  const [capturePhotoOnPunch, setCapturePhotoOnPunch] = useState(true);
  const [capturedPreview, setCapturedPreview] = useState<string | null>(null);
  const [lastScannedCode, setLastScannedCode] = useState<string | null>(null);
  const [showBadgeQrGenerator, setShowBadgeQrGenerator] = useState(false);
  const [badgeQrInput, setBadgeQrInput] = useState('EMP-2026-0001');
  const [badgeQrDataUrl, setBadgeQrDataUrl] = useState('');

  // Face Recognition states
  const [enrolledFaces, setEnrolledFaces] = useState<EnrolledFaceCandidate[]>([]);
  const [faceAutoRecognize, setFaceAutoRecognize] = useState(true);
  const [autoPunchFace, setAutoPunchFace] = useState(true);
  const [faceModelsReady, setFaceModelsReady] = useState(false);
  const [lastFaceMatch, setLastFaceMatch] = useState<FaceMatchResult | null>(null);

  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const scanCanvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const lastScanRef = useRef<{ code: string; at: number }>({ code: '', at: 0 });
  const lastFacePunchRef = useRef<{ code: string; at: number }>({ code: '', at: 0 });
  const submittingRef = useRef(false);

  useEffect(() => {
    const t = setInterval(() => setClock(new Date()), 1000);
    const onFsChange = () => setIsFullscreen(Boolean(document.fullscreenElement));
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);

    document.addEventListener('fullscreenchange', onFsChange);
    window.addEventListener('online', onOnline);
    window.addEventListener('offline', onOffline);

    return () => {
      clearInterval(t);
      document.removeEventListener('fullscreenchange', onFsChange);
      window.removeEventListener('online', onOnline);
      window.removeEventListener('offline', onOffline);
    };
  }, []);

  // Immediately show employee name & next punch state when Employee Number is typed
  useEffect(() => {
    const trimmed = employeeNumber.trim();
    if (!trimmed) {
      setLookup(null);
      return;
    }
    let cancelled = false;
    dataService.lookupEmployeeByNumber(trimmed).then((res) => {
      if (!cancelled) setLookup(res);
    });
    return () => {
      cancelled = true;
    };
  }, [employeeNumber, result]);

  // Generate on-screen QR badge helper when opened
  useEffect(() => {
    if (!showBadgeQrGenerator || !badgeQrInput.trim()) {
      setBadgeQrDataUrl('');
      return;
    }
    let cancelled = false;
    QRCode.toDataURL(buildEmployeeQrPayload(badgeQrInput), {
      width: 220,
      margin: 1,
      color: { dark: '#0f172a', light: '#ffffff' },
    })
      .then((url) => {
        if (!cancelled) setBadgeQrDataUrl(url);
      })
      .catch(() => {
        if (!cancelled) setBadgeQrDataUrl('');
      });
    return () => {
      cancelled = true;
    };
  }, [showBadgeQrGenerator, badgeQrInput]);

  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  }, []);

  const captureVideoFrame = useCallback((): string | null => {
    const video = videoRef.current;
    if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) return null;
    const canvas = document.createElement('canvas');
    const maxW = 480;
    const scale = Math.min(1, maxW / video.videoWidth);
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return null;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.72);
  }, []);

  const startCamera = useCallback(async () => {
    stopCamera();
    setCameraError(null);

    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setCameraError('Camera access is not supported in this browser or non-HTTPS context.');
      return;
    }

    try {
      const videoConstraints: MediaTrackConstraints = selectedDeviceId
        ? { deviceId: { exact: selectedDeviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
        : { facingMode, width: { ideal: 1280 }, height: { ideal: 720 } };

      const stream = await navigator.mediaDevices.getUserMedia({
        video: videoConstraints,
        audio: false,
      });

      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCameraActive(true);

      if (navigator.mediaDevices.enumerateDevices) {
        const devices = await navigator.mediaDevices.enumerateDevices();
        setVideoDevices(devices.filter((d) => d.kind === 'videoinput'));
      }
    } catch (err) {
      const msg = (err as Error)?.message || 'Unable to access camera.';
      setCameraError(
        msg.toLowerCase().includes('permission') || msg.toLowerCase().includes('denied')
          ? 'Camera permission denied. Allow camera access in browser settings and tap Retry Camera.'
          : `Unable to start camera (${msg}).`
      );
      setCameraActive(false);
    }
  }, [facingMode, selectedDeviceId, stopCamera]);

  // Start / stop camera automatically when switching between NUMBER and QR/CAMERA modes
  useEffect(() => {
    if (mode === 'QR' || mode === 'CAMERA') {
      startCamera();
      if (mode === 'CAMERA') {
        dataService.listEnrolledFaces().then(setEnrolledFaces).catch(() => {});
        if (faceAutoRecognize) {
          loadFaceModels().then(() => setFaceModelsReady(true)).catch(() => setFaceModelsReady(false));
        }
      }
    } else {
      stopCamera();
      setCapturedPreview(null);
      setLastFaceMatch(null);
    }
    return () => {
      stopCamera();
    };
  }, [faceAutoRecognize, mode, startCamera, stopCamera]);

  const executePunch = useCallback(
    async (targetEmpNumber: string, snapshotDataUrl?: string | null) => {
      const cleaned = targetEmpNumber.trim().toUpperCase();
      if (!cleaned || submittingRef.current) return;

      submittingRef.current = true;
      setSubmitting(true);
      try {
        const snap =
          snapshotDataUrl !== undefined
            ? snapshotDataUrl
            : (mode === 'CAMERA' || (mode === 'QR' && capturePhotoOnPunch)) && cameraActive
            ? captureVideoFrame()
            : null;

        const res = await dataService.punchAttendanceByEmployeeNumber(cleaned, {
          pin: pin.trim() || undefined,
          source: 'KIOSK',
        });
        setResult(res);
        setResultSnapshot(res.success ? snap : null);
        if (res.success) {
          onPunchRecorded();
          setPin('');
          const refreshed = await dataService.lookupEmployeeByNumber(cleaned);
          setLookup(refreshed);
        }
      } finally {
        submittingRef.current = false;
        setSubmitting(false);
        if (mode === 'NUMBER') {
          inputRef.current?.focus();
        }
      }
    },
    [cameraActive, capturePhotoOnPunch, captureVideoFrame, mode, onPunchRecorded, pin]
  );

  // Continuous QR scanning loop while in QR mode & camera is active
  useEffect(() => {
    if (mode !== 'QR' || !cameraActive) return;

    let cancelled = false;
    const detector =
      typeof window !== 'undefined' && window.BarcodeDetector
        ? new window.BarcodeDetector({ formats: ['qr_code'] })
        : null;

    const handleDetectedQr = (rawValue: string) => {
      const extracted = extractEmployeeNumberFromQr(rawValue);
      if (!extracted) return;

      const now = Date.now();
      const isDuplicateBurst =
        lastScanRef.current.code === extracted && now - lastScanRef.current.at < 2800;
      if (isDuplicateBurst) return;

      lastScanRef.current = { code: extracted, at: now };
      setLastScannedCode(extracted);
      setEmployeeNumber(extracted);

      if (autoPunchQr && !submittingRef.current) {
        const snap = capturePhotoOnPunch ? captureVideoFrame() : null;
        executePunch(extracted, snap);
      }
    };

    const intervalId = window.setInterval(async () => {
      if (cancelled) return;
      const video = videoRef.current;
      if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) return;

      try {
        if (detector) {
          const codes = await detector.detect(video);
          const match = codes.find((c) => c.rawValue && c.rawValue.trim());
          if (match?.rawValue) {
            handleDetectedQr(match.rawValue);
            return;
          }
        }
      } catch {
        // Fallback to jsQR below if native BarcodeDetector fails on frame
      }

      const canvas = scanCanvasRef.current;
      if (!canvas) return;
      const targetW = Math.min(640, video.videoWidth);
      const targetH = Math.round((video.videoHeight / video.videoWidth) * targetW);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }
      const ctx = canvas.getContext('2d', { willReadFrequently: true });
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, targetW, targetH);
      const imageData = ctx.getImageData(0, 0, targetW, targetH);
      const decoded = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'dontInvert',
      });
      if (decoded?.data) {
        handleDetectedQr(decoded.data);
      }
    }, 180);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [autoPunchQr, cameraActive, capturePhotoOnPunch, captureVideoFrame, executePunch, mode]);

  // Continuous Face Recognition loop while in CAMERA mode
  useEffect(() => {
    if (mode !== 'CAMERA' || !cameraActive || !faceAutoRecognize || enrolledFaces.length === 0) return;

    let cancelled = false;
    let busy = false;

    const intervalId = window.setInterval(async () => {
      if (cancelled || busy || submittingRef.current) return;
      const video = videoRef.current;
      if (!video || video.readyState < 2 || !video.videoWidth || !video.videoHeight) return;

      busy = true;
      try {
        const detected = await detectFaceDescriptor(video);
        if (cancelled) return;
        setFaceModelsReady(true);
        if (!detected) return;

        const match = findBestFaceMatch(detected.descriptor, enrolledFaces, 0.54);
        if (!match) return;

        setLastFaceMatch(match);
        setEmployeeNumber(match.employee_number);

        const now = Date.now();
        const isCooldown =
          lastFacePunchRef.current.code === match.employee_number && now - lastFacePunchRef.current.at < 4000;
        if (!isCooldown && autoPunchFace) {
          lastFacePunchRef.current = { code: match.employee_number, at: now };
          const snap = captureVideoFrame();
          await executePunch(match.employee_number, snap);
        }
      } catch {
        // ignore transient frame read errors
      } finally {
        busy = false;
      }
    }, 650);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [autoPunchFace, cameraActive, captureVideoFrame, enrolledFaces, executePunch, faceAutoRecognize, mode]);

  async function enterFullscreen() {
    try {
      await (containerRef.current ?? document.documentElement).requestFullscreen();
    } catch {
      // browser blocked fullscreen
    }
  }

  async function exitFullscreen() {
    try {
      if (document.fullscreenElement) await document.exitFullscreen();
    } catch {
      // ignore
    }
  }

  async function handlePunch(e?: React.FormEvent) {
    e?.preventDefault();
    if (!employeeNumber.trim()) return;
    await executePunch(employeeNumber, mode === 'CAMERA' ? capturedPreview ?? captureVideoFrame() : undefined);
    setCapturedPreview(null);
  }

  return (
    <div
      ref={containerRef}
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-8"
    >
      {/* Kiosk Top Bar — zero admin/salary/payroll access */}
      <header className="max-w-5xl w-full mx-auto flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          {company.company_logo_url ? (
            <img
              src={company.company_logo_url}
              alt={company.company_name}
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-lg object-cover border border-slate-700"
            />
          ) : (
            <div className="w-10 h-10 rounded-lg bg-blue-600 text-white font-bold flex items-center justify-center">
              PL
            </div>
          )}
          <div>
            <h1 className="text-base font-bold text-white leading-tight">{company.company_name}</h1>
            <p className="text-xs text-slate-400">
              Entrance Attendance Kiosk · Employee Number, QR Scan &amp; Camera
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-xs">
            <span className="inline-flex items-center gap-1.5 text-slate-300">
              {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-400" /> : <WifiOff className="w-3.5 h-3.5 text-rose-400" />}
              {isOnline ? 'Network Connected' : 'Offline'}
            </span>
            <span className="text-slate-700">|</span>
            <span className="inline-flex items-center gap-1.5 text-slate-300">
              <Database className="w-3.5 h-3.5 text-blue-400" />
              {dataService.isLiveSupabase() ? 'Supabase Connected' : 'Local Preview DB'}
            </span>
          </div>

          <button
            type="button"
            onClick={() => setShowGuide((v) => !v)}
            className="px-3 py-2 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <Info className="w-3.5 h-3.5" />
            Setup Guide
          </button>

          {!isFullscreen ? (
            <button
              type="button"
              onClick={enterFullscreen}
              className="px-3 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
            >
              <Maximize2 className="w-3.5 h-3.5" />
              MAXIMIZE
            </button>
          ) : (
            <button
              type="button"
              onClick={exitFullscreen}
              className="px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
            >
              <Minimize2 className="w-3.5 h-3.5" />
              MINIMIZE
            </button>
          )}

          <button
            type="button"
            onClick={async () => {
              stopCamera();
              await exitFullscreen();
              onExitKiosk();
            }}
            className="px-3 py-2 text-xs font-semibold text-slate-200 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" />
            EXIT KIOSK
          </button>
        </div>
      </header>

      {showGuide && (
        <div className="max-w-5xl w-full mx-auto mt-4 p-4 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 space-y-1.5">
          <p className="font-semibold text-white">Kiosk Attendance Modes &amp; Device Setup</p>
          <p>
            • <strong>QR Scanner &amp; Camera:</strong> Allow browser camera permission to scan employee ID QR badges or capture verification photos during Time In / Time Out.
          </p>
          <p>
            • <strong>Windows:</strong> Set Power &amp; Sleep to Never, then launch Chrome/Edge with{' '}
            <code className="font-mono text-blue-300">--kiosk --edge-kiosk-type=fullscreen</code>.
          </p>
          <p>
            • <strong>Android Tablet:</strong> Enable &ldquo;Stay awake while charging&rdquo; in Developer Options and pin this screen via Android Screen Pinning.
          </p>
        </div>
      )}

      {/* Main Kiosk Center Stage */}
      <main className="max-w-5xl w-full mx-auto my-auto py-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
        <div className="md:col-span-5 text-center md:text-left space-y-3">
          <p className="text-xs font-semibold uppercase tracking-widest text-blue-400">
            Philippine Standard Time · Asia/Manila (24-Hr)
          </p>
          <div className="text-5xl sm:text-6xl font-mono font-bold tabular-nums text-white tracking-tight">
            {toManilaTime24(clock)}
          </div>
          <p className="text-lg text-slate-300 font-medium">{formatManilaDate(toManilaDateString(clock))}</p>
          <div className="pt-4 border-t border-slate-800 text-xs text-slate-400 space-y-1.5">
            <p>1. Choose Number Entry, QR Scanner, or Camera Check-In.</p>
            <p>2. Verify your displayed name or scan your Employee QR badge.</p>
            <p>3. 1st = Time In, 2nd = Time Out, 3rd = Time In (zero delay).</p>
          </div>
        </div>

        <div className="md:col-span-7 bg-slate-900 border border-slate-800 rounded-2xl p-6 sm:p-7 space-y-4">
          {/* Entry Mode Selector */}
          <div className="grid grid-cols-3 gap-2 p-1 rounded-xl bg-slate-950 border border-slate-800">
            <button
              type="button"
              onClick={() => setMode('NUMBER')}
              className={`py-2.5 px-3 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors ${
                mode === 'NUMBER'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <Keyboard className="w-3.5 h-3.5" />
              Employee Number
            </button>
            <button
              type="button"
              onClick={() => setMode('QR')}
              className={`py-2.5 px-3 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors ${
                mode === 'QR'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              QR Scanner
            </button>
            <button
              type="button"
              onClick={() => {
                setFacingMode('user');
                setSelectedDeviceId('');
                setMode('CAMERA');
              }}
              className={`py-2.5 px-3 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors ${
                mode === 'CAMERA'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'text-slate-300 hover:bg-slate-900 hover:text-white'
              }`}
            >
              <ScanFace className="w-3.5 h-3.5" />
              Face / Camera
            </button>
          </div>

          {result && (
            <div
              className={`rounded-xl border p-4 ${
                result.success ? 'bg-emerald-950/60 border-emerald-700' : 'bg-rose-950/60 border-rose-700'
              }`}
            >
              {result.success ? (
                <div className="flex items-center gap-4">
                  <Avatar name={result.full_name ?? 'Employee'} src={result.photo_url} size="lg" />
                  <div className="flex-1 min-w-0">
                    <div className="inline-flex items-center gap-1.5 text-emerald-400 text-xs font-bold">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>{result.event_type === 'TIME_IN' ? 'TIME IN RECORDED' : 'TIME OUT RECORDED'}</span>
                    </div>
                    <h2 className="text-lg font-bold text-white truncate">{result.full_name}</h2>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-300">
                      <span className="font-mono font-semibold text-white">{result.employee_number}</span>
                      <span>·</span>
                      <span className="font-mono tabular-nums">
                        {result.recorded_at ? toManilaTime24(result.recorded_at) : '—'}
                      </span>
                      {result.status && <StatusLabel label={result.status} />}
                    </div>
                  </div>
                  {resultSnapshot && (
                    <img
                      src={resultSnapshot}
                      alt="Captured check-in snapshot"
                      className="w-16 h-16 rounded-lg object-cover border border-emerald-500/60 shrink-0"
                    />
                  )}
                </div>
              ) : (
                <div className="flex items-start gap-3">
                  <XCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <h3 className="text-sm font-bold text-white">Attendance Not Recorded</h3>
                    <p className="text-xs text-rose-200 mt-0.5">{result.message}</p>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Live Camera Viewport for QR Scanner & Camera Check-In Modes */}
          {(mode === 'QR' || mode === 'CAMERA') && (
            <div className="rounded-xl border border-slate-700 bg-slate-950 p-3 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-2 text-slate-300 font-medium">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      cameraActive ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'
                    }`}
                  />
                  <span>
                    {mode === 'QR'
                      ? cameraActive
                        ? 'Scanning for Employee QR Code...'
                        : 'Starting QR Camera...'
                      : cameraActive
                      ? faceAutoRecognize && enrolledFaces.length > 0
                        ? faceModelsReady
                          ? `Face Recognition Active (${enrolledFaces.length} enrolled)`
                          : 'Loading Face Recognition Models...'
                        : 'Camera Ready for Check-In Photo'
                      : 'Starting Verification Camera...'}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-1.5">
                  {videoDevices.length > 1 && (
                    <select
                      value={selectedDeviceId}
                      onChange={(e) => setSelectedDeviceId(e.target.value)}
                      className="px-2 py-1 text-[11px] bg-slate-900 border border-slate-700 rounded-md text-slate-200 max-w-[140px]"
                    >
                      <option value="">Auto Camera</option>
                      {videoDevices.map((d, idx) => (
                        <option key={d.deviceId} value={d.deviceId}>
                          {d.label || `Camera ${idx + 1}`}
                        </option>
                      ))}
                    </select>
                  )}

                  <button
                    type="button"
                    onClick={() => {
                      setSelectedDeviceId('');
                      setFacingMode((prev) => (prev === 'environment' ? 'user' : 'environment'));
                    }}
                    className="px-2.5 py-1 text-[11px] font-medium bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-md text-slate-200 inline-flex items-center gap-1"
                  >
                    <SwitchCamera className="w-3.5 h-3.5" />
                    Flip
                  </button>

                  <button
                    type="button"
                    onClick={startCamera}
                    className="px-2.5 py-1 text-[11px] font-medium bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-md text-slate-200 inline-flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" />
                    Retry
                  </button>
                </div>
              </div>

              <div className="relative w-full aspect-video max-h-64 rounded-lg overflow-hidden bg-black border border-slate-800 flex items-center justify-center">
                <video
                  ref={videoRef}
                  muted
                  playsInline
                  autoPlay
                  className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
                />
                <canvas ref={scanCanvasRef} className="hidden" />

                {mode === 'QR' && cameraActive && (
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <div className="w-40 h-40 sm:w-48 sm:h-48 border-2 border-blue-400/90 rounded-xl shadow-[0_0_0_9999px_rgba(2,6,23,0.45)] relative">
                      <span className="absolute -top-6 left-1/2 -translate-x-1/2 whitespace-nowrap text-[11px] font-medium text-blue-200 bg-slate-950/80 px-2 py-0.5 rounded">
                        Align Employee QR Code
                      </span>
                    </div>
                  </div>
                )}

                {mode === 'CAMERA' && capturedPreview && (
                  <div className="absolute bottom-2 right-2 bg-slate-950/90 border border-emerald-500 rounded-lg p-1 flex items-center gap-2">
                    <img
                      src={capturedPreview}
                      alt="Captured snapshot preview"
                      className="w-12 h-12 rounded object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setCapturedPreview(null)}
                      className="text-[11px] px-2 py-1 text-slate-200 hover:text-white"
                    >
                      Retake
                    </button>
                  </div>
                )}

                {cameraError && (
                  <div className="absolute inset-0 bg-slate-950/95 p-4 flex flex-col items-center justify-center text-center gap-2.5">
                    <XCircle className="w-7 h-7 text-rose-400" />
                    <p className="text-xs text-rose-200 max-w-sm">{cameraError}</p>
                    <button
                      type="button"
                      onClick={startCamera}
                      className="px-3 py-1.5 text-xs font-semibold bg-blue-600 hover:bg-blue-700 text-white rounded-lg inline-flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      Retry Camera
                    </button>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-xs text-slate-300">
                {mode === 'QR' ? (
                  <div className="flex flex-wrap items-center gap-4">
                    <label className="inline-flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={autoPunchQr}
                        onChange={(e) => setAutoPunchQr(e.target.checked)}
                        className="rounded border-slate-600 bg-slate-900"
                      />
                      <span>Auto-punch on scan</span>
                    </label>
                    <label className="inline-flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={capturePhotoOnPunch}
                        onChange={(e) => setCapturePhotoOnPunch(e.target.checked)}
                        className="rounded border-slate-600 bg-slate-900"
                      />
                      <span>Save photo snapshot</span>
                    </label>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-3">
                    <button
                      type="button"
                      disabled={!cameraActive}
                      onClick={() => setCapturedPreview(captureVideoFrame())}
                      className="px-3 py-1.5 text-xs font-semibold bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-white border border-slate-700 rounded-lg inline-flex items-center gap-1.5"
                    >
                      <Camera className="w-3.5 h-3.5 text-blue-400" />
                      {capturedPreview ? 'Retake Snapshot' : 'Capture Photo'}
                    </button>
                    <label className="inline-flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={faceAutoRecognize}
                        onChange={(e) => setFaceAutoRecognize(e.target.checked)}
                        className="rounded border-slate-600 bg-slate-900"
                      />
                      <span>Face Recognition</span>
                    </label>
                    {faceAutoRecognize && (
                      <label className="inline-flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={autoPunchFace}
                          onChange={(e) => setAutoPunchFace(e.target.checked)}
                          className="rounded border-slate-600 bg-slate-900"
                        />
                        <span>Auto-punch match</span>
                      </label>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  onClick={() => setShowBadgeQrGenerator((v) => !v)}
                  className="text-[11px] font-medium text-blue-400 hover:text-blue-300 inline-flex items-center gap-1"
                >
                  <Sparkles className="w-3 h-3" />
                  {showBadgeQrGenerator ? 'Hide QR Badge Preview' : 'Show / Test Employee QR'}
                </button>
              </div>

              {mode === 'CAMERA' && lastFaceMatch && (
                <div className="text-[11px] text-emerald-300 bg-emerald-950/40 border border-emerald-800/60 rounded-lg px-3 py-1.5 flex items-center justify-between">
                  <span>
                    Face Matched: <strong>{lastFaceMatch.full_name}</strong> ({lastFaceMatch.employee_number}) ·{' '}
                    {lastFaceMatch.confidencePercent}% confidence
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      lastFacePunchRef.current = { code: '', at: 0 };
                      setLastFaceMatch(null);
                    }}
                    className="underline text-emerald-200 hover:text-white"
                  >
                    Ready for Next Scan
                  </button>
                </div>
              )}

              {mode === 'QR' && lastScannedCode && (
                <div className="text-[11px] text-emerald-300 bg-emerald-950/40 border border-emerald-800/60 rounded-lg px-3 py-1.5 flex items-center justify-between">
                  <span>
                    Last QR Scanned: <strong className="font-mono">{lastScannedCode}</strong>
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      lastScanRef.current = { code: '', at: 0 };
                      setLastScannedCode(null);
                    }}
                    className="underline text-emerald-200 hover:text-white"
                  >
                    Ready for Next Scan
                  </button>
                </div>
              )}

              {showBadgeQrGenerator && (
                <div className="p-3 rounded-lg bg-slate-900 border border-slate-700 flex flex-wrap items-center gap-4">
                  <div className="flex-1 min-w-[180px] space-y-1.5">
                    <label className="block text-[11px] font-medium text-slate-300">
                      Generate Scannable Employee QR Code
                    </label>
                    <input
                      type="text"
                      value={badgeQrInput}
                      onChange={(e) => setBadgeQrInput(e.target.value.toUpperCase())}
                      placeholder="EMP-2026-0001"
                      className="w-full px-3 py-1.5 text-xs font-mono bg-slate-950 text-white border border-slate-700 rounded-lg"
                    />
                    <p className="text-[10px] text-slate-400">
                      Printable QR codes are also embedded automatically on each Employee ID Card.
                    </p>
                  </div>
                  {badgeQrDataUrl && (
                    <div className="bg-white p-1.5 rounded-lg shrink-0">
                      <img src={badgeQrDataUrl} alt="Employee QR preview" className="w-24 h-24 block" />
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          <form onSubmit={handlePunch} className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-2">
                {mode === 'QR'
                  ? 'Scanned / Manual Employee Number'
                  : mode === 'CAMERA'
                  ? 'Employee Number (Camera Verification)'
                  : 'Employee Number'}
              </label>
              <input
                ref={inputRef}
                type="text"
                autoFocus={mode === 'NUMBER'}
                value={employeeNumber}
                onChange={(e) => setEmployeeNumber(e.target.value.toUpperCase())}
                placeholder={mode === 'QR' ? 'Scan QR badge or type Employee Number' : 'Enter Employee Number'}
                className="w-full px-4 py-3.5 text-xl sm:text-2xl font-mono font-bold tracking-wider bg-slate-950 text-white border border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>

            {/* Live Employee Name Display */}
            {employeeNumber.trim() && (
              <div className="rounded-xl border border-slate-700 bg-slate-950/90 px-4 py-3">
                {lookup?.found ? (
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <Avatar name={lookup.full_name ?? 'Employee'} src={lookup.photo_url} size="md" />
                      <div className="min-w-0">
                        <p className="text-sm font-bold text-white truncate">{lookup.full_name}</p>
                        <p className="text-xs text-slate-400 truncate">
                          <span className="font-mono text-slate-300">{lookup.employee_number}</span> · {lookup.position}
                        </p>
                      </div>
                    </div>
                    <StatusLabel
                      label={lookup.is_active === false ? 'INACTIVE' : `NEXT: ${lookup.next_event === 'TIME_OUT' ? 'TIME OUT' : 'TIME IN'}`}
                      tone={lookup.is_active === false ? 'red' : lookup.next_event === 'TIME_OUT' ? 'orange' : 'blue'}
                    />
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    No matching employee found for <span className="font-mono text-slate-200">{employeeNumber.trim()}</span>
                  </p>
                )}
              </div>
            )}

            {company.require_kiosk_pin && (
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1.5">PIN</label>
                <input
                  type="password"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  placeholder="Enter PIN"
                  className="w-full px-4 py-3 text-lg font-mono bg-slate-950 text-white border border-slate-700 rounded-xl"
                />
              </div>
            )}

            {mode === 'NUMBER' ? (
              <div className="grid grid-cols-4 gap-2 pt-1">
                {['1', '2', '3', 'EMP-', '4', '5', '6', '2026-', '7', '8', '9', '0'].map((k) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => {
                      setEmployeeNumber((p) => p + k);
                      inputRef.current?.focus();
                    }}
                    className="py-3.5 text-base font-mono font-semibold bg-slate-800 hover:bg-slate-700 text-white rounded-xl border border-slate-700"
                  >
                    {k}
                  </button>
                ))}
                <button
                  type="button"
                  onClick={() => setEmployeeNumber((p) => p.slice(0, -1))}
                  className="py-3.5 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700 inline-flex items-center justify-center"
                >
                  <Delete className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setEmployeeNumber('');
                    setLookup(null);
                    setResult(null);
                    setResultSnapshot(null);
                  }}
                  className="py-3.5 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700"
                >
                  Clear
                </button>
                <button
                  type="submit"
                  disabled={submitting || !employeeNumber.trim()}
                  className="col-span-2 py-3.5 px-4 text-base font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl inline-flex items-center justify-center gap-2"
                >
                  <CornerDownLeft className="w-5 h-5" />
                  {submitting
                    ? 'Saving...'
                    : lookup?.found
                    ? `Clock ${lookup.next_event === 'TIME_OUT' ? 'Out' : 'In'}`
                    : 'Clock In / Out'}
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setEmployeeNumber('');
                    setLookup(null);
                    setResult(null);
                    setResultSnapshot(null);
                    setCapturedPreview(null);
                    setLastScannedCode(null);
                    lastScanRef.current = { code: '', at: 0 };
                  }}
                  className="px-4 py-3.5 text-sm font-medium bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl border border-slate-700"
                >
                  Clear
                </button>
                <button
                  type="submit"
                  disabled={submitting || !employeeNumber.trim()}
                  className="flex-1 py-3.5 px-4 text-base font-semibold bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white rounded-xl inline-flex items-center justify-center gap-2"
                >
                  <CornerDownLeft className="w-5 h-5" />
                  {submitting
                    ? 'Saving...'
                    : mode === 'CAMERA'
                    ? lookup?.found
                      ? `Capture & Clock ${lookup.next_event === 'TIME_OUT' ? 'Out' : 'In'}`
                      : 'Capture & Clock In / Out'
                    : lookup?.found
                    ? `Clock ${lookup.next_event === 'TIME_OUT' ? 'Out' : 'In'}`
                    : 'Clock In / Out'}
                </button>
              </div>
            )}
          </form>
        </div>
      </main>

      <footer className="max-w-5xl w-full mx-auto text-xs text-slate-500 flex items-center justify-between border-t border-slate-800 pt-4">
        <span>Kiosk Session Locked to Attendance Entry Only</span>
        <span>Timezone: Asia/Manila (24-Hour Format)</span>
      </footer>
    </div>
  );
}
