import React, { useEffect, useState } from 'react';
import { UserPlus, Settings, RefreshCw, Upload, Sun, Moon, Palette } from 'lucide-react';
import { EmptyState, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type {
  AuditLog,
  CompanySettings,
  Employee,
  IntegrationSyncItem,
  Schedule,
  UserProfile,
  UserRole,
} from '../../types/database';

const inputCls =
  'w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-950 text-slate-900 dark:text-slate-100';

export function UserAccountsPage({
  actor,
  profiles,
  employees,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  profiles: UserProfile[];
  employees: Employee[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<UserRole>('EMPLOYEE');
  const [employeeId, setEmployeeId] = useState('');
  const [canEditSalary, setCanEditSalary] = useState(false);
  const [canManagePayroll, setCanManagePayroll] = useState(false);
  const [canManageHolidays, setCanManageHolidays] = useState(false);
  const [creating, setCreating] = useState(false);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    const linkedEmp = employees.find((x) => x.id === employeeId) ?? null;
    setCreating(true);
    try {
      await dataService.createUserAccount(actor, {
        email: email.trim(),
        password,
        full_name: fullName.trim() || linkedEmp?.full_name || 'Staff User',
        role,
        employee_id: linkedEmp?.id ?? null,
        employee_number: linkedEmp?.employee_number ?? null,
        department: linkedEmp?.department ?? null,
        position: linkedEmp?.position ?? null,
        phone: linkedEmp?.contact_number ?? null,
        permissions: {
          can_edit_salary: role === 'SUPER_ADMIN' || canEditSalary,
          can_manage_payroll: role === 'SUPER_ADMIN' || canManagePayroll,
          can_manage_holidays: role === 'SUPER_ADMIN' || canManageHolidays,
          can_view_reports: role !== 'EMPLOYEE',
        },
      });
      setEmail('');
      setPassword('');
      setFullName('');
      onNotify('success', 'User Account Created', 'Profile data saved to database.');
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to create account', (err as Error).message);
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">User Accounts &amp; Role Access</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          All user accounts use Supabase Email &amp; Password authentication (no Google Auth) with profile data stored in{' '}
          <code className="font-mono">public.profiles</code>.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleCreate}
          className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-3.5 text-xs shadow-sm dark:shadow-lg dark:shadow-black/30"
        >
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Create User Account</h2>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
              Link Employee Record (optional)
            </label>
            <select
              value={employeeId}
              onChange={(e) => {
                setEmployeeId(e.target.value);
                const emp = employees.find((x) => x.id === e.target.value);
                if (emp) {
                  setFullName(emp.full_name);
                  if (emp.email) setEmail(emp.email);
                }
              }}
              className={inputCls}
            >
              <option value="">— No linked employee —</option>
              {employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.employee_number} — {e.full_name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Full Name *</label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Email *</label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Initial Password *</label>
            <input
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={inputCls}
            />
          </div>
          <div>
            <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Role</label>
            <select
              value={role}
              onChange={(e) => setRole(e.target.value as UserRole)}
              className={inputCls}
            >
              <option value="EMPLOYEE">Employee</option>
              <option value="HR">HR</option>
              <option value="ADMIN">Admin</option>
              <option value="SUPER_ADMIN">Super Admin</option>
            </select>
          </div>

          {(role === 'ADMIN' || role === 'HR') && (
            <div className="space-y-1.5 pt-1 text-slate-700 dark:text-slate-300">
              <p className="font-medium">Explicit Module Authorizations</p>
              <label className="flex items-center gap-2">
                <input type="checkbox" checked={canEditSalary} onChange={(e) => setCanEditSalary(e.target.checked)} />
                Authorize Salary Management
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={canManagePayroll}
                  onChange={(e) => setCanManagePayroll(e.target.checked)}
                />
                Authorize Payroll Processing
              </label>
              <label className="flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={canManageHolidays}
                  onChange={(e) => setCanManageHolidays(e.target.checked)}
                />
                Authorize Holiday Management
              </label>
            </div>
          )}

          <button
            type="submit"
            disabled={creating}
            className="w-full py-2.5 px-4 font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center justify-center gap-1.5"
          >
            <UserPlus className="w-3.5 h-3.5" />
            {creating ? 'Creating...' : 'Create Account'}
          </button>
        </form>

        <div className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 overflow-x-auto shadow-sm dark:shadow-lg dark:shadow-black/30">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">Database User Profiles</h2>
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-medium">
                <th className="py-2 pr-3">Name &amp; Email</th>
                <th className="py-2 px-3">Role</th>
                <th className="py-2 px-3">Employee #</th>
                <th className="py-2 px-3">Permissions</th>
                <th className="py-2 pl-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {profiles.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60">
                  <td className="py-2.5 pr-3">
                    <p className="font-semibold text-slate-900 dark:text-slate-100">{p.full_name}</p>
                    <p className="text-slate-500 dark:text-slate-400">{p.email}</p>
                  </td>
                  <td className="py-2.5 px-3">
                    <StatusLabel label={p.role} tone={p.role === 'SUPER_ADMIN' ? 'purple' : 'blue'} />
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-800 dark:text-slate-200">
                    {p.employee_number || '—'}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-300">
                    {[
                      p.permissions.can_edit_salary && 'Salary',
                      p.permissions.can_manage_payroll && 'Payroll',
                      p.permissions.can_manage_holidays && 'Holidays',
                    ]
                      .filter(Boolean)
                      .join(', ') || 'Standard'}
                  </td>
                  <td className="py-2.5 pl-3 text-right">
                    <button
                      type="button"
                      disabled={p.id === actor.id}
                      onClick={async () => {
                        await dataService.updateUserAccount(actor, p.id, { is_active: !p.is_active });
                        onNotify('success', 'Account Status Updated', `${p.full_name} updated.`);
                        onReload();
                      }}
                      className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline disabled:opacity-40"
                    >
                      {p.is_active ? 'Active (Deactivate)' : 'Inactive (Restore)'}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export function IntegrationsPage({
  actor,
  syncQueue,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  syncQueue: IntegrationSyncItem[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const tabs = [
    'Employees',
    'Attendance Logs',
    'Daily Reports',
    'Weekly Reports',
    'Monthly Reports',
    'Salary Records',
    'Payroll',
    'Overtime Requests',
    'Holiday Records',
    'Company Settings',
    'Audit Logs',
  ];

  async function testQueueSync() {
    await dataService.queueGoogleSheetsSync(actor, 'Attendance Logs', 'TEST_SYNC', actor.id, {
      triggered_at: new Date().toISOString(),
    });
    onNotify('success', 'Sync Task Queued', 'Checked integration queue. Supabase records remain primary.');
    onReload();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
            Optional Integrations (Google Sheets)
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Supabase is the primary source of truth. If Google Sheets secrets are unconfigured, all attendance &amp;
            payroll features continue normally.
          </p>
        </div>
        <button
          type="button"
          onClick={testQueueSync}
          className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Run Sync Check
        </button>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 space-y-3 shadow-sm dark:shadow-lg dark:shadow-black/30">
        <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
          Supported Spreadsheet Tabs (Idempotent Queue)
        </h2>
        <div className="flex flex-wrap gap-2 text-xs text-slate-700 dark:text-slate-300">
          {tabs.map((t) => (
            <span
              key={t}
              className="px-2.5 py-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded"
            >
              {t}
            </span>
          ))}
        </div>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          Configure <code className="font-mono">GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON</code> and{' '}
          <code className="font-mono">GOOGLE_SHEETS_SPREADSHEET_ID</code> exclusively inside Supabase Edge Function
          secrets.
        </p>
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 shadow-sm dark:shadow-lg dark:shadow-black/30">
        <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100 mb-3">Synchronization Queue</h2>
        {syncQueue.length === 0 ? (
          <EmptyState title="Sync queue is empty" description="Queued synchronization tasks appear here." />
        ) : (
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400">
                <th className="py-2 pr-3">Tab</th>
                <th className="py-2 px-3">Idempotency Key</th>
                <th className="py-2 px-3">Status</th>
                <th className="py-2 pl-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {syncQueue.map((item) => (
                <tr key={item.id}>
                  <td className="py-2.5 pr-3 font-medium text-slate-900 dark:text-slate-100">{item.sheet_tab}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-500 dark:text-slate-400">{item.idempotency_key}</td>
                  <td className="py-2.5 px-3">
                    <StatusLabel label={item.status} />
                  </td>
                  <td className="py-2.5 pl-3 text-slate-600 dark:text-slate-300">{item.last_error || 'Synced'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export function AuditLogsPage({ auditLogs }: { auditLogs: AuditLog[] }) {
  const [filter, setFilter] = useState('');
  const filtered = auditLogs.filter(
    (a) =>
      !filter.trim() ||
      a.action.toLowerCase().includes(filter.toLowerCase()) ||
      a.table_name.toLowerCase().includes(filter.toLowerCase()) ||
      (a.reason ?? '').toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Audit Logs</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            Immutable record of employee changes, salary history, corrections, overtime approvals, and payroll actions.
          </p>
        </div>
        <input
          type="text"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="Filter by action, table, reason..."
          className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 w-64"
        />
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-4 overflow-x-auto shadow-sm dark:shadow-lg dark:shadow-black/30">
        {filtered.length === 0 ? (
          <EmptyState title="No audit logs" description="System actions are recorded automatically." />
        ) : (
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-700 text-slate-500 dark:text-slate-400 font-medium">
                <th className="py-2 pr-3">Timestamp</th>
                <th className="py-2 px-3">Actor / Role</th>
                <th className="py-2 px-3">Action</th>
                <th className="py-2 px-3">Table / Record</th>
                <th className="py-2 pl-3">Reason / Summary</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60">
                  <td className="py-2.5 pr-3 font-mono whitespace-nowrap text-slate-500 dark:text-slate-400">
                    {formatManilaDate(log.created_at)}
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="font-medium text-slate-900 dark:text-slate-100">
                      {log.actor_name || log.actor_user_id?.slice(0, 8)}
                    </span>
                    <span className="text-slate-500 dark:text-slate-400 ml-1">· {log.actor_role}</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono font-semibold text-blue-700 dark:text-blue-400">{log.action}</td>
                  <td className="py-2.5 px-3 font-mono text-slate-600 dark:text-slate-300">{log.table_name}</td>
                  <td className="py-2.5 pl-3 text-slate-600 dark:text-slate-300">
                    {log.reason || JSON.stringify(log.new_value ?? {})}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}

export function CompanySettingsPage({
  actor,
  company,
  schedules,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  company: CompanySettings;
  schedules: Schedule[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [form, setForm] = useState<CompanySettings>(company);
  const [schedName, setSchedName] = useState('');
  const [schedIn, setSchedIn] = useState('08:00');
  const [schedOut, setSchedOut] = useState('17:00');
  const [schedOvernight, setSchedOvernight] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm(company);
  }, [company]);

  const activeTheme: 'light' | 'dark' | 'colorful' =
    form.theme === 'dark' ? 'dark' : form.theme === 'colorful' ? 'colorful' : 'light';

  async function handleThemeSwitch(nextTheme: 'light' | 'dark' | 'colorful') {
    const updated = { ...form, theme: nextTheme };
    setForm(updated);
    document.documentElement.classList.toggle('dark', nextTheme === 'dark');
    document.documentElement.classList.toggle('colorful', nextTheme === 'colorful');
    try {
      await dataService.updateCompanySettings(actor, updated);
      const label = nextTheme === 'dark' ? 'Dark' : nextTheme === 'colorful' ? 'Colorful' : 'Light';
      onNotify('success', `${label} Theme Active`, 'Workspace appearance updated.');
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to update theme', (err as Error).message);
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await dataService.updateCompanySettings(actor, form);
      onNotify('success', 'Company Settings Saved', 'Default schedule, theme, and attendance rules updated.');
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to save settings', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function handleAddSchedule(e: React.FormEvent) {
    e.preventDefault();
    if (!schedName.trim()) return;
    try {
      await dataService.createSchedule(actor, {
        name: schedName.trim(),
        time_in: `${schedIn}:00`,
        time_out: `${schedOut}:00`,
        lunch_break_minutes: form.lunch_break_minutes,
        grace_period_minutes: form.grace_period_minutes,
        regular_hours: form.regular_working_hours,
        is_flexible: false,
        is_overnight: schedOvernight,
        is_default: false,
      });
      setSchedName('');
      onNotify('success', 'Schedule Created', `${schedName} added to schedules.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to create schedule', (err as Error).message);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">Company Settings &amp; Work Schedules</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          Configure appearance theme (Light / Dark / Colorful), company identity, Asia/Manila timezone, default schedule,
          and payslip notes.
        </p>
      </div>

      {/* Theme Appearance Card */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-5 shadow-sm dark:shadow-lg dark:shadow-black/30">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Workspace Theme Appearance</h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Switch between crisp Light mode, high-contrast Dark mode, or vibrant Colorful theme across cards, sidebar, and tables.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            <button
              type="button"
              onClick={() => handleThemeSwitch('light')}
              className={`px-4 py-2.5 rounded-lg border text-xs font-semibold inline-flex items-center justify-center gap-2 transition ${
                activeTheme === 'light'
                  ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                  : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Sun className="w-4 h-4" />
              Light Theme
            </button>
            <button
              type="button"
              onClick={() => handleThemeSwitch('dark')}
              className={`px-4 py-2.5 rounded-lg border text-xs font-semibold inline-flex items-center justify-center gap-2 transition ${
                activeTheme === 'dark'
                  ? 'bg-slate-900 text-white border-slate-700 shadow-sm'
                  : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Moon className="w-4 h-4" />
              Dark Theme
            </button>
            <button
              type="button"
              onClick={() => handleThemeSwitch('colorful')}
              className={`px-4 py-2.5 rounded-lg border text-xs font-semibold inline-flex items-center justify-center gap-2 transition ${
                activeTheme === 'colorful'
                  ? 'bg-gradient-to-r from-indigo-600 via-fuchsia-600 to-amber-500 text-white border-transparent shadow-md'
                  : 'bg-gradient-to-r from-indigo-50 via-pink-50 to-amber-50 dark:from-slate-900 dark:to-slate-900 text-indigo-700 dark:text-pink-300 border-indigo-200 dark:border-slate-700 hover:from-indigo-100 hover:to-pink-100'
              }`}
            >
              <Palette className="w-4 h-4" />
              Colorful Theme
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-6 space-y-4 text-xs shadow-sm dark:shadow-lg dark:shadow-black/30"
        >
          <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Company &amp; Attendance Configuration
            </h2>
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-lg cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200">
              <Upload className="w-3.5 h-3.5" />
              Upload Logo
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={async (e) => {
                  const f = e.target.files?.[0];
                  if (!f) return;
                  const url = await dataService.uploadCompanyLogo(f);
                  setForm({ ...form, company_logo_url: url });
                }}
              />
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Company Name</label>
              <input
                type="text"
                value={form.company_name}
                onChange={(e) => setForm({ ...form, company_name: e.target.value })}
                className={inputCls}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Company Email</label>
              <input
                type="email"
                value={form.company_email}
                onChange={(e) => setForm({ ...form, company_email: e.target.value })}
                className={inputCls}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Contact Number</label>
              <input
                type="text"
                value={form.contact_number}
                onChange={(e) => setForm({ ...form, contact_number: e.target.value })}
                className={inputCls}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Timezone</label>
              <input
                type="text"
                value={form.timezone}
                onChange={(e) => setForm({ ...form, timezone: e.target.value })}
                className={`${inputCls} font-mono`}
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Company Address</label>
              <input
                type="text"
                value={form.company_address}
                onChange={(e) => setForm({ ...form, company_address: e.target.value })}
                className={inputCls}
              />
            </div>
            <div className="sm:col-span-2">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Payslip Footer Note (Printed on 80mm Payslips)
              </label>
              <input
                type="text"
                value={form.payslip_note ?? ''}
                onChange={(e) => setForm({ ...form, payslip_note: e.target.value })}
                placeholder="e.g. DEDUCTION ON SSS & PHIC SHARE (FULL FOR NOVEMBER)- 0%"
                className={inputCls}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Default Time In</label>
              <input
                type="time"
                value={form.default_time_in.slice(0, 5)}
                onChange={(e) => setForm({ ...form, default_time_in: `${e.target.value}:00` })}
                className={`${inputCls} font-mono`}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Default Time Out</label>
              <input
                type="time"
                value={form.default_time_out.slice(0, 5)}
                onChange={(e) => setForm({ ...form, default_time_out: `${e.target.value}:00` })}
                className={`${inputCls} font-mono`}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Unpaid Lunch Break (min)
              </label>
              <input
                type="number"
                value={form.lunch_break_minutes}
                onChange={(e) => setForm({ ...form, lunch_break_minutes: Number(e.target.value) })}
                className={`${inputCls} font-mono`}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Grace Period (min)</label>
              <input
                type="number"
                value={form.grace_period_minutes}
                onChange={(e) => setForm({ ...form, grace_period_minutes: Number(e.target.value) })}
                className={`${inputCls} font-mono`}
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Payroll Schedule</label>
              <select
                value={form.payroll_schedule}
                onChange={(e) =>
                  setForm({ ...form, payroll_schedule: e.target.value as CompanySettings['payroll_schedule'] })
                }
                className={inputCls}
              >
                <option value="WEEKLY">Weekly</option>
                <option value="SEMI_MONTHLY">Semi-Monthly</option>
                <option value="MONTHLY">Monthly</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                Employee Number Prefix
              </label>
              <input
                type="text"
                value={form.employee_number_prefix}
                onChange={(e) => setForm({ ...form, employee_number_prefix: e.target.value.toUpperCase() })}
                className={`${inputCls} font-mono`}
              />
            </div>
          </div>

          <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300 pt-1">
            <input
              type="checkbox"
              checked={form.require_kiosk_pin}
              onChange={(e) => setForm({ ...form, require_kiosk_pin: e.target.checked })}
            />
            Show PIN prompt on Attendance Terminal &amp; Kiosk
          </label>

          <button
            type="submit"
            disabled={saving}
            className="px-4 py-2.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center gap-1.5"
          >
            <Settings className="w-3.5 h-3.5" />
            {saving ? 'Saving...' : 'Save Company Settings'}
          </button>
        </form>

        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-xl p-6 space-y-4 text-xs shadow-sm dark:shadow-lg dark:shadow-black/30">
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Work Schedules (Day / Overnight)
          </h2>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {schedules.map((s) => (
              <div key={s.id} className="py-2.5 flex items-center justify-between">
                <div>
                  <p className="font-semibold text-slate-900 dark:text-slate-100">{s.name}</p>
                  <p className="font-mono text-slate-500 dark:text-slate-400">
                    {s.time_in.slice(0, 5)} – {s.time_out.slice(0, 5)} · {s.lunch_break_minutes}m lunch
                    {s.is_overnight ? ' · Overnight' : ''}
                  </p>
                </div>
                {s.is_default && <StatusLabel label="DEFAULT" tone="blue" />}
              </div>
            ))}
          </div>

          <form onSubmit={handleAddSchedule} className="pt-4 border-t border-slate-100 dark:border-slate-800 space-y-3">
            <h3 className="font-semibold text-slate-900 dark:text-slate-100">Add Custom Schedule</h3>
            <input
              type="text"
              required
              value={schedName}
              onChange={(e) => setSchedName(e.target.value)}
              placeholder="e.g. Mid Shift (1:00 PM - 10:00 PM)"
              className={inputCls}
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="time"
                value={schedIn}
                onChange={(e) => setSchedIn(e.target.value)}
                className={`${inputCls} font-mono`}
              />
              <input
                type="time"
                value={schedOut}
                onChange={(e) => setSchedOut(e.target.value)}
                className={`${inputCls} font-mono`}
              />
            </div>
            <label className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
              <input
                type="checkbox"
                checked={schedOvernight}
                onChange={(e) => setSchedOvernight(e.target.checked)}
              />
              Overnight shift (Time Out falls on next calendar day)
            </label>
            <button
              type="submit"
              className="w-full py-2 px-3 font-semibold text-white bg-slate-900 dark:bg-blue-600 hover:bg-slate-800 dark:hover:bg-blue-700 rounded-lg"
            >
              Add Schedule
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
