import React, { useMemo, useState } from 'react';
import { Download, Printer, Search, Clock } from 'lucide-react';
import { Avatar, EmptyState, StatusLabel } from '../../components/ui/Common';
import { DailyStatusBreakdownBar, DepartmentAttendanceChart } from '../../components/charts/AttendanceCharts';
import { formatManilaDate, formatManilaTime, formatPeso, toManilaDateString } from '../../lib/date/manila';
import { exportTableToPdf, exportToCsv, exportToExcel } from '../../lib/export/exporters';
import type {
  AttendanceRecord,
  Employee,
  LeaveRequest,
  OvertimeRequest,
  UserProfile,
} from '../../types/database';

export function DashboardPage({
  actor,
  employees,
  attendance,
  overtimeRequests,
  leaveRequests,
  onOpenTerminal,
}: {
  actor: UserProfile;
  employees: Employee[];
  attendance: AttendanceRecord[];
  overtimeRequests: OvertimeRequest[];
  leaveRequests: LeaveRequest[];
  onOpenTerminal: () => void;
}) {
  const [selectedDate, setSelectedDate] = useState(() => toManilaDateString());
  const [search, setSearch] = useState('');
  const [deptFilter, setDeptFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [sortBy, setSortBy] = useState<'name' | 'time_in' | 'late'>('name');
  const [page, setPage] = useState(1);
  const pageSize = 10;

  const canSeeEarnings =
    actor.role === 'SUPER_ADMIN' || actor.permissions.can_edit_salary || actor.permissions.can_manage_payroll;

  const activeEmployees = useMemo(() => employees.filter((e) => e.is_active), [employees]);
  const departments = useMemo(
    () => Array.from(new Set(activeEmployees.map((e) => e.department))).sort(),
    [activeEmployees]
  );

  const dayRows = useMemo(() => {
    const attByEmp = new Map(
      attendance.filter((a) => a.work_date === selectedDate).map((a) => [a.employee_id, a])
    );
    const otByEmp = new Map(
      overtimeRequests
        .filter((o) => o.work_date === selectedDate && o.decision === 'YES')
        .map((o) => [o.employee_id, o])
    );

    return activeEmployees.map((emp) => {
      const att = attByEmp.get(emp.id) ?? null;
      const ot = otByEmp.get(emp.id) ?? null;
      const onLeave = leaveRequests.some(
        (l) => l.employee_id === emp.id && l.status === 'APPROVED' && selectedDate >= l.start_date && selectedDate <= l.end_date
      );
      const effectiveStatus = att
        ? att.status
        : onLeave
        ? 'LEAVE'
        : 'ABSENT';

      const estDailyEarnings =
        att && att.actual_time_in
          ? emp.salary_type === 'HOURLY'
            ? (att.regular_hours || 8) * emp.hourly_rate
            : emp.daily_rate > 0
            ? emp.daily_rate
            : emp.salary_type === 'WEEKLY'
            ? (emp.weekly_rate ?? 0) / 6
            : emp.monthly_rate / 22
          : 0;

      return {
        employee: emp,
        att,
        ot,
        effectiveStatus,
        estDailyEarnings,
      };
    });
  }, [activeEmployees, attendance, overtimeRequests, leaveRequests, selectedDate]);

  const kpis = useMemo(() => {
    let present = 0;
    let onTime = 0;
    let late = 0;
    let absent = 0;
    let onLeave = 0;
    let withOvertime = 0;
    let notTimedOut = 0;

    for (const r of dayRows) {
      if (r.att?.actual_time_in) {
        present += 1;
        if (r.att.late_minutes > 0) late += 1;
        else onTime += 1;
        if (!r.att.actual_time_out) notTimedOut += 1;
        if (r.att.approved_overtime_hours > 0 || r.ot?.status === 'APPROVED') withOvertime += 1;
      } else if (r.effectiveStatus === 'LEAVE') {
        onLeave += 1;
      } else {
        absent += 1;
      }
    }
    return {
      total: activeEmployees.length,
      present,
      onTime,
      late,
      absent,
      onLeave,
      withOvertime,
      notTimedOut,
    };
  }, [dayRows, activeEmployees.length]);

  const filtered = useMemo(() => {
    return dayRows
      .filter((r) => {
        if (deptFilter !== 'ALL' && r.employee.department !== deptFilter) return false;
        if (statusFilter !== 'ALL' && r.effectiveStatus !== statusFilter) return false;
        if (search.trim()) {
          const q = search.toLowerCase();
          return (
            r.employee.full_name.toLowerCase().includes(q) ||
            r.employee.employee_number.toLowerCase().includes(q) ||
            r.employee.position.toLowerCase().includes(q)
          );
        }
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'late') return (b.att?.late_minutes ?? 0) - (a.att?.late_minutes ?? 0);
        if (sortBy === 'time_in') {
          return (a.att?.actual_time_in ?? '9999').localeCompare(b.att?.actual_time_in ?? '9999');
        }
        return a.employee.full_name.localeCompare(b.employee.full_name);
      });
  }, [dayRows, deptFilter, statusFilter, search, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const paged = filtered.slice((page - 1) * pageSize, page * pageSize);

  function buildExportRows() {
    return filtered.map((r) => {
      const base: Record<string, string | number> = {
        Date: selectedDate,
        'Employee Number': r.employee.employee_number,
        Name: r.employee.full_name,
        Position: r.employee.position,
        Department: r.employee.department,
        'Time In': formatManilaTime(r.att?.actual_time_in),
        'Time Out': formatManilaTime(r.att?.actual_time_out),
        'Late (min)': r.att?.late_minutes ?? 0,
        'Undertime (min)': r.att?.undertime_minutes ?? 0,
        'Regular Hrs': r.att?.regular_hours ?? 0,
        'OT Hrs': r.att?.approved_overtime_hours ?? 0,
        Status: r.effectiveStatus,
      };
      if (canSeeEarnings) {
        base['Est. Daily Earnings (PHP)'] = Number(r.estDailyEarnings.toFixed(2));
      }
      return base;
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 inline-block cursor-pointer rounded-md px-1.5 -mx-1.5 py-0.5 transition-colors hover:bg-blue-100/80 dark:hover:bg-blue-900/50 hover:text-blue-700 dark:hover:text-blue-300">
            Live Attendance Dashboard
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
            {formatManilaDate(selectedDate)} · Asia/Manila (24-Hr) real-time monitoring
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2 no-print">
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => {
              setSelectedDate(e.target.value);
              setPage(1);
            }}
            className="px-3 py-2 text-xs font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-2xs"
          />
          {actor.role !== 'HR' && (
            <button
              type="button"
              onClick={onOpenTerminal}
              className="px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 colorful:bg-gradient-to-r colorful:from-indigo-600 colorful:via-purple-600 colorful:to-pink-600 rounded-lg shadow-xs colorful:shadow-md inline-flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Clock className="w-3.5 h-3.5" />
              Attendance Terminal
            </button>
          )}
        </div>
      </div>

      {/* 8 KPI Cards with shadow & borders for light, dark, and colorful themes */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {[
          {
            label: 'Total Employees',
            value: kpis.total,
            accent: 'text-slate-900 dark:text-slate-100 colorful:text-indigo-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-indigo-100 colorful:!to-blue-50 colorful:!border-indigo-300',
          },
          {
            label: 'Present Today',
            value: kpis.present,
            accent: 'text-emerald-700 dark:text-emerald-400 colorful:text-emerald-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-emerald-100 colorful:!to-teal-50 colorful:!border-emerald-300',
          },
          {
            label: 'On Time',
            value: kpis.onTime,
            accent: 'text-emerald-700 dark:text-emerald-400 colorful:text-teal-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-teal-100 colorful:!to-cyan-50 colorful:!border-teal-300',
          },
          {
            label: 'Late Today',
            value: kpis.late,
            accent: 'text-rose-700 dark:text-rose-400 colorful:text-rose-700',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-rose-100 colorful:!to-pink-50 colorful:!border-rose-300',
          },
          {
            label: 'Absent',
            value: kpis.absent,
            accent: 'text-slate-700 dark:text-slate-300 colorful:text-slate-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-orange-100 colorful:!to-amber-50 colorful:!border-orange-300',
          },
          {
            label: 'On Leave',
            value: kpis.onLeave,
            accent: 'text-blue-700 dark:text-blue-400 colorful:text-sky-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-sky-100 colorful:!to-indigo-50 colorful:!border-sky-300',
          },
          {
            label: 'With Overtime',
            value: kpis.withOvertime,
            accent: 'text-amber-700 dark:text-amber-400 colorful:text-amber-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-amber-100 colorful:!to-yellow-50 colorful:!border-amber-300',
          },
          {
            label: 'Not Timed Out',
            value: kpis.notTimedOut,
            accent: 'text-violet-700 dark:text-violet-400 colorful:text-fuchsia-800',
            colorfulBg: 'colorful:!bg-gradient-to-br colorful:!from-fuchsia-100 colorful:!to-purple-50 colorful:!border-fuchsia-300',
          },
        ].map((card) => (
          <div
            key={card.label}
            className={`group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 colorful:shadow-md rounded-lg p-3.5 transition-all hover:border-blue-300 dark:hover:border-blue-600 ${card.colorfulBg}`}
          >
            <p className="text-xs text-slate-500 dark:text-slate-400 colorful:text-slate-700 colorful:font-semibold truncate cursor-pointer rounded px-1 -mx-1 transition-colors group-hover:text-blue-700 dark:group-hover:text-blue-300 group-hover:bg-blue-50 dark:group-hover:bg-blue-950/50">
              {card.label}
            </p>
            <p className={`text-2xl font-mono font-bold tabular-nums mt-1 ${card.accent}`}>{card.value}</p>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <DailyStatusBreakdownBar
          counts={{
            onTime: kpis.onTime,
            late: kpis.late,
            overtime: kpis.withOvertime,
            leave: kpis.onLeave,
            absent: kpis.absent,
          }}
        />
        <DepartmentAttendanceChart
          employees={activeEmployees}
          todayRecords={attendance.filter((a) => a.work_date === selectedDate)}
        />
      </div>

      {/* Filter & Export Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-lg p-4 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3 no-print">
          <div className="flex flex-wrap items-center gap-2 flex-1 min-w-[260px]">
            <div className="relative flex-1 min-w-[200px] max-w-xs">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
                placeholder="Search name or Employee Number..."
                className="w-full pl-9 pr-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-2xs"
              />
            </div>
            <select
              value={deptFilter}
              onChange={(e) => {
                setDeptFilter(e.target.value);
                setPage(1);
              }}
              className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-2xs"
            >
              <option value="ALL">All Departments</option>
              {departments.map((d) => (
                <option key={d} value={d}>
                  {d}
                </option>
              ))}
            </select>
            <select
              value={statusFilter}
              onChange={(e) => {
                setStatusFilter(e.target.value);
                setPage(1);
              }}
              className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-2xs"
            >
              <option value="ALL">All Statuses</option>
              <option value="ON_TIME">On Time</option>
              <option value="LATE">Late</option>
              <option value="OVERTIME">Overtime</option>
              <option value="LEAVE">On Leave</option>
              <option value="ABSENT">Absent</option>
            </select>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as 'name' | 'time_in' | 'late')}
              className="px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 shadow-2xs"
            >
              <option value="name">Sort: Name</option>
              <option value="time_in">Sort: Time In</option>
              <option value="late">Sort: Most Late</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => exportToExcel(`Attendance_${selectedDate}.xlsx`, 'Attendance', buildExportRows())}
              className="px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs inline-flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              Excel
            </button>
            <button
              type="button"
              onClick={() => exportToCsv(`Attendance_${selectedDate}.csv`, buildExportRows())}
              className="px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs"
            >
              CSV
            </button>
            <button
              type="button"
              onClick={() => {
                const cols = [
                  'Emp #',
                  'Name',
                  'Dept',
                  'In',
                  'Out',
                  'Late',
                  'UT',
                  'Reg Hrs',
                  'OT Hrs',
                  'Status',
                ];
                const body = filtered.map((r) => [
                  r.employee.employee_number,
                  r.employee.full_name,
                  r.employee.department,
                  formatManilaTime(r.att?.actual_time_in),
                  formatManilaTime(r.att?.actual_time_out),
                  `${r.att?.late_minutes ?? 0}m`,
                  `${r.att?.undertime_minutes ?? 0}m`,
                  r.att?.regular_hours ?? 0,
                  r.att?.approved_overtime_hours ?? 0,
                  r.effectiveStatus,
                ]);
                exportTableToPdf(
                  `Attendance_${selectedDate}.pdf`,
                  'Daily Attendance Monitoring',
                  `Date: ${formatManilaDate(selectedDate)}`,
                  cols,
                  body
                );
              }}
              className="px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs"
            >
              PDF
            </button>
            <button
              type="button"
              onClick={() => window.print()}
              className="px-2.5 py-2 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-700 shadow-2xs inline-flex items-center gap-1"
            >
              <Printer className="w-3.5 h-3.5" />
              Print
            </button>
          </div>
        </div>

        {paged.length === 0 ? (
          <EmptyState
            title="No matching attendance records"
            description="Adjust your filters or record attendance using an Employee Number."
          />
        ) : (
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs dark:shadow-md dark:shadow-black/30">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800/90 border-b border-slate-200 dark:border-slate-700 text-xs text-slate-600 dark:text-slate-300 font-semibold">
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Employee</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Department</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Sched In / Out</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Actual In</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Actual Out</th>
                  <th className="py-2.5 px-3 text-right border-r border-slate-200 dark:border-slate-700">Late</th>
                  <th className="py-2.5 px-3 text-right border-r border-slate-200 dark:border-slate-700">UT</th>
                  <th className="py-2.5 px-3 text-right border-r border-slate-200 dark:border-slate-700">Reg Hrs</th>
                  <th className="py-2.5 px-3 text-right border-r border-slate-200 dark:border-slate-700">OT Hrs</th>
                  <th className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">Status</th>
                  {canSeeEarnings && <th className="py-2.5 px-3 text-right">Est. Daily Pay</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700 text-xs">
                {paged.map((row) => (
                  <tr key={row.employee.id} className="group hover:bg-blue-50/50 dark:hover:bg-slate-800/70 shadow-[0_1px_2px_rgba(15,23,42,0.03)] dark:shadow-[0_1px_2px_rgba(0,0,0,0.25)] transition-colors">
                    <td className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">
                      <div className="flex items-center gap-2.5">
                        <Avatar name={row.employee.full_name} src={row.employee.photo_url} size="sm" />
                        <div className="min-w-0">
                          <p className="font-semibold text-slate-900 dark:text-slate-100 truncate cursor-pointer rounded px-1.5 -mx-1.5 py-0.5 transition-all hover:bg-amber-200/90 dark:hover:bg-amber-500/35 hover:text-slate-950 dark:hover:text-amber-200 group-hover:text-blue-700 dark:group-hover:text-blue-300">
                            {row.employee.full_name}
                          </p>
                          <p className="text-slate-500 dark:text-slate-400 font-mono truncate">
                            <span>{row.employee.employee_number}</span>
                            <span> · </span>
                            <span className="cursor-pointer rounded px-1 -mx-0.5 transition-colors hover:bg-amber-200/80 dark:hover:bg-amber-500/30 hover:text-slate-900 dark:hover:text-amber-200">
                              {row.employee.position}
                            </span>
                          </p>
                        </div>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300 whitespace-nowrap border-r border-slate-200 dark:border-slate-700">{row.employee.department}</td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-500 dark:text-slate-400 whitespace-nowrap border-r border-slate-200 dark:border-slate-700">
                      {row.att?.scheduled_time_in
                        ? `${formatManilaTime(row.att.scheduled_time_in)} – ${formatManilaTime(row.att.scheduled_time_out)}`
                        : '08:00 – 17:00'}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-900 dark:text-slate-100 whitespace-nowrap border-r border-slate-200 dark:border-slate-700">
                      {formatManilaTime(row.att?.actual_time_in)}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-slate-900 dark:text-slate-100 whitespace-nowrap border-r border-slate-200 dark:border-slate-700">
                      {formatManilaTime(row.att?.actual_time_out)}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700">
                      {row.att?.late_minutes ? `${row.att.late_minutes}m` : '0m'}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right text-slate-700 dark:text-slate-300 border-r border-slate-200 dark:border-slate-700">
                      {row.att?.undertime_minutes ? `${row.att.undertime_minutes}m` : '0m'}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right text-slate-900 dark:text-slate-100 border-r border-slate-200 dark:border-slate-700">
                      {(row.att?.regular_hours ?? 0).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 font-mono tabular-nums text-right text-slate-900 dark:text-slate-100 border-r border-slate-200 dark:border-slate-700">
                      {(row.att?.approved_overtime_hours ?? 0).toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 border-r border-slate-200 dark:border-slate-700">
                      <StatusLabel label={row.effectiveStatus} />
                    </td>
                    {canSeeEarnings && (
                      <td className="py-2.5 px-3 font-mono tabular-nums text-right font-medium text-slate-900 dark:text-slate-100 whitespace-nowrap">
                        {formatPeso(row.estDailyEarnings)}
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {totalPages > 1 && (
          <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 no-print">
            <span>
              Page {page} of {totalPages} ({filtered.length} records)
            </span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                disabled={page <= 1}
                onClick={() => setPage((p) => p - 1)}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-50"
              >
                Previous
              </button>
              <button
                type="button"
                disabled={page >= totalPages}
                onClick={() => setPage((p) => p + 1)}
                className="px-3 py-1.5 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-50"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
