import React, { useState } from 'react';
import { CalendarPlus, Trash2, CheckCircle2 } from 'lucide-react';
import { EmptyState, StatusLabel } from '../../components/ui/Common';
import { formatManilaDate } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { CompanySettings, Holiday, HolidayType, UserProfile } from '../../types/database';

const OFFICIAL_PH_2026: Array<{ date: string; name: string; type: HolidayType }> = [
  { date: '2026-01-01', name: "New Year's Day", type: 'REGULAR' },
  { date: '2026-04-02', name: 'Maundy Thursday', type: 'REGULAR' },
  { date: '2026-04-03', name: 'Good Friday', type: 'REGULAR' },
  { date: '2026-04-09', name: 'Araw ng Kagitingan', type: 'REGULAR' },
  { date: '2026-05-01', name: 'Labor Day', type: 'REGULAR' },
  { date: '2026-06-12', name: 'Independence Day', type: 'REGULAR' },
  { date: '2026-08-21', name: 'Ninoy Aquino Day', type: 'SPECIAL_NON_WORKING' },
  { date: '2026-08-31', name: 'National Heroes Day', type: 'REGULAR' },
  { date: '2026-11-01', name: "All Saints' Day", type: 'SPECIAL_NON_WORKING' },
  { date: '2026-11-30', name: 'Bonifacio Day', type: 'REGULAR' },
  { date: '2026-12-25', name: 'Christmas Day', type: 'REGULAR' },
  { date: '2026-12-30', name: 'Rizal Day', type: 'REGULAR' },
];

export function HolidaysPage({
  actor,
  company,
  holidays,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  company: CompanySettings;
  holidays: Holiday[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [holidayDate, setHolidayDate] = useState('2026-12-08');
  const [name, setName] = useState('');
  const [holidayType, setHolidayType] = useState<HolidayType>('SPECIAL_NON_WORKING');
  const [description, setDescription] = useState('');
  const [isVerified, setIsVerified] = useState(true);
  const [mults, setMults] = useState(company.multipliers);
  const [saving, setSaving] = useState(false);

  async function handleAddHoliday(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    setSaving(true);
    try {
      await dataService.saveHoliday(actor, {
        holiday_date: holidayDate,
        name: name.trim(),
        holiday_type: holidayType,
        description: description.trim() || null,
        is_verified: isVerified,
        source: 'MANUAL',
      });
      setName('');
      setDescription('');
      onNotify('success', 'Holiday Saved', `${name} (${holidayDate}) added to calendar.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Failed to save holiday', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  async function handleImportOfficial() {
    let added = 0;
    for (const item of OFFICIAL_PH_2026) {
      const exists = holidays.some((h) => h.holiday_date === item.date && h.name === item.name);
      if (!exists) {
        await dataService.saveHoliday(actor, {
          holiday_date: item.date,
          name: item.name,
          holiday_type: item.type,
          description: 'Official Philippine Holiday',
          is_verified: true,
          source: 'OFFICIAL_PH',
        });
        added += 1;
      }
    }
    onNotify('success', 'Official Holidays Checked', `Imported ${added} missing official 2026 Philippine holidays.`);
    onReload();
  }

  async function handleSaveMultipliers() {
    try {
      await dataService.updateCompanySettings(actor, { ...company, multipliers: mults });
      onNotify('success', 'Multipliers Saved', 'Holiday and rest day multipliers updated.');
      onReload();
    } catch (err) {
      onNotify('error', 'Update failed', (err as Error).message);
    }
  }

  const multiplierRows: Array<{ key: keyof typeof mults; label: string }> = [
    { key: 'ordinary', label: 'Ordinary Workday' },
    { key: 'rest_day', label: 'Ordinary Rest Day' },
    { key: 'special_holiday', label: 'Special Non-Working Holiday' },
    { key: 'special_holiday_rest_day', label: 'Special Holiday + Rest Day' },
    { key: 'regular_holiday', label: 'Regular Holiday' },
    { key: 'regular_holiday_rest_day', label: 'Regular Holiday + Rest Day' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900">Sunday, Rest Day &amp; Philippine Holiday Management</h1>
          <p className="text-sm text-slate-500 mt-0.5">
            Sunday is not automatically a rest day; payroll uses each employee&apos;s assigned rest day and verified holidays.
          </p>
        </div>
        <button
          type="button"
          onClick={handleImportOfficial}
          className="px-3.5 py-2 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 rounded-lg hover:bg-blue-100 inline-flex items-center gap-1.5"
        >
          <CheckCircle2 className="w-3.5 h-3.5" />
          Import Official 2026 PH Holidays
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <div className="lg:col-span-5 space-y-6">
          <form onSubmit={handleAddHoliday} className="bg-white border border-slate-200 rounded-xl p-5 space-y-3.5">
            <h2 className="text-sm font-semibold text-slate-900">Add Holiday Entry</h2>
            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block font-medium text-slate-700 mb-1">Holiday Date</label>
                <input
                  type="date"
                  required
                  value={holidayDate}
                  onChange={(e) => setHolidayDate(e.target.value)}
                  className="w-full px-3 py-2 font-mono border border-slate-200 rounded-lg"
                />
              </div>
              <div>
                <label className="block font-medium text-slate-700 mb-1">Holiday Type</label>
                <select
                  value={holidayType}
                  onChange={(e) => setHolidayType(e.target.value as HolidayType)}
                  className="w-full px-3 py-2 border border-slate-200 rounded-lg bg-white"
                >
                  <option value="REGULAR">Regular Holiday</option>
                  <option value="SPECIAL_NON_WORKING">Special Non-Working</option>
                  <option value="SPECIAL_WORKING">Special Working</option>
                </select>
              </div>
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 mb-1">Holiday Name *</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Feast of the Immaculate Conception"
                className="w-full px-3 py-2 border border-slate-200 rounded-lg"
              />
            </div>
            <div className="text-xs">
              <label className="block font-medium text-slate-700 mb-1">Description / Proclamation</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Proclamation reference..."
                className="w-full px-3 py-2 border border-slate-200 rounded-lg"
              />
            </div>
            <label className="flex items-center gap-2 text-xs text-slate-700">
              <input
                type="checkbox"
                checked={isVerified}
                onChange={(e) => setIsVerified(e.target.checked)}
                className="rounded border-slate-300"
              />
              Verified official declaration (unverified dates are excluded from auto holiday pay)
            </label>
            <button
              type="submit"
              disabled={saving}
              className="w-full py-2 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center justify-center gap-1.5"
            >
              <CalendarPlus className="w-3.5 h-3.5" />
              Add Holiday
            </button>
          </form>

          {/* Configurable Multipliers */}
          <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">Pay Multiplier Configuration</h2>
              <button
                type="button"
                onClick={handleSaveMultipliers}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg"
              >
                Save Multipliers
              </button>
            </div>
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-500">
                  <th className="py-2 text-left">Classification</th>
                  <th className="py-2 text-right">First 8h</th>
                  <th className="py-2 text-right">Overtime</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {multiplierRows.map((row) => (
                  <tr key={row.key}>
                    <td className="py-2 font-medium text-slate-800">{row.label}</td>
                    <td className="py-1.5 text-right">
                      <input
                        type="number"
                        step="0.01"
                        value={mults[row.key].first8}
                        onChange={(e) =>
                          setMults({
                            ...mults,
                            [row.key]: { ...mults[row.key], first8: Number(e.target.value) },
                          })
                        }
                        className="w-20 px-2 py-1 text-right font-mono border border-slate-200 rounded"
                      />
                    </td>
                    <td className="py-1.5 text-right">
                      <input
                        type="number"
                        step="0.01"
                        value={mults[row.key].overtime}
                        onChange={(e) =>
                          setMults({
                            ...mults,
                            [row.key]: { ...mults[row.key], overtime: Number(e.target.value) },
                          })
                        }
                        className="w-20 px-2 py-1 text-right font-mono border border-slate-200 rounded"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-5">
          <h2 className="text-sm font-semibold text-slate-900 mb-3">Configured Holiday Calendar</h2>
          {holidays.length === 0 ? (
            <EmptyState
              title="No holidays configured"
              description="Add a holiday or import official Philippine holidays."
            />
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 text-slate-500 font-medium">
                    <th className="py-2 pr-3">Date</th>
                    <th className="py-2 px-3">Holiday Name</th>
                    <th className="py-2 px-3">Type</th>
                    <th className="py-2 px-3">Verification</th>
                    <th className="py-2 pl-3 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {[...holidays]
                    .sort((a, b) => a.holiday_date.localeCompare(b.holiday_date))
                    .map((h) => (
                      <tr key={h.id} className="hover:bg-slate-50">
                        <td className="py-2.5 pr-3 font-mono whitespace-nowrap">
                          {formatManilaDate(h.holiday_date)}
                        </td>
                        <td className="py-2.5 px-3">
                          <p className="font-semibold text-slate-900">{h.name}</p>
                          {h.description && <p className="text-slate-500">{h.description}</p>}
                        </td>
                        <td className="py-2.5 px-3">
                          <StatusLabel
                            label={h.holiday_type}
                            tone={h.holiday_type === 'REGULAR' ? 'purple' : 'blue'}
                          />
                        </td>
                        <td className="py-2.5 px-3">
                          <StatusLabel
                            label={h.is_verified ? 'VERIFIED' : 'UNVERIFIED'}
                            tone={h.is_verified ? 'green' : 'orange'}
                          />
                        </td>
                        <td className="py-2.5 pl-3 text-right">
                          <button
                            type="button"
                            onClick={async () => {
                              await dataService.deleteHoliday(actor, h.id);
                              onNotify('success', 'Holiday Removed', `${h.name} deleted.`);
                              onReload();
                            }}
                            className="p-1.5 text-slate-500 hover:text-rose-700 hover:bg-rose-50 rounded"
                            title="Delete holiday"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
