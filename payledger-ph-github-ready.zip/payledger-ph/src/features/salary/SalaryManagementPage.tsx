import React, { useState } from 'react';
import { DollarSign, History } from 'lucide-react';
import { formatManilaDate, formatPeso, toManilaDateString } from '../../lib/date/manila';
import { dataService } from '../../services/dataService';
import type { Employee, SalaryHistoryRecord, SalaryType, UserProfile } from '../../types/database';

export function SalaryManagementPage({
  actor,
  employees,
  salaryHistory,
  onReload,
  onNotify,
}: {
  actor: UserProfile;
  employees: Employee[];
  salaryHistory: SalaryHistoryRecord[];
  onReload: () => void;
  onNotify: (type: 'success' | 'error', title: string, desc?: string) => void;
}) {
  const [selectedId, setSelectedId] = useState(employees[0]?.id ?? '');
  const selected = employees.find((e) => e.id === selectedId) ?? employees[0];

  const [salaryType, setSalaryType] = useState<SalaryType>(selected?.salary_type ?? 'DAILY');
  const [dailyRate, setDailyRate] = useState(String(selected?.daily_rate ?? 0));
  const [hourlyRate, setHourlyRate] = useState(String(selected?.hourly_rate ?? 0));
  const [weeklyRate, setWeeklyRate] = useState(
    String(selected?.weekly_rate ?? Number(((selected?.daily_rate ?? 0) * 6).toFixed(2)))
  );
  const [monthlyRate, setMonthlyRate] = useState(String(selected?.monthly_rate ?? 0));
  const [overtimeRate, setOvertimeRate] = useState(String(selected?.overtime_rate ?? 0));
  const [mealAllowance, setMealAllowance] = useState(String(selected?.meal_allowance ?? 0));
  const [transportAllowance, setTransportAllowance] = useState(String(selected?.transport_allowance ?? 0));
  const [otherAllowances, setOtherAllowances] = useState(String(selected?.other_allowances ?? 0));

  // Earnings & Leave / Holiday Credits (above SSS Share)
  const [ot1Pay, setOt1Pay] = useState(String(selected?.ot1_pay ?? 0));
  const [ot2Pay, setOt2Pay] = useState(String(selected?.ot2_pay ?? 0));
  const [silSlVlPay, setSilSlVlPay] = useState(String(selected?.sil_sl_vl_pay ?? 0));
  const [paidLeavePay, setPaidLeavePay] = useState(String(selected?.paid_leave_pay ?? 0));
  const [legalHolidayPay, setLegalHolidayPay] = useState(String(selected?.legal_holiday_pay ?? 0));
  const [specialHolidayPay, setSpecialHolidayPay] = useState(String(selected?.special_holiday_pay ?? 0));

  // Itemized Deductions table
  const [sssShare, setSssShare] = useState(String(selected?.sss_share ?? 0));
  const [sssShareRemarks, setSssShareRemarks] = useState(selected?.sss_share_remarks ?? '');
  const [phicShare, setPhicShare] = useState(String(selected?.phic_share ?? 0));
  const [phicShareRemarks, setPhicShareRemarks] = useState(selected?.phic_share_remarks ?? '');
  const [pagibigShare, setPagibigShare] = useState(String(selected?.pagibig_share ?? 0));
  const [sssLoan, setSssLoan] = useState(String(selected?.sss_loan ?? 0));
  const [pagibigLoan, setPagibigLoan] = useState(String(selected?.pagibig_loan ?? 0));
  const [coopShare, setCoopShare] = useState(String(selected?.coop_share ?? 0));
  const [coopLoan, setCoopLoan] = useState(String(selected?.coop_loan ?? 0));
  const [donation, setDonation] = useState(String(selected?.donation ?? 0));
  const [cashAdvance, setCashAdvance] = useState(String(selected?.cash_advance ?? 0));

  const [effectiveDate, setEffectiveDate] = useState(() => toManilaDateString());
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);

  const totalExtraCredits =
    (Number(ot1Pay) || 0) +
    (Number(ot2Pay) || 0) +
    (Number(silSlVlPay) || 0) +
    (Number(paidLeavePay) || 0) +
    (Number(legalHolidayPay) || 0) +
    (Number(specialHolidayPay) || 0);

  const totalDeductions =
    (Number(sssShare) || 0) +
    (Number(phicShare) || 0) +
    (Number(pagibigShare) || 0) +
    (Number(sssLoan) || 0) +
    (Number(pagibigLoan) || 0) +
    (Number(coopShare) || 0) +
    (Number(coopLoan) || 0) +
    (Number(donation) || 0) +
    (Number(cashAdvance) || 0);

  function handleDailyRateChange(val: string) {
    setDailyRate(val);
    if (val.trim() === '') {
      setHourlyRate('');
      setWeeklyRate('');
      setMonthlyRate('');
      setOvertimeRate('');
      return;
    }
    const d = Number(val);
    if (!Number.isNaN(d)) {
      const h = d / 8;
      setHourlyRate(h.toFixed(2));
      setWeeklyRate((d * 6).toFixed(2));
      setMonthlyRate((d * 22).toFixed(2));
      setOvertimeRate(h.toFixed(2));
    }
  }

  function handleHourlyRateChange(val: string) {
    setHourlyRate(val);
    if (val.trim() === '') {
      setDailyRate('');
      setWeeklyRate('');
      setMonthlyRate('');
      setOvertimeRate('');
      return;
    }
    const h = Number(val);
    if (!Number.isNaN(h)) {
      const d = h * 8;
      setDailyRate(d.toFixed(2));
      setWeeklyRate((d * 6).toFixed(2));
      setMonthlyRate((d * 22).toFixed(2));
      setOvertimeRate(h.toFixed(2));
    }
  }

  function handleWeeklyRateChange(val: string) {
    setWeeklyRate(val);
    if (val.trim() === '') {
      setDailyRate('');
      setHourlyRate('');
      setMonthlyRate('');
      setOvertimeRate('');
      return;
    }
    const w = Number(val);
    if (!Number.isNaN(w)) {
      const d = w / 6;
      const h = d / 8;
      setDailyRate(d.toFixed(2));
      setHourlyRate(h.toFixed(2));
      setMonthlyRate((d * 22).toFixed(2));
      setOvertimeRate(h.toFixed(2));
    }
  }

  function handleMonthlyRateChange(val: string) {
    setMonthlyRate(val);
    if (val.trim() === '') {
      setDailyRate('');
      setHourlyRate('');
      setWeeklyRate('');
      setOvertimeRate('');
      return;
    }
    const m = Number(val);
    if (!Number.isNaN(m)) {
      const d = m / 22;
      const h = d / 8;
      setDailyRate(d.toFixed(2));
      setHourlyRate(h.toFixed(2));
      setWeeklyRate((d * 6).toFixed(2));
      setOvertimeRate(h.toFixed(2));
    }
  }

  function selectEmployee(empId: string) {
    setSelectedId(empId);
    const emp = employees.find((e) => e.id === empId);
    if (emp) {
      setSalaryType(emp.salary_type);
      setDailyRate(String(emp.daily_rate));
      setHourlyRate(String(emp.hourly_rate));
      setWeeklyRate(String(emp.weekly_rate ?? Number((emp.daily_rate * 6).toFixed(2))));
      setMonthlyRate(String(emp.monthly_rate));
      setOvertimeRate(String(emp.overtime_rate));
      setMealAllowance(String(emp.meal_allowance));
      setTransportAllowance(String(emp.transport_allowance));
      setOtherAllowances(String(emp.other_allowances));
      setOt1Pay(String(emp.ot1_pay ?? 0));
      setOt2Pay(String(emp.ot2_pay ?? 0));
      setSilSlVlPay(String(emp.sil_sl_vl_pay ?? 0));
      setPaidLeavePay(String(emp.paid_leave_pay ?? 0));
      setLegalHolidayPay(String(emp.legal_holiday_pay ?? 0));
      setSpecialHolidayPay(String(emp.special_holiday_pay ?? 0));
      setSssShare(String(emp.sss_share ?? 0));
      setSssShareRemarks(emp.sss_share_remarks ?? '');
      setPhicShare(String(emp.phic_share ?? 0));
      setPhicShareRemarks(emp.phic_share_remarks ?? '');
      setPagibigShare(String(emp.pagibig_share ?? 0));
      setSssLoan(String(emp.sss_loan ?? 0));
      setPagibigLoan(String(emp.pagibig_loan ?? 0));
      setCoopShare(String(emp.coop_share ?? 0));
      setCoopLoan(String(emp.coop_loan ?? 0));
      setDonation(String(emp.donation ?? 0));
      setCashAdvance(String(emp.cash_advance ?? 0));
    }
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!selected || !reason.trim()) {
      onNotify('error', 'Reason required', 'Please enter a reason for the effective-dated salary change.');
      return;
    }
    setSaving(true);
    try {
      await dataService.updateEmployeeSalary(actor, selected, {
        salary_type: salaryType,
        daily_rate: Number(dailyRate) || 0,
        hourly_rate: Number(hourlyRate) || 0,
        weekly_rate: Number(weeklyRate) || 0,
        monthly_rate: Number(monthlyRate) || 0,
        overtime_rate: Number(overtimeRate) || 0,
        meal_allowance: Number(mealAllowance) || 0,
        transport_allowance: Number(transportAllowance) || 0,
        other_allowances: Number(otherAllowances) || 0,
        default_deductions: totalDeductions,
        ot1_pay: Number(ot1Pay) || 0,
        ot2_pay: Number(ot2Pay) || 0,
        sil_sl_vl_pay: Number(silSlVlPay) || 0,
        paid_leave_pay: Number(paidLeavePay) || 0,
        legal_holiday_pay: Number(legalHolidayPay) || 0,
        special_holiday_pay: Number(specialHolidayPay) || 0,
        sss_share: Number(sssShare) || 0,
        sss_share_remarks: sssShareRemarks.trim(),
        phic_share: Number(phicShare) || 0,
        phic_share_remarks: phicShareRemarks.trim(),
        pagibig_share: Number(pagibigShare) || 0,
        sss_loan: Number(sssLoan) || 0,
        pagibig_loan: Number(pagibigLoan) || 0,
        coop_share: Number(coopShare) || 0,
        coop_loan: Number(coopLoan) || 0,
        donation: Number(donation) || 0,
        cash_advance: Number(cashAdvance) || 0,
        effective_date: effectiveDate,
        reason: reason.trim(),
      });
      setReason('');
      onNotify('success', 'Salary Updated', `Recorded effective-dated rate & deduction change for ${selected.full_name}.`);
      onReload();
    } catch (err) {
      onNotify('error', 'Salary update failed', (err as Error).message);
    } finally {
      setSaving(false);
    }
  }

  if (!selected) return null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100">
          Salary Management &amp; Effective-Dated History
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-0.5">
          Updating a current salary or recurring deductions records an immutable history entry and never alters finalized payroll snapshots.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        <form
          onSubmit={handleSave}
          className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-xl p-6 space-y-5"
        >
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Update Compensation &amp; Deductions</h2>
            <select
              value={selected.id}
              onChange={(e) => selectEmployee(e.target.value)}
              className="px-3 py-1.5 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100"
            >
              {employees.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.employee_number} — {e.full_name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="col-span-2 sm:col-span-2">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Salary Type</label>
              <select
                value={salaryType}
                onChange={(e) => setSalaryType(e.target.value as SalaryType)}
                className="w-full px-3 py-2 border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              >
                <option value="DAILY">Daily Paid</option>
                <option value="HOURLY">Hourly Paid</option>
                <option value="WEEKLY">Weekly Paid</option>
                <option value="MONTHLY">Monthly Paid</option>
              </select>
            </div>
            <div className="col-span-2 sm:col-span-2">
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Effective Date *</label>
              <input
                type="date"
                required
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>

            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Daily Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={dailyRate}
                onChange={(e) => handleDailyRateChange(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Hourly Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={hourlyRate}
                onChange={(e) => handleHourlyRateChange(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Weekly Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={weeklyRate}
                onChange={(e) => handleWeeklyRateChange(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Monthly Rate (₱)</label>
              <input
                type="number"
                step="0.01"
                value={monthlyRate}
                onChange={(e) => handleMonthlyRateChange(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">OT Base Rate (₱/hr)</label>
              <input
                type="number"
                step="0.01"
                value={overtimeRate}
                onChange={(e) => setOvertimeRate(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Meal Allow. (₱)</label>
              <input
                type="number"
                step="0.01"
                value={mealAllowance}
                onChange={(e) => setMealAllowance(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Transport Allow. (₱)</label>
              <input
                type="number"
                step="0.01"
                value={transportAllowance}
                onChange={(e) => setTransportAllowance(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">Other Allowances (₱)</label>
              <input
                type="number"
                step="0.01"
                value={otherAllowances}
                onChange={(e) => setOtherAllowances(e.target.value)}
                className="w-full px-3 py-2 font-mono border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
              />
            </div>
          </div>

          {/* Itemized Overtime / Leave / Holiday Credits (on top of SSS Share) & Deductions Table */}
          <div className="overflow-x-auto border border-slate-200 dark:border-slate-700 rounded-lg shadow-xs">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 dark:bg-slate-800 border-b border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 font-semibold">
                  <th className="py-2 px-3 border-r border-slate-200 dark:border-slate-700">Description</th>
                  <th className="py-2 px-3 border-r border-slate-200 dark:border-slate-700">Remarks</th>
                  <th className="py-2 px-3 text-right w-36">Amount (₱)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-700">
                <tr className="bg-emerald-50/70 dark:bg-emerald-950/30 colorful:bg-gradient-to-r colorful:from-emerald-100/80 colorful:to-teal-100/80">
                  <td colSpan={3} className="py-1.5 px-3 font-semibold uppercase tracking-wide text-[11px] text-emerald-800 dark:text-emerald-300">
                    Overtime, Leave &amp; Holiday Credits (Top of SSS Share)
                  </td>
                </tr>
                {[
                  { label: 'OT 1', val: ot1Pay, set: setOt1Pay, hint: 'Regular Overtime' },
                  { label: 'OT 2', val: ot2Pay, set: setOt2Pay, hint: 'Rest Day / Excess OT' },
                  { label: 'SIL / SL / VL', val: silSlVlPay, set: setSilSlVlPay, hint: 'Leave Credit Pay' },
                  { label: 'PAID', val: paidLeavePay, set: setPaidLeavePay, hint: 'Paid Credit / Adjustment' },
                  { label: 'Legal Holiday', val: legalHolidayPay, set: setLegalHolidayPay, hint: 'Regular Holiday Pay' },
                  { label: 'Special Holiday', val: specialHolidayPay, set: setSpecialHolidayPay, hint: 'Special Non-Working Holiday' },
                ].map((item) => (
                  <tr key={item.label}>
                    <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                      {item.label}
                    </td>
                    <td className="py-2 px-3 text-slate-500 dark:text-slate-400 border-r border-slate-200 dark:border-slate-700">
                      {item.hint}
                    </td>
                    <td className="py-1.5 px-2">
                      <input
                        type="number"
                        step="0.01"
                        value={item.val}
                        onChange={(e) => item.set(e.target.value)}
                        className="w-full px-2.5 py-1 text-right font-mono border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800"
                      />
                    </td>
                  </tr>
                ))}
                <tr className="bg-emerald-50/40 dark:bg-emerald-950/20 font-semibold">
                  <td colSpan={2} className="py-2 px-3 text-emerald-900 dark:text-emerald-200 border-r border-slate-200 dark:border-slate-700">
                    Total Additional Credits
                  </td>
                  <td className="py-2 px-3 text-right font-mono tabular-nums text-emerald-700 dark:text-emerald-400">
                    {formatPeso(totalExtraCredits)}
                  </td>
                </tr>

                <tr className="bg-rose-50/70 dark:bg-rose-950/30 colorful:bg-gradient-to-r colorful:from-rose-100/80 colorful:to-fuchsia-100/80">
                  <td colSpan={3} className="py-1.5 px-3 font-semibold uppercase tracking-wide text-[11px] text-rose-800 dark:text-rose-300">
                    Deductions (SSS Share &amp; Statutory)
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                    SSS Share
                  </td>
                  <td className="py-1.5 px-2 border-r border-slate-200 dark:border-slate-700">
                    <input
                      type="text"
                      value={sssShareRemarks}
                      onChange={(e) => setSssShareRemarks(e.target.value)}
                      placeholder="Add remarks (e.g. PARTIAL-NOV)"
                      className="w-full px-2.5 py-1 border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800 text-xs"
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <input
                      type="number"
                      step="0.01"
                      value={sssShare}
                      onChange={(e) => setSssShare(e.target.value)}
                      className="w-full px-2.5 py-1 text-right font-mono border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800"
                    />
                  </td>
                </tr>
                <tr>
                  <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                    PHIC Share
                  </td>
                  <td className="py-1.5 px-2 border-r border-slate-200 dark:border-slate-700">
                    <input
                      type="text"
                      value={phicShareRemarks}
                      onChange={(e) => setPhicShareRemarks(e.target.value)}
                      placeholder="Add remarks (e.g. PARTIAL-NOV)"
                      className="w-full px-2.5 py-1 border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800 text-xs"
                    />
                  </td>
                  <td className="py-1.5 px-2">
                    <input
                      type="number"
                      step="0.01"
                      value={phicShare}
                      onChange={(e) => setPhicShare(e.target.value)}
                      className="w-full px-2.5 py-1 text-right font-mono border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800"
                    />
                  </td>
                </tr>
                {[
                  { label: 'PAG-IBIG Share', val: pagibigShare, set: setPagibigShare },
                  { label: 'SSS Loan', val: sssLoan, set: setSssLoan },
                  { label: 'Pag-ibig Loan', val: pagibigLoan, set: setPagibigLoan },
                  { label: 'Coop Share', val: coopShare, set: setCoopShare },
                  { label: 'Coop Loan', val: coopLoan, set: setCoopLoan },
                  { label: 'Donation', val: donation, set: setDonation },
                  { label: 'Cash Advance', val: cashAdvance, set: setCashAdvance },
                ].map((item) => (
                  <tr key={item.label}>
                    <td className="py-2 px-3 font-medium text-slate-800 dark:text-slate-200 border-r border-slate-200 dark:border-slate-700">
                      {item.label}
                    </td>
                    <td className="py-2 px-3 text-slate-400 border-r border-slate-200 dark:border-slate-700">—</td>
                    <td className="py-1.5 px-2">
                      <input
                        type="number"
                        step="0.01"
                        value={item.val}
                        onChange={(e) => item.set(e.target.value)}
                        className="w-full px-2.5 py-1 text-right font-mono border border-slate-200 dark:border-slate-700 rounded bg-white dark:bg-slate-800"
                      />
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-50 dark:bg-slate-800 font-semibold">
                  <td colSpan={2} className="py-2 px-3 text-slate-900 dark:text-slate-100 border-r border-slate-200 dark:border-slate-700">
                    Total Deductions
                  </td>
                  <td className="py-2 px-3 text-right font-mono tabular-nums text-rose-700 dark:text-rose-400">
                    {formatPeso(totalDeductions)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700 dark:text-slate-300 mb-1">Reason for Change *</label>
            <input
              type="text"
              required
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Annual performance adjustment / statutory deduction update"
              className="w-full px-3 py-2 text-xs border border-slate-200 dark:border-slate-700 rounded-lg bg-white dark:bg-slate-800"
            />
          </div>

          <button
            type="submit"
            disabled={saving}
            className="w-full py-2.5 px-4 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-lg inline-flex items-center justify-center gap-1.5 shadow-xs"
          >
            <DollarSign className="w-3.5 h-3.5" />
            {saving ? 'Recording Salary Change...' : 'Save Effective-Dated Salary & Deductions Update'}
          </button>
        </form>

        <div className="lg:col-span-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 shadow-sm dark:shadow-lg dark:shadow-black/30 rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2">
            <History className="w-4 h-4 text-slate-500 dark:text-slate-400" />
            <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">Salary History Ledger</h2>
          </div>

          {salaryHistory.length === 0 ? (
            <p className="text-xs text-slate-500 dark:text-slate-400 py-8 text-center">No salary adjustments recorded yet.</p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[620px] overflow-y-auto">
              {salaryHistory.map((h) => {
                const emp = employees.find((e) => e.id === h.employee_id);
                return (
                  <div key={h.id} className="py-3 text-xs space-y-1">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-slate-900 dark:text-slate-100">
                        {emp?.full_name ?? 'Employee'} ({emp?.employee_number})
                      </span>
                      <span className="font-mono text-slate-500 dark:text-slate-400">
                        Effective {formatManilaDate(h.effective_date)}
                      </span>
                    </div>
                    <p className="text-slate-600 dark:text-slate-300">{h.reason}</p>
                    <p className="font-mono tabular-nums text-slate-700 dark:text-slate-300">
                      Daily: {formatPeso(h.previous_daily_rate)} → {formatPeso(h.new_daily_rate)} · Weekly:{' '}
                      {formatPeso(h.previous_weekly_rate ?? 0)} → {formatPeso(h.new_weekly_rate ?? 0)} · Monthly:{' '}
                      {formatPeso(h.previous_monthly_rate)} → {formatPeso(h.new_monthly_rate)}
                    </p>
                    <p className="font-mono tabular-nums text-rose-700 dark:text-rose-400">
                      Deductions: {formatPeso(h.previous_deductions)} → {formatPeso(h.new_deductions)}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
