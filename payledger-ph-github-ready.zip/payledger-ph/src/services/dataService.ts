import { isSupabaseConfigured, supabase } from '../lib/supabase/client';
import { calculateAttendanceMetrics } from '../lib/attendance/calculator';
import type { EnrolledFaceCandidate } from '../lib/attendance/faceRecognition';
import { computeEmployeePayroll, DEFAULT_MULTIPLIERS } from '../lib/payroll/calculator';
import {
  addDaysToDateString,
  buildManilaTimestamp,
  deriveWorkDate,
  toManilaDateString,
} from '../lib/date/manila';
import type {
  AttendanceCorrection,
  AttendanceEvent,
  AttendancePunchResult,
  AttendanceRecord,
  AuditLog,
  CompanySettings,
  Employee,
  EmployeeNumberCredential,
  Holiday,
  IntegrationSyncItem,
  LeaveRequest,
  OvertimeRequest,
  OvertimeStatus,
  PayrollAdjustment,
  PayrollPeriod,
  PayrollRecord,
  SalaryHistoryRecord,
  Schedule,
  UserProfile,
  UserRole,
} from '../types/database';

const STORAGE_KEY = 'payledger_ph_local_db_v1';
const SESSION_KEY = 'payledger_ph_local_session_v1';

export interface AppDatabaseState {
  companySettings: CompanySettings;
  schedules: Schedule[];
  employees: Employee[];
  credentials: EmployeeNumberCredential[];
  profiles: UserProfile[];
  salaryHistory: SalaryHistoryRecord[];
  holidays: Holiday[];
  attendance: AttendanceRecord[];
  attendanceEvents: AttendanceEvent[];
  corrections: AttendanceCorrection[];
  overtimeRequests: OvertimeRequest[];
  leaveRequests: LeaveRequest[];
  payrollPeriods: PayrollPeriod[];
  payrollRecords: PayrollRecord[];
  payrollAdjustments: PayrollAdjustment[];
  auditLogs: AuditLog[];
  syncQueue: IntegrationSyncItem[];
  localPasswords: Record<string, string>; // preview-mode only
}

function uid(prefix = 'id'): string {
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
}

function createInitialPreviewState(): AppDatabaseState {
  const today = toManilaDateString();
  const yesterday = addDaysToDateString(today, -1);
  const twoDaysAgo = addDaysToDateString(today, -2);
  const schedDefaultId = '11111111-1111-4111-8111-111111111101';
  const schedNightId = '11111111-1111-4111-8111-111111111102';

  const schedules: Schedule[] = [
    {
      id: schedDefaultId,
      name: 'Standard Day Shift (8:00 AM - 5:00 PM)',
      time_in: '08:00:00',
      time_out: '17:00:00',
      lunch_break_minutes: 60,
      grace_period_minutes: 0,
      regular_hours: 8,
      is_flexible: false,
      is_overnight: false,
      is_default: true,
    },
    {
      id: schedNightId,
      name: 'Overnight Operations Shift (10:00 PM - 7:00 AM)',
      time_in: '22:00:00',
      time_out: '07:00:00',
      lunch_break_minutes: 60,
      grace_period_minutes: 5,
      regular_hours: 8,
      is_flexible: false,
      is_overnight: true,
      is_default: false,
    },
  ];

  const companySettings: CompanySettings = {
    id: '22222222-2222-4222-8222-222222222201',
    company_name: 'PayLedger PH Enterprise',
    company_logo_url: null,
    company_address: 'Ayala Avenue, Makati City, Metro Manila 1226',
    contact_number: '+63 2 8855 4200',
    company_email: 'hr@payledger.ph',
    timezone: 'Asia/Manila',
    working_days: [1, 2, 3, 4, 5, 6],
    default_schedule_id: schedDefaultId,
    default_time_in: '08:00:00',
    default_time_out: '17:00:00',
    lunch_break_minutes: 60,
    grace_period_minutes: 0,
    regular_working_hours: 8,
    default_rest_days: [0],
    payroll_schedule: 'SEMI_MONTHLY',
    employee_number_prefix: 'EMP',
    require_kiosk_pin: false,
    theme: 'light',
    payslip_note: 'DEDUCTION ON SSS & PHIC SHARE (FULL FOR NOVEMBER)- 0%',
    multipliers: DEFAULT_MULTIPLIERS,
  };

  const employees: Employee[] = [
    {
      id: '33333333-3333-4333-8333-333333333301',
      employee_number: 'EMP-2026-0001',
      full_name: 'Mateo Villanueva',
      photo_url: null,
      position: 'Operations Supervisor',
      department: 'Operations',
      contact_number: '+63 917 555 0101',
      address: 'BGC, Taguig City, Metro Manila',
      email: 'mateo.villanueva@payledger.ph',
      date_hired: '2024-03-15',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: schedDefaultId,
      rest_days: [0],
      salary_type: 'MONTHLY',
      daily_rate: 1500,
      hourly_rate: 187.5,
      weekly_rate: 9000,
      monthly_rate: 33000,
      overtime_rate: 187.5,
      meal_allowance: 1500,
      transport_allowance: 1200,
      other_allowances: 0,
      default_deductions: 1450,
      sss_share: 675,
      sss_share_remarks: 'PARTIAL-NOV',
      phic_share: 400,
      phic_share_remarks: 'PARTIAL-NOV',
      pagibig_share: 200,
      sss_loan: 0,
      pagibig_loan: 0,
      coop_share: 175,
      coop_loan: 0,
      donation: 0,
      cash_advance: 0,
      is_active: true,
      deactivated_at: null,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '33333333-3333-4333-8333-333333333302',
      employee_number: 'EMP-2026-0002',
      full_name: 'Clarissa Mendoza',
      photo_url: null,
      position: 'Payroll & HR Specialist',
      department: 'Human Resources',
      contact_number: '+63 917 555 0102',
      address: 'Ortigas Center, Pasig City',
      email: 'clarissa.mendoza@payledger.ph',
      date_hired: '2024-06-01',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: schedDefaultId,
      rest_days: [0],
      salary_type: 'MONTHLY',
      daily_rate: 1350,
      hourly_rate: 168.75,
      weekly_rate: 8100,
      monthly_rate: 29700,
      overtime_rate: 168.75,
      meal_allowance: 1200,
      transport_allowance: 1000,
      other_allowances: 0,
      default_deductions: 1200,
      sss_share: 560,
      sss_share_remarks: 'PARTIAL-NOV',
      phic_share: 340,
      phic_share_remarks: 'PARTIAL-NOV',
      pagibig_share: 200,
      sss_loan: 0,
      pagibig_loan: 0,
      coop_share: 100,
      coop_loan: 0,
      donation: 0,
      cash_advance: 0,
      is_active: true,
      deactivated_at: null,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '33333333-3333-4333-8333-333333333303',
      employee_number: 'EMP-2026-0003',
      full_name: 'Rafael Santos',
      photo_url: null,
      position: 'Field Logistics Technician',
      department: 'Logistics',
      contact_number: '+63 918 555 0103',
      address: 'Quezon City, Metro Manila',
      email: 'rafael.santos@payledger.ph',
      date_hired: '2025-01-10',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: schedDefaultId,
      rest_days: [0],
      salary_type: 'DAILY',
      daily_rate: 850,
      hourly_rate: 106.25,
      weekly_rate: 5100,
      monthly_rate: 0,
      overtime_rate: 106.25,
      meal_allowance: 800,
      transport_allowance: 600,
      other_allowances: 0,
      default_deductions: 650,
      sss_share: 300,
      sss_share_remarks: 'PARTIAL-NOV',
      phic_share: 200,
      phic_share_remarks: 'PARTIAL-NOV',
      pagibig_share: 150,
      sss_loan: 0,
      pagibig_loan: 0,
      coop_share: 0,
      coop_loan: 0,
      donation: 0,
      cash_advance: 0,
      is_active: true,
      deactivated_at: null,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '33333333-3333-4333-8333-333333333304',
      employee_number: 'EMP-2026-0004',
      full_name: 'Angela Reyes',
      photo_url: null,
      position: 'Software Engineer',
      department: 'Engineering',
      contact_number: '+63 919 555 0104',
      address: 'Mandaluyong City, Metro Manila',
      email: 'angela.reyes@payledger.ph',
      date_hired: '2025-04-20',
      employment_type: 'REGULAR',
      employment_status: 'ACTIVE',
      schedule_id: schedDefaultId,
      rest_days: [0, 6],
      salary_type: 'MONTHLY',
      daily_rate: 2200,
      hourly_rate: 275,
      weekly_rate: 13200,
      monthly_rate: 48400,
      overtime_rate: 275,
      meal_allowance: 2000,
      transport_allowance: 1500,
      other_allowances: 500,
      default_deductions: 2100,
      sss_share: 900,
      sss_share_remarks: 'PARTIAL-NOV',
      phic_share: 600,
      phic_share_remarks: 'PARTIAL-NOV',
      pagibig_share: 200,
      sss_loan: 400,
      pagibig_loan: 0,
      coop_share: 0,
      coop_loan: 0,
      donation: 0,
      cash_advance: 0,
      is_active: true,
      deactivated_at: null,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '33333333-3333-4333-8333-333333333305',
      employee_number: 'EMP-2026-0005',
      full_name: 'Marco Bautista',
      photo_url: null,
      position: 'Warehouse Associate',
      department: 'Logistics',
      contact_number: '+63 920 555 0105',
      address: 'Parañaque City, Metro Manila',
      email: 'marco.bautista@payledger.ph',
      date_hired: '2025-09-01',
      employment_type: 'PROBATIONARY',
      employment_status: 'ACTIVE',
      schedule_id: schedDefaultId,
      rest_days: [3], // Wednesday rest day
      salary_type: 'HOURLY',
      daily_rate: 760,
      hourly_rate: 95,
      weekly_rate: 4560,
      monthly_rate: 0,
      overtime_rate: 95,
      meal_allowance: 600,
      transport_allowance: 500,
      other_allowances: 0,
      default_deductions: 500,
      sss_share: 250,
      sss_share_remarks: 'PARTIAL-NOV',
      phic_share: 150,
      phic_share_remarks: 'PARTIAL-NOV',
      pagibig_share: 100,
      sss_loan: 0,
      pagibig_loan: 0,
      coop_share: 0,
      coop_loan: 0,
      donation: 0,
      cash_advance: 0,
      is_active: true,
      deactivated_at: null,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
  ];

  const credentials: EmployeeNumberCredential[] = employees.map((e) => ({
    id: uid('cred'),
    employee_id: e.id,
    employee_number: e.employee_number,
    credential_status: 'ACTIVE',
    pin_required: false,
    issued_at: e.created_at,
    revoked_at: null,
    revoked_reason: null,
  }));

  const profiles: UserProfile[] = [
    {
      id: '44444444-4444-4444-8444-444444444401',
      email: 'superadmin@payledger.ph',
      full_name: 'Victor Navarro',
      avatar_url: null,
      phone: '+63 917 800 0001',
      address: 'Makati City, Metro Manila',
      department: 'Executive',
      position: 'Chief Operations Officer',
      role: 'SUPER_ADMIN',
      employee_id: null,
      employee_number: null,
      permissions: {
        can_edit_salary: true,
        can_manage_payroll: true,
        can_manage_holidays: true,
        can_view_reports: true,
      },
      is_active: true,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '44444444-4444-4444-8444-444444444402',
      email: 'admin@payledger.ph',
      full_name: 'Mateo Villanueva',
      avatar_url: null,
      phone: '+63 917 555 0101',
      address: 'BGC, Taguig City',
      department: 'Operations',
      position: 'Operations Supervisor',
      role: 'ADMIN',
      employee_id: employees[0].id,
      employee_number: employees[0].employee_number,
      permissions: {
        can_edit_salary: true,
        can_manage_payroll: true,
        can_manage_holidays: true,
        can_view_reports: true,
      },
      is_active: true,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '44444444-4444-4444-8444-444444444403',
      email: 'hr@payledger.ph',
      full_name: 'Clarissa Mendoza',
      avatar_url: null,
      phone: '+63 917 555 0102',
      address: 'Ortigas Center, Pasig City',
      department: 'Human Resources',
      position: 'Payroll & HR Specialist',
      role: 'HR',
      employee_id: employees[1].id,
      employee_number: employees[1].employee_number,
      permissions: {
        can_edit_salary: false,
        can_manage_payroll: false,
        can_manage_holidays: false,
        can_view_reports: true,
      },
      is_active: true,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: '44444444-4444-4444-8444-444444444404',
      email: 'rafael.santos@payledger.ph',
      full_name: 'Rafael Santos',
      avatar_url: null,
      phone: '+63 918 555 0103',
      address: 'Quezon City, Metro Manila',
      department: 'Logistics',
      position: 'Field Logistics Technician',
      role: 'EMPLOYEE',
      employee_id: employees[2].id,
      employee_number: employees[2].employee_number,
      permissions: {
        can_edit_salary: false,
        can_manage_payroll: false,
        can_manage_holidays: false,
        can_view_reports: false,
      },
      is_active: true,
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
      updated_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
  ];

  const holidays: Holiday[] = [
    {
      id: uid('hol'),
      holiday_date: '2026-01-01',
      name: "New Year's Day",
      holiday_type: 'REGULAR',
      description: 'Official Regular Holiday',
      is_verified: true,
      source: 'OFFICIAL_PH',
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: uid('hol'),
      holiday_date: '2026-05-01',
      name: 'Labor Day',
      holiday_type: 'REGULAR',
      description: 'Official Regular Holiday',
      is_verified: true,
      source: 'OFFICIAL_PH',
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: uid('hol'),
      holiday_date: '2026-11-01',
      name: "All Saints' Day",
      holiday_type: 'SPECIAL_NON_WORKING',
      description: 'Special Non-Working Holiday',
      is_verified: true,
      source: 'OFFICIAL_PH',
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: uid('hol'),
      holiday_date: '2026-11-30',
      name: 'Bonifacio Day',
      holiday_type: 'REGULAR',
      description: 'Official Regular Holiday',
      is_verified: true,
      source: 'OFFICIAL_PH',
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
    {
      id: uid('hol'),
      holiday_date: '2026-12-25',
      name: 'Christmas Day',
      holiday_type: 'REGULAR',
      description: 'Official Regular Holiday',
      is_verified: true,
      source: 'OFFICIAL_PH',
      created_at: `${twoDaysAgo}T00:00:00+08:00`,
    },
  ];

  const attendance: AttendanceRecord[] = [
    {
      id: '55555555-5555-4555-8555-555555555501',
      employee_id: employees[0].id,
      work_date: today,
      schedule_id: schedDefaultId,
      scheduled_time_in: buildManilaTimestamp(today, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(today, '17:00:00'),
      actual_time_in: buildManilaTimestamp(today, '07:52:00'),
      actual_time_out: null,
      early_arrival_minutes: 8,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 0,
      actual_hours: 0,
      paid_hours: 0,
      approved_overtime_hours: 0,
      status: 'ON_TIME',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: buildManilaTimestamp(today, '07:52:00'),
      updated_at: buildManilaTimestamp(today, '07:52:00'),
    },
    {
      id: '55555555-5555-4555-8555-555555555502',
      employee_id: employees[2].id,
      work_date: today,
      schedule_id: schedDefaultId,
      scheduled_time_in: buildManilaTimestamp(today, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(today, '17:00:00'),
      actual_time_in: buildManilaTimestamp(today, '08:14:00'),
      actual_time_out: null,
      early_arrival_minutes: 0,
      late_minutes: 14,
      undertime_minutes: 0,
      regular_hours: 0,
      actual_hours: 0,
      paid_hours: 0,
      approved_overtime_hours: 0,
      status: 'LATE',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: buildManilaTimestamp(today, '08:14:00'),
      updated_at: buildManilaTimestamp(today, '08:14:00'),
    },
    {
      id: '55555555-5555-4555-8555-555555555503',
      employee_id: employees[2].id,
      work_date: yesterday,
      schedule_id: schedDefaultId,
      scheduled_time_in: buildManilaTimestamp(yesterday, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(yesterday, '17:00:00'),
      actual_time_in: buildManilaTimestamp(yesterday, '07:58:00'),
      actual_time_out: buildManilaTimestamp(yesterday, '19:15:00'),
      early_arrival_minutes: 2,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 8,
      actual_hours: 10,
      paid_hours: 8,
      approved_overtime_hours: 0,
      status: 'ON_TIME',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: buildManilaTimestamp(yesterday, '07:58:00'),
      updated_at: buildManilaTimestamp(yesterday, '19:15:00'),
    },
    {
      id: '55555555-5555-4555-8555-555555555504',
      employee_id: employees[3].id,
      work_date: yesterday,
      schedule_id: schedDefaultId,
      scheduled_time_in: buildManilaTimestamp(yesterday, '08:00:00'),
      scheduled_time_out: buildManilaTimestamp(yesterday, '17:00:00'),
      actual_time_in: buildManilaTimestamp(yesterday, '08:00:00'),
      actual_time_out: buildManilaTimestamp(yesterday, '17:00:00'),
      early_arrival_minutes: 0,
      late_minutes: 0,
      undertime_minutes: 0,
      regular_hours: 8,
      actual_hours: 8,
      paid_hours: 8,
      approved_overtime_hours: 0,
      status: 'ON_TIME',
      day_classification: 'ORDINARY',
      is_rest_day: false,
      holiday_id: null,
      is_corrected: false,
      notes: null,
      created_at: buildManilaTimestamp(yesterday, '08:00:00'),
      updated_at: buildManilaTimestamp(yesterday, '17:00:00'),
    },
  ];

  const overtimeRequests: OvertimeRequest[] = [
    {
      id: uid('ot'),
      attendance_id: attendance[2].id,
      employee_id: employees[2].id,
      work_date: yesterday,
      scheduled_time_in: attendance[2].scheduled_time_in,
      actual_time_in: attendance[2].actual_time_in,
      scheduled_time_out: attendance[2].scheduled_time_out,
      actual_time_out: attendance[2].actual_time_out,
      decision: 'YES',
      requested_hours: 2,
      verified_hours: 2.25,
      approved_hours: 0,
      overtime_rate_applied: 132.81,
      approved_amount: 0,
      reason: 'Completed evening warehouse dispatch & unloading batch #44',
      status: 'PENDING',
      admin_remarks: null,
      reviewed_by: null,
      reviewed_at: null,
      created_at: buildManilaTimestamp(yesterday, '19:20:00'),
    },
  ];

  const leaveRequests: LeaveRequest[] = [
    {
      id: uid('lv'),
      employee_id: employees[1].id,
      leave_type: 'Vacation Leave',
      start_date: today,
      end_date: today,
      total_days: 1,
      is_paid: true,
      reason: 'Scheduled family appointment',
      attachment_path: null,
      status: 'APPROVED',
      admin_remarks: 'Approved by Operations',
      reviewed_by: profiles[0].id,
      reviewed_at: `${yesterday}T14:00:00+08:00`,
      created_at: `${twoDaysAgo}T10:00:00+08:00`,
    },
  ];

  const salaryHistory: SalaryHistoryRecord[] = [
    {
      id: uid('sal'),
      employee_id: employees[2].id,
      salary_type: 'DAILY',
      previous_daily_rate: 780,
      new_daily_rate: 850,
      previous_hourly_rate: 97.5,
      new_hourly_rate: 106.25,
      previous_monthly_rate: 0,
      new_monthly_rate: 0,
      previous_overtime_rate: 97.5,
      new_overtime_rate: 106.25,
      previous_allowances: 1200,
      new_allowances: 1400,
      previous_deductions: 650,
      new_deductions: 650,
      effective_date: '2026-01-01',
      reason: 'Annual merit & minimum wage alignment',
      changed_by: profiles[0].id,
      changed_by_name: profiles[0].full_name,
      created_at: '2026-01-01T09:00:00+08:00',
    },
  ];

  const initialEvents: AttendanceEvent[] = [];
  for (const a of attendance) {
    const emp = employees.find((e) => e.id === a.employee_id);
    if (!emp) continue;
    if (a.actual_time_in) {
      initialEvents.push({
        id: uid('ev'),
        attendance_id: a.id,
        employee_id: a.employee_id,
        employee_number: emp.employee_number,
        event_type: 'TIME_IN',
        recorded_at: a.actual_time_in,
        work_date: a.work_date,
        source: 'TERMINAL',
        device_info: null,
      });
    }
    if (a.actual_time_out) {
      initialEvents.push({
        id: uid('ev'),
        attendance_id: a.id,
        employee_id: a.employee_id,
        employee_number: emp.employee_number,
        event_type: 'TIME_OUT',
        recorded_at: a.actual_time_out,
        work_date: a.work_date,
        source: 'TERMINAL',
        device_info: null,
      });
    }
  }

  return {
    companySettings,
    schedules,
    employees,
    credentials,
    profiles,
    salaryHistory,
    holidays,
    attendance,
    attendanceEvents: initialEvents,
    corrections: [],
    overtimeRequests,
    leaveRequests,
    payrollPeriods: [],
    payrollRecords: [],
    payrollAdjustments: [],
    auditLogs: [
      {
        id: uid('aud'),
        actor_user_id: profiles[0].id,
        actor_role: 'SUPER_ADMIN',
        actor_name: profiles[0].full_name,
        action: 'WORKSPACE_INITIALIZED',
        table_name: 'company_settings',
        record_id: companySettings.id,
        previous_value: null,
        new_value: { timezone: 'Asia/Manila', attendance_mode: 'EMPLOYEE_NUMBER' },
        reason: 'Initialized workspace with Employee Number attendance',
        created_at: `${twoDaysAgo}T08:00:00+08:00`,
      },
    ],
    syncQueue: [],
    localPasswords: {
      'superadmin@payledger.ph': 'PreviewAdmin123!',
      'admin@payledger.ph': 'PreviewAdmin123!',
      'hr@payledger.ph': 'PreviewHr123!',
      'rafael.santos@payledger.ph': 'PreviewEmp123!',
    },
  };
}

function loadLocalDb(): AppDatabaseState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      return JSON.parse(raw) as AppDatabaseState;
    }
  } catch {
    // ignore storage parse failure
  }
  const initial = createInitialPreviewState();
  saveLocalDb(initial);
  return initial;
}

function saveLocalDb(state: AppDatabaseState) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore storage quota errors
  }
}

export const dataService = {
  isLiveSupabase: () => isSupabaseConfigured && supabase !== null,

  // ==================== AUTH & PROFILES (NO GOOGLE AUTH) ====================
  async getCurrentProfile(): Promise<UserProfile | null> {
    if (supabase) {
      const { data: sessionData } = await supabase.auth.getSession();
      const user = sessionData.session?.user;
      if (!user) return null;
      const { data, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
      if (error) return null;
      return data as UserProfile;
    }

    const sessionUid = localStorage.getItem(SESSION_KEY);
    if (!sessionUid) return null;
    const db = loadLocalDb();
    return db.profiles.find((p) => p.id === sessionUid && p.is_active) ?? null;
  },

  async hasAnySuperAdmin(): Promise<boolean> {
    if (supabase) {
      const { count } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('role', 'SUPER_ADMIN')
        .eq('is_active', true);
      return (count ?? 0) > 0;
    }
    const db = loadLocalDb();
    return db.profiles.some((p) => p.role === 'SUPER_ADMIN' && p.is_active);
  },

  async signInWithPassword(email: string, password: string): Promise<UserProfile> {
    if (supabase) {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error || !data.user) throw new Error(error?.message ?? 'Invalid email or password.');
      const { data: profile, error: profErr } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .single();
      if (profErr || !profile) {
        throw new Error('Profile record not found in database.');
      }
      if (!profile.is_active) {
        await supabase.auth.signOut();
        throw new Error('This account has been deactivated.');
      }
      return profile as UserProfile;
    }

    const db = loadLocalDb();
    const normalized = email.trim().toLowerCase();
    const profile = db.profiles.find((p) => p.email.toLowerCase() === normalized);
    if (!profile) throw new Error('Account not found for that email address.');
    if (!profile.is_active) throw new Error('Account is deactivated.');
    const expected = db.localPasswords[normalized];
    if (expected && password !== expected) {
      throw new Error('Incorrect password.');
    }
    localStorage.setItem(SESSION_KEY, profile.id);
    return profile;
  },

  async resetPassword(email: string): Promise<void> {
    if (supabase) {
      const { error } = await supabase.auth.resetPasswordForEmail(email);
      if (error) throw new Error(error.message);
      return;
    }
    const db = loadLocalDb();
    const exists = db.profiles.some((p) => p.email.toLowerCase() === email.trim().toLowerCase());
    if (!exists) throw new Error('No account matches that email address.');
  },

  async provisionFirstSuperAdmin(payload: {
    email: string;
    password: string;
    full_name: string;
    phone?: string;
  }): Promise<UserProfile> {
    if (supabase) {
      // Try protected Edge Function first; fallback to auth.signUp + RPC provision_first_super_admin
      const { data: fnData, error: fnErr } = await supabase.functions.invoke('provision-super-admin', {
        body: { mode: 'FIRST_SUPER_ADMIN', ...payload },
      });
      if (!fnErr && fnData?.success) {
        return await this.signInWithPassword(payload.email, payload.password);
      }
      const { data: signUpData, error: signUpErr } = await supabase.auth.signUp({
        email: payload.email,
        password: payload.password,
        options: { data: { full_name: payload.full_name } },
      });
      if (signUpErr || !signUpData.user) throw new Error(signUpErr?.message ?? 'Failed to register Super Admin');
      const { error: rpcErr } = await supabase.rpc('provision_first_super_admin', {
        p_full_name: payload.full_name,
        p_phone: payload.phone ?? null,
      });
      if (rpcErr) throw new Error(rpcErr.message);
      const prof = await this.getCurrentProfile();
      if (!prof) throw new Error('Super Admin profile provisioned; check email confirmation if required.');
      return prof;
    }

    const db = loadLocalDb();
    const newId = uid('usr');
    const now = new Date().toISOString();
    const profile: UserProfile = {
      id: newId,
      email: payload.email.trim().toLowerCase(),
      full_name: payload.full_name.trim(),
      avatar_url: null,
      phone: payload.phone ?? null,
      address: null,
      department: 'Executive',
      position: 'Super Administrator',
      role: 'SUPER_ADMIN',
      employee_id: null,
      employee_number: null,
      permissions: {
        can_edit_salary: true,
        can_manage_payroll: true,
        can_manage_holidays: true,
        can_view_reports: true,
      },
      is_active: true,
      created_at: now,
      updated_at: now,
    };
    db.profiles.push(profile);
    db.localPasswords[profile.email] = payload.password;
    db.auditLogs.unshift({
      id: uid('aud'),
      actor_user_id: newId,
      actor_role: 'SUPER_ADMIN',
      actor_name: profile.full_name,
      action: 'PROVISION_FIRST_SUPER_ADMIN',
      table_name: 'profiles',
      record_id: newId,
      previous_value: null,
      new_value: { email: profile.email, role: 'SUPER_ADMIN' },
      reason: 'First Super Admin setup',
      created_at: now,
    });
    saveLocalDb(db);
    localStorage.setItem(SESSION_KEY, newId);
    return profile;
  },

  async signOut(): Promise<void> {
    if (supabase) {
      await supabase.auth.signOut();
      return;
    }
    localStorage.removeItem(SESSION_KEY);
  },

  async updateOwnProfile(
    userId: string,
    updates: Partial<Pick<UserProfile, 'full_name' | 'phone' | 'address' | 'avatar_url'>>
  ): Promise<UserProfile> {
    if (supabase) {
      const { data, error } = await supabase
        .from('profiles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', userId)
        .select('*')
        .single();
      if (error) throw new Error(error.message);
      return data as UserProfile;
    }
    const db = loadLocalDb();
    const idx = db.profiles.findIndex((p) => p.id === userId);
    if (idx === -1) throw new Error('Profile not found.');
    db.profiles[idx] = { ...db.profiles[idx], ...updates, updated_at: new Date().toISOString() };
    saveLocalDb(db);
    return db.profiles[idx];
  },

  // ==================== FULL SNAPSHOT LOAD ====================
  async loadWorkspaceData(actor: UserProfile): Promise<Omit<AppDatabaseState, 'localPasswords'>> {
    if (supabase) {
      const [
        settingsRes,
        schedRes,
        empRes,
        credRes,
        profRes,
        salRes,
        holRes,
        attRes,
        corrRes,
        otRes,
        leaveRes,
        periodRes,
        payRecRes,
        adjRes,
        auditRes,
        syncRes,
      ] = await Promise.all([
        supabase.from('company_settings').select('*').limit(1).maybeSingle(),
        supabase.from('schedules').select('*').order('name'),
        supabase.from('employees').select('*').order('employee_number'),
        supabase.from('employee_number_credentials').select('*'),
        supabase.from('profiles').select('*').order('created_at', { ascending: false }),
        supabase.from('employee_salary_history').select('*').order('created_at', { ascending: false }),
        supabase.from('holidays').select('*').order('holiday_date'),
        supabase.from('attendance').select('*').order('work_date', { ascending: false }).limit(500),
        supabase.from('attendance_corrections').select('*').order('created_at', { ascending: false }),
        supabase.from('overtime_requests').select('*').order('created_at', { ascending: false }),
        supabase.from('leave_requests').select('*').order('created_at', { ascending: false }),
        supabase.from('payroll_periods').select('*').order('start_date', { ascending: false }),
        supabase.from('payroll_records').select('*').order('created_at', { ascending: false }),
        supabase.from('payroll_adjustments').select('*').order('created_at', { ascending: false }),
        supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(200),
        supabase.from('integration_sync_queue').select('*').order('created_at', { ascending: false }).limit(100),
      ]);

      const fallback = createInitialPreviewState();
      return {
        companySettings: (settingsRes.data as CompanySettings) ?? fallback.companySettings,
        schedules: (schedRes.data as Schedule[]) ?? [],
        employees: (empRes.data as Employee[]) ?? [],
        credentials: (credRes.data as EmployeeNumberCredential[]) ?? [],
        profiles: (profRes.data as UserProfile[]) ?? [actor],
        salaryHistory: (salRes.data as SalaryHistoryRecord[]) ?? [],
        holidays: (holRes.data as Holiday[]) ?? [],
        attendance: (attRes.data as AttendanceRecord[]) ?? [],
        attendanceEvents: [],
        corrections: (corrRes.data as AttendanceCorrection[]) ?? [],
        overtimeRequests: (otRes.data as OvertimeRequest[]) ?? [],
        leaveRequests: (leaveRes.data as LeaveRequest[]) ?? [],
        payrollPeriods: (periodRes.data as PayrollPeriod[]) ?? [],
        payrollRecords: (payRecRes.data as PayrollRecord[]) ?? [],
        payrollAdjustments: (adjRes.data as PayrollAdjustment[]) ?? [],
        auditLogs: (auditRes.data as AuditLog[]) ?? [],
        syncQueue: (syncRes.data as IntegrationSyncItem[]) ?? [],
      };
    }

    const db = loadLocalDb();
    const { localPasswords: _ignore, ...rest } = db;
    void _ignore;
    return rest;
  },

  // ==================== STORAGE FILE UPLOADS ====================
  async uploadEmployeePhoto(employeeId: string, file: File): Promise<string> {
    if (supabase) {
      const ext = file.name.split('.').pop() || 'png';
      const path = `${employeeId}/avatar-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('employee-photos').upload(path, file, { upsert: true });
      if (error) throw new Error(error.message);
      const { data: signed } = await supabase.storage.from('employee-photos').createSignedUrl(path, 60 * 60 * 24 * 7);
      return signed?.signedUrl ?? path;
    }

    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('Failed to read image file'));
      reader.readAsDataURL(file);
    });
  },

  async uploadCompanyLogo(file: File): Promise<string> {
    if (supabase) {
      const ext = file.name.split('.').pop() || 'png';
      const path = `logo-${Date.now()}.${ext}`;
      const { error } = await supabase.storage.from('company-assets').upload(path, file, { upsert: true });
      if (error) throw new Error(error.message);
      const { data } = supabase.storage.from('company-assets').getPublicUrl(path);
      return data.publicUrl;
    }
    return await new Promise<string>((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result));
      reader.onerror = () => reject(new Error('Failed to read logo file'));
      reader.readAsDataURL(file);
    });
  },

  // ==================== AUDIT LOG HELPER ====================
  async writeAuditLog(
    actor: UserProfile,
    action: string,
    tableName: string,
    recordId: string | null,
    previousValue: Record<string, unknown> | null,
    newValue: Record<string, unknown> | null,
    reason?: string
  ) {
    if (supabase) {
      await supabase.from('audit_logs').insert({
        actor_user_id: actor.id,
        actor_role: actor.role,
        action,
        table_name: tableName,
        record_id: recordId,
        previous_value: previousValue,
        new_value: newValue,
        reason: reason ?? null,
      });
      return;
    }
    const db = loadLocalDb();
    db.auditLogs.unshift({
      id: uid('aud'),
      actor_user_id: actor.id,
      actor_role: actor.role,
      actor_name: actor.full_name,
      action,
      table_name: tableName,
      record_id: recordId,
      previous_value: previousValue,
      new_value: newValue,
      reason: reason ?? null,
      created_at: new Date().toISOString(),
    });
    saveLocalDb(db);
  },

  // ==================== EMPLOYEE NUMBER LOOKUP & ATTENDANCE PUNCH ====================
  async lookupEmployeeByNumber(employeeNumber: string): Promise<{
    found: boolean;
    employee_number?: string;
    full_name?: string;
    position?: string;
    department?: string;
    photo_url?: string | null;
    is_active?: boolean;
    next_event?: 'TIME_IN' | 'TIME_OUT';
  }> {
    const cleaned = employeeNumber.trim().toUpperCase();
    if (!cleaned) return { found: false };

    if (supabase) {
      const { data, error } = await supabase.rpc('lookup_employee_for_kiosk', {
        p_employee_number: cleaned,
      });
      if (error || !data) return { found: false };
      return data as {
        found: boolean;
        employee_number?: string;
        full_name?: string;
        position?: string;
        department?: string;
        photo_url?: string | null;
        is_active?: boolean;
        next_event?: 'TIME_IN' | 'TIME_OUT';
      };
    }

    const db = loadLocalDb();
    const emp = db.employees.find((e) => e.employee_number.toUpperCase() === cleaned);
    if (!emp) return { found: false };

    const now = new Date();
    const schedule =
      db.schedules.find((s) => s.id === (emp.schedule_id ?? db.companySettings.default_schedule_id)) ??
      db.schedules[0];
    const todayStr = toManilaDateString(now);
    const yesterdayStr = addDaysToDateString(todayStr, -1);
    const openYesterday = db.attendance.find(
      (a) => a.employee_id === emp.id && a.work_date === yesterdayStr && a.actual_time_in && !a.actual_time_out
    );
    const workDate = deriveWorkDate(now, schedule, Boolean(openYesterday));
    const att = db.attendance.find((a) => a.employee_id === emp.id && a.work_date === workDate);
    const nextEvent: 'TIME_IN' | 'TIME_OUT' =
      att && att.actual_time_in && !att.actual_time_out ? 'TIME_OUT' : 'TIME_IN';

    return {
      found: true,
      employee_number: emp.employee_number,
      full_name: emp.full_name,
      position: emp.position,
      department: emp.department,
      photo_url: emp.photo_url,
      is_active: emp.is_active && emp.employment_status === 'ACTIVE',
      next_event: nextEvent,
    };
  },

  async listEnrolledFaces(): Promise<EnrolledFaceCandidate[]> {
    if (supabase) {
      const { data, error } = await supabase.rpc('list_enrolled_face_descriptors');
      if (!error && Array.isArray(data)) {
        return data as EnrolledFaceCandidate[];
      }
      const { data: rows } = await supabase
        .from('employees')
        .select('id, employee_number, full_name, position, department, photo_url, face_descriptor')
        .eq('is_active', true)
        .eq('employment_status', 'ACTIVE');
      if (Array.isArray(rows)) {
        return rows
          .filter((r) => Array.isArray(r.face_descriptor) && r.face_descriptor.length === 128)
          .map((r) => ({
            employee_id: r.id,
            employee_number: r.employee_number,
            full_name: r.full_name,
            position: r.position,
            department: r.department,
            photo_url: r.photo_url,
            face_descriptor: r.face_descriptor as number[],
          }));
      }
      return [];
    }

    const db = loadLocalDb();
    return db.employees
      .filter(
        (e) =>
          e.is_active &&
          e.employment_status === 'ACTIVE' &&
          Array.isArray(e.face_descriptor) &&
          e.face_descriptor.length === 128
      )
      .map((e) => ({
        employee_id: e.id,
        employee_number: e.employee_number,
        full_name: e.full_name,
        position: e.position,
        department: e.department,
        photo_url: e.photo_url,
        face_descriptor: e.face_descriptor as number[],
      }));
  },

  async punchAttendanceByEmployeeNumber(
    employeeNumber: string,
    options?: { pin?: string; source?: 'TERMINAL' | 'KIOSK' }
  ): Promise<AttendancePunchResult> {
    const cleaned = employeeNumber.trim().toUpperCase();
    if (!cleaned) {
      return { success: false, error_code: 'MISSING_NUMBER', message: 'Please enter an Employee Number.' };
    }

    if (supabase) {
      const { data, error } = await supabase.rpc('record_employee_number_attendance', {
        p_employee_number: cleaned,
        p_pin: options?.pin ?? null,
        p_source: options?.source ?? 'TERMINAL',
        p_device_info: navigator.userAgent,
      });
      if (error) {
        return { success: false, error_code: 'RPC_ERROR', message: error.message };
      }
      return data as AttendancePunchResult;
    }

    const db = loadLocalDb();
    const emp = db.employees.find((e) => e.employee_number.toUpperCase() === cleaned);
    if (!emp) {
      return { success: false, error_code: 'UNKNOWN_EMPLOYEE', message: `Employee Number "${cleaned}" was not found.` };
    }
    if (!emp.is_active || emp.employment_status !== 'ACTIVE') {
      return { success: false, error_code: 'DEACTIVATED_EMPLOYEE', message: 'Employee account is deactivated.' };
    }

    const cred = db.credentials.find((c) => c.employee_id === emp.id);
    if (cred && cred.credential_status !== 'ACTIVE') {
      return {
        success: false,
        error_code: 'REVOKED_CREDENTIAL',
        message: 'Attendance access for this Employee Number is suspended or revoked.',
      };
    }
    if (cred?.pin_required) {
      if (!options?.pin || options.pin !== cred.pin_plain_preview) {
        return { success: false, error_code: 'INVALID_PIN', message: 'Invalid attendance PIN for this Employee Number.' };
      }
    }

    const now = new Date();
    const nowIso = now.toISOString();

    const schedule =
      db.schedules.find((s) => s.id === (emp.schedule_id ?? db.companySettings.default_schedule_id)) ??
      db.schedules[0];

    const todayStr = toManilaDateString(now);
    const yesterdayStr = addDaysToDateString(todayStr, -1);
    const openYesterday = db.attendance.find(
      (a) => a.employee_id === emp.id && a.work_date === yesterdayStr && a.actual_time_in && !a.actual_time_out
    );
    const workDate = deriveWorkDate(now, schedule, Boolean(openYesterday));
    const holiday = db.holidays.find((h) => h.holiday_date === workDate && h.is_verified) ?? null;

    const existingIdx = db.attendance.findIndex((a) => a.employee_id === emp.id && a.work_date === workDate);
    if (existingIdx === -1) {
      // 1st punch: TIME IN
      const calc = calculateAttendanceMetrics({
        workDate,
        schedule,
        actualTimeIn: nowIso,
        actualTimeOut: null,
        restDays: emp.rest_days,
        holiday,
      });

      const newRec: AttendanceRecord = {
        id: uid('att'),
        employee_id: emp.id,
        work_date: workDate,
        schedule_id: schedule.id,
        scheduled_time_in: calc.scheduledTimeIn,
        scheduled_time_out: calc.scheduledTimeOut,
        actual_time_in: nowIso,
        actual_time_out: null,
        early_arrival_minutes: calc.earlyArrivalMinutes,
        late_minutes: calc.lateMinutes,
        undertime_minutes: 0,
        regular_hours: 0,
        actual_hours: 0,
        paid_hours: 0,
        approved_overtime_hours: 0,
        status: calc.status,
        day_classification: calc.dayClassification,
        is_rest_day: calc.isRestDay,
        holiday_id: holiday?.id ?? null,
        is_corrected: false,
        notes: null,
        created_at: nowIso,
        updated_at: nowIso,
      };
      db.attendance.unshift(newRec);
      db.attendanceEvents.push({
        id: uid('ev'),
        attendance_id: newRec.id,
        employee_id: emp.id,
        employee_number: emp.employee_number,
        event_type: 'TIME_IN',
        recorded_at: nowIso,
        work_date: workDate,
        source: options?.source ?? 'TERMINAL',
        device_info: navigator.userAgent,
      });
      saveLocalDb(db);
      return {
        success: true,
        event_type: 'TIME_IN',
        employee_id: emp.id,
        employee_number: emp.employee_number,
        full_name: emp.full_name,
        position: emp.position,
        department: emp.department,
        photo_url: emp.photo_url,
        work_date: workDate,
        recorded_at: nowIso,
        status: calc.status,
        late_minutes: calc.lateMinutes,
      };
    }

    const existing = db.attendance[existingIdx];
    if (existing.actual_time_in && !existing.actual_time_out) {
      // Even punch (2nd, 4th, ...): TIME OUT
      db.attendanceEvents.push({
        id: uid('ev'),
        attendance_id: existing.id,
        employee_id: emp.id,
        employee_number: emp.employee_number,
        event_type: 'TIME_OUT',
        recorded_at: nowIso,
        work_date: workDate,
        source: options?.source ?? 'TERMINAL',
        device_info: navigator.userAgent,
      });

      const dayEvents = db.attendanceEvents
        .filter((ev) => ev.attendance_id === existing.id)
        .sort((a, b) => a.recorded_at.localeCompare(b.recorded_at));

      // Pair TIME_IN -> TIME_OUT sessions across the workday
      let rawHours = 0;
      let sessionCount = 0;
      for (let i = 0; i < dayEvents.length - 1; i++) {
        if (dayEvents[i].event_type === 'TIME_IN' && dayEvents[i + 1].event_type === 'TIME_OUT') {
          const ms = new Date(dayEvents[i + 1].recorded_at).getTime() - new Date(dayEvents[i].recorded_at).getTime();
          if (ms > 0) {
            rawHours += ms / 3_600_000;
            sessionCount += 1;
          }
          i += 1;
        }
      }

      const calc = calculateAttendanceMetrics({
        workDate,
        schedule,
        actualTimeIn: existing.actual_time_in,
        actualTimeOut: nowIso,
        restDays: emp.rest_days,
        holiday,
        approvedOvertimeHours: existing.approved_overtime_hours,
      });

      const multiSessionActual =
        sessionCount > 1
          ? Number(Math.max(0, rawHours).toFixed(2))
          : calc.actualHours;
      const multiSessionRegular =
        sessionCount > 1
          ? Number(Math.min(schedule.regular_hours, multiSessionActual).toFixed(2))
          : calc.regularHours;
      const multiSessionPaid = Number((multiSessionRegular + existing.approved_overtime_hours).toFixed(2));

      db.attendance[existingIdx] = {
        ...existing,
        actual_time_out: nowIso,
        undertime_minutes: calc.undertimeMinutes,
        actual_hours: multiSessionActual,
        regular_hours: multiSessionRegular,
        paid_hours: multiSessionPaid,
        status: calc.status,
        updated_at: nowIso,
      };
      saveLocalDb(db);
      return {
        success: true,
        event_type: 'TIME_OUT',
        employee_id: emp.id,
        employee_number: emp.employee_number,
        full_name: emp.full_name,
        position: emp.position,
        department: emp.department,
        photo_url: emp.photo_url,
        work_date: workDate,
        recorded_at: nowIso,
        status: calc.status,
        late_minutes: existing.late_minutes,
        undertime_minutes: calc.undertimeMinutes,
      };
    }

    // Odd subsequent punch (3rd, 5th, ...): Re-entry TIME IN
    db.attendance[existingIdx] = {
      ...existing,
      actual_time_out: null,
      updated_at: nowIso,
    };
    db.attendanceEvents.push({
      id: uid('ev'),
      attendance_id: existing.id,
      employee_id: emp.id,
      employee_number: emp.employee_number,
      event_type: 'TIME_IN',
      recorded_at: nowIso,
      work_date: workDate,
      source: options?.source ?? 'TERMINAL',
      device_info: navigator.userAgent,
    });
    saveLocalDb(db);
    return {
      success: true,
      event_type: 'TIME_IN',
      employee_id: emp.id,
      employee_number: emp.employee_number,
      full_name: emp.full_name,
      position: emp.position,
      department: emp.department,
      photo_url: emp.photo_url,
      work_date: workDate,
      recorded_at: nowIso,
      status: existing.status,
      late_minutes: existing.late_minutes,
    };
  },

  // ==================== EMPLOYEES & CREDENTIALS ====================
  async createEmployeesBulk(
    actor: UserProfile,
    rows: Array<{
      input: Omit<Employee, 'id' | 'is_active' | 'deactivated_at' | 'created_at' | 'updated_at'>;
      pin?: string;
    }>
  ): Promise<{ created: Employee[]; skipped: Array<{ employee_number: string; reason: string }> }> {
    const created: Employee[] = [];
    const skipped: Array<{ employee_number: string; reason: string }> = [];
    for (const row of rows) {
      try {
        const emp = await this.createEmployee(actor, row.input, row.pin);
        created.push(emp);
      } catch (err) {
        skipped.push({
          employee_number: row.input.employee_number || '(blank)',
          reason: (err as Error).message,
        });
      }
    }
    return { created, skipped };
  },

  async createEmployee(
    actor: UserProfile,
    input: Omit<Employee, 'id' | 'is_active' | 'deactivated_at' | 'created_at' | 'updated_at'>,
    pin?: string
  ): Promise<Employee> {
    const normalizedNum = input.employee_number.trim().toUpperCase();
    if (!normalizedNum) throw new Error('Employee Number is required.');
    const now = new Date().toISOString();
    const itemizedSum =
      (input.sss_share ?? 0) +
      (input.phic_share ?? 0) +
      (input.pagibig_share ?? 0) +
      (input.sss_loan ?? 0) +
      (input.pagibig_loan ?? 0) +
      (input.coop_share ?? 0) +
      (input.coop_loan ?? 0) +
      (input.donation ?? 0) +
      (input.cash_advance ?? 0);
    const resolvedDefaultDeductions = itemizedSum > 0 ? itemizedSum : input.default_deductions ?? 0;
    const normalizedInput = {
      ...input,
      employee_number: normalizedNum,
      weekly_rate: input.weekly_rate ?? (input.daily_rate ? Number((input.daily_rate * 6).toFixed(2)) : 0),
      overtime_rate: input.overtime_rate,
      meal_allowance: input.meal_allowance,
      transport_allowance: input.transport_allowance,
      other_allowances: input.other_allowances,
      ot1_pay: input.ot1_pay ?? 0,
      ot2_pay: input.ot2_pay ?? 0,
      sil_sl_vl_pay: input.sil_sl_vl_pay ?? 0,
      paid_leave_pay: input.paid_leave_pay ?? 0,
      legal_holiday_pay: input.legal_holiday_pay ?? 0,
      special_holiday_pay: input.special_holiday_pay ?? 0,
      sss_share: input.sss_share ?? 0,
      sss_share_remarks: input.sss_share_remarks ?? '',
      phic_share: input.phic_share ?? 0,
      phic_share_remarks: input.phic_share_remarks ?? '',
      pagibig_share: input.pagibig_share ?? 0,
      sss_loan: input.sss_loan ?? 0,
      pagibig_loan: input.pagibig_loan ?? 0,
      coop_share: input.coop_share ?? 0,
      coop_loan: input.coop_loan ?? 0,
      donation: input.donation ?? 0,
      cash_advance: input.cash_advance ?? 0,
      face_descriptor: input.face_descriptor ?? null,
      face_enrolled_at: input.face_enrolled_at ?? null,
      default_deductions: resolvedDefaultDeductions,
    };

    if (supabase) {
      const { data: dup } = await supabase
        .from('employees')
        .select('id')
        .eq('employee_number', normalizedNum)
        .maybeSingle();
      if (dup) throw new Error(`Employee Number "${normalizedNum}" is already assigned.`);

      let insertRes = await supabase
        .from('employees')
        .insert({ ...normalizedInput, is_active: true })
        .select('*')
        .single();

      if (insertRes.error && /face_descriptor|face_enrolled_at/i.test(insertRes.error.message)) {
        const { face_descriptor: _fd, face_enrolled_at: _fe, ...withoutFace } = normalizedInput;
        insertRes = await supabase
          .from('employees')
          .insert({ ...withoutFace, is_active: true })
          .select('*')
          .single();
      }

      if (insertRes.error) throw new Error(insertRes.error.message);
      const data = insertRes.data;

      await supabase.from('employee_number_credentials').insert({
        employee_id: data.id,
        employee_number: normalizedNum,
        credential_status: 'ACTIVE',
        pin_required: Boolean(pin),
      });

      await this.writeAuditLog(actor, 'REGISTER_EMPLOYEE', 'employees', data.id, null, {
        employee_number: normalizedNum,
        full_name: input.full_name,
        face_enrolled: Boolean(normalizedInput.face_descriptor),
      });
      return data as Employee;
    }

    const db = loadLocalDb();
    if (db.employees.some((e) => e.employee_number.toUpperCase() === normalizedNum)) {
      throw new Error(`Employee Number "${normalizedNum}" is already assigned.`);
    }
    const newEmp: Employee = {
      ...normalizedInput,
      id: uid('emp'),
      is_active: true,
      deactivated_at: null,
      created_at: now,
      updated_at: now,
    };
    db.employees.push(newEmp);
    db.credentials.push({
      id: uid('cred'),
      employee_id: newEmp.id,
      employee_number: normalizedNum,
      credential_status: 'ACTIVE',
      pin_required: Boolean(pin),
      pin_plain_preview: pin || undefined,
      issued_at: now,
      revoked_at: null,
      revoked_reason: null,
    });
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'REGISTER_EMPLOYEE', 'employees', newEmp.id, null, {
      employee_number: normalizedNum,
      full_name: newEmp.full_name,
    });
    return newEmp;
  },

  async updateEmployee(actor: UserProfile, employeeId: string, updates: Partial<Employee>): Promise<Employee> {
    const now = new Date().toISOString();
    if (supabase) {
      const { data: prev } = await supabase.from('employees').select('*').eq('id', employeeId).single();
      const { data, error } = await supabase
        .from('employees')
        .update({ ...updates, updated_at: now })
        .eq('id', employeeId)
        .select('*')
        .single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'UPDATE_EMPLOYEE', 'employees', employeeId, prev, updates);
      return data as Employee;
    }

    const db = loadLocalDb();
    const idx = db.employees.findIndex((e) => e.id === employeeId);
    if (idx === -1) throw new Error('Employee not found.');
    const prev = { ...db.employees[idx] };
    db.employees[idx] = { ...prev, ...updates, updated_at: now };
    if (updates.employee_number) {
      const credIdx = db.credentials.findIndex((c) => c.employee_id === employeeId);
      if (credIdx !== -1) {
        db.credentials[credIdx].employee_number = updates.employee_number;
      }
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'UPDATE_EMPLOYEE', 'employees', employeeId, prev, updates);
    return db.employees[idx];
  },

  async updateEmployeeCredential(
    actor: UserProfile,
    employeeId: string,
    updates: { credential_status?: 'ACTIVE' | 'SUSPENDED' | 'REVOKED'; pin_required?: boolean; pin?: string; revoked_reason?: string }
  ): Promise<void> {
    const now = new Date().toISOString();
    if (supabase) {
      await supabase
        .from('employee_number_credentials')
        .update({
          credential_status: updates.credential_status,
          pin_required: updates.pin_required,
          revoked_at: updates.credential_status === 'REVOKED' ? now : null,
          revoked_reason: updates.revoked_reason ?? null,
          updated_at: now,
        })
        .eq('employee_id', employeeId);
      await this.writeAuditLog(actor, 'UPDATE_EMPLOYEE_CREDENTIAL', 'employee_number_credentials', employeeId, null, updates);
      return;
    }

    const db = loadLocalDb();
    const idx = db.credentials.findIndex((c) => c.employee_id === employeeId);
    if (idx !== -1) {
      db.credentials[idx] = {
        ...db.credentials[idx],
        credential_status: updates.credential_status ?? db.credentials[idx].credential_status,
        pin_required: updates.pin_required ?? db.credentials[idx].pin_required,
        pin_plain_preview: updates.pin !== undefined ? updates.pin : db.credentials[idx].pin_plain_preview,
        revoked_at: updates.credential_status === 'REVOKED' ? now : null,
        revoked_reason: updates.revoked_reason ?? null,
      };
      saveLocalDb(db);
    }
    await this.writeAuditLog(actor, 'UPDATE_EMPLOYEE_CREDENTIAL', 'employee_number_credentials', employeeId, null, updates);
  },

  // ==================== SALARY UPDATES (EFFECTIVE-DATED HISTORY) ====================
  async updateEmployeeSalary(
    actor: UserProfile,
    employee: Employee,
    newRates: {
      salary_type: Employee['salary_type'];
      daily_rate: number;
      hourly_rate: number;
      weekly_rate?: number;
      monthly_rate: number;
      overtime_rate: number;
      meal_allowance: number;
      transport_allowance: number;
      other_allowances: number;
      default_deductions: number;
      ot1_pay?: number;
      ot2_pay?: number;
      sil_sl_vl_pay?: number;
      paid_leave_pay?: number;
      legal_holiday_pay?: number;
      special_holiday_pay?: number;
      sss_share?: number;
      sss_share_remarks?: string;
      phic_share?: number;
      phic_share_remarks?: string;
      pagibig_share?: number;
      sss_loan?: number;
      pagibig_loan?: number;
      coop_share?: number;
      coop_loan?: number;
      donation?: number;
      cash_advance?: number;
      effective_date: string;
      reason: string;
    }
  ): Promise<void> {
    const prevAllowances = employee.meal_allowance + employee.transport_allowance + employee.other_allowances;
    const newAllowances = newRates.meal_allowance + newRates.transport_allowance + newRates.other_allowances;
    const now = new Date().toISOString();

    const ot1Pay = newRates.ot1_pay ?? employee.ot1_pay ?? 0;
    const ot2Pay = newRates.ot2_pay ?? employee.ot2_pay ?? 0;
    const silSlVlPay = newRates.sil_sl_vl_pay ?? employee.sil_sl_vl_pay ?? 0;
    const paidLeavePay = newRates.paid_leave_pay ?? employee.paid_leave_pay ?? 0;
    const legalHolidayPay = newRates.legal_holiday_pay ?? employee.legal_holiday_pay ?? 0;
    const specialHolidayPay = newRates.special_holiday_pay ?? employee.special_holiday_pay ?? 0;

    const sssShare = newRates.sss_share ?? employee.sss_share ?? 0;
    const sssShareRemarks = newRates.sss_share_remarks ?? employee.sss_share_remarks ?? '';
    const phicShare = newRates.phic_share ?? employee.phic_share ?? 0;
    const phicShareRemarks = newRates.phic_share_remarks ?? employee.phic_share_remarks ?? '';
    const pagibigShare = newRates.pagibig_share ?? employee.pagibig_share ?? 0;
    const sssLoan = newRates.sss_loan ?? employee.sss_loan ?? 0;
    const pagibigLoan = newRates.pagibig_loan ?? employee.pagibig_loan ?? 0;
    const coopShare = newRates.coop_share ?? employee.coop_share ?? 0;
    const coopLoan = newRates.coop_loan ?? employee.coop_loan ?? 0;
    const donation = newRates.donation ?? employee.donation ?? 0;
    const cashAdvance = newRates.cash_advance ?? employee.cash_advance ?? 0;
    const itemizedSum =
      sssShare + phicShare + pagibigShare + sssLoan + pagibigLoan + coopShare + coopLoan + donation + cashAdvance;
    const totalDeductions = itemizedSum > 0 ? itemizedSum : newRates.default_deductions;

    const deductionsSnapshot = {
      ot1_pay: ot1Pay,
      ot2_pay: ot2Pay,
      sil_sl_vl_pay: silSlVlPay,
      paid_leave_pay: paidLeavePay,
      legal_holiday_pay: legalHolidayPay,
      special_holiday_pay: specialHolidayPay,
      sss_share: sssShare,
      sss_share_remarks: sssShareRemarks,
      phic_share: phicShare,
      phic_share_remarks: phicShareRemarks,
      pagibig_share: pagibigShare,
      sss_loan: sssLoan,
      pagibig_loan: pagibigLoan,
      coop_share: coopShare,
      coop_loan: coopLoan,
      donation,
      cash_advance: cashAdvance,
    };

    const weeklyRate =
      newRates.weekly_rate ??
      employee.weekly_rate ??
      Number((newRates.daily_rate * 6).toFixed(2));

    const historyEntry = {
      employee_id: employee.id,
      salary_type: newRates.salary_type,
      previous_daily_rate: employee.daily_rate,
      new_daily_rate: newRates.daily_rate,
      previous_hourly_rate: employee.hourly_rate,
      new_hourly_rate: newRates.hourly_rate,
      previous_weekly_rate: employee.weekly_rate ?? Number((employee.daily_rate * 6).toFixed(2)),
      new_weekly_rate: weeklyRate,
      previous_monthly_rate: employee.monthly_rate,
      new_monthly_rate: newRates.monthly_rate,
      previous_overtime_rate: employee.overtime_rate,
      new_overtime_rate: newRates.overtime_rate,
      previous_allowances: prevAllowances,
      new_allowances: newAllowances,
      previous_deductions: employee.default_deductions,
      new_deductions: totalDeductions,
      deductions_snapshot: deductionsSnapshot,
      effective_date: newRates.effective_date,
      reason: newRates.reason,
      changed_by: actor.id,
    };

    if (supabase) {
      const { error: histErr } = await supabase.from('employee_salary_history').insert(historyEntry);
      if (histErr) throw new Error(histErr.message);

      const { error: empErr } = await supabase
        .from('employees')
        .update({
          salary_type: newRates.salary_type,
          daily_rate: newRates.daily_rate,
          hourly_rate: newRates.hourly_rate,
          weekly_rate: weeklyRate,
          monthly_rate: newRates.monthly_rate,
          overtime_rate: newRates.overtime_rate,
          meal_allowance: newRates.meal_allowance,
          transport_allowance: newRates.transport_allowance,
          other_allowances: newRates.other_allowances,
          default_deductions: totalDeductions,
          ...deductionsSnapshot,
          updated_at: now,
        })
        .eq('id', employee.id);
      if (empErr) throw new Error(empErr.message);

      await this.writeAuditLog(actor, 'SALARY_UPDATE', 'employee_salary_history', employee.id, { daily: employee.daily_rate, weekly: employee.weekly_rate ?? 0, monthly: employee.monthly_rate }, newRates, newRates.reason);
      return;
    }

    const db = loadLocalDb();
    db.salaryHistory.unshift({
      ...historyEntry,
      id: uid('sal'),
      changed_by_name: actor.full_name,
      created_at: now,
    });
    const idx = db.employees.findIndex((e) => e.id === employee.id);
    if (idx !== -1) {
      db.employees[idx] = {
        ...db.employees[idx],
        salary_type: newRates.salary_type,
        daily_rate: newRates.daily_rate,
        hourly_rate: newRates.hourly_rate,
        weekly_rate: weeklyRate,
        monthly_rate: newRates.monthly_rate,
        overtime_rate: newRates.overtime_rate,
        meal_allowance: newRates.meal_allowance,
        transport_allowance: newRates.transport_allowance,
        other_allowances: newRates.other_allowances,
        default_deductions: totalDeductions,
        ...deductionsSnapshot,
        updated_at: now,
      };
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'SALARY_UPDATE', 'employee_salary_history', employee.id, { daily: employee.daily_rate, weekly: employee.weekly_rate ?? 0, monthly: employee.monthly_rate }, newRates, newRates.reason);
  },

  // ==================== OVERTIME REQUEST & APPROVAL ====================
  async submitOvertimeRequest(
    actor: UserProfile,
    input: {
      attendance_id: string | null;
      employee_id: string;
      work_date: string;
      scheduled_time_in: string | null;
      actual_time_in: string | null;
      scheduled_time_out: string | null;
      actual_time_out: string | null;
      decision: 'YES' | 'NO';
      requested_hours: number;
      verified_hours: number;
      reason: string;
    }
  ): Promise<OvertimeRequest> {
    const now = new Date().toISOString();
    const status: OvertimeStatus = input.decision === 'YES' ? 'PENDING' : 'DECLINED_BY_EMPLOYEE';
    const record = {
      ...input,
      approved_hours: 0,
      overtime_rate_applied: 0,
      approved_amount: 0,
      status,
      admin_remarks: null,
      reviewed_by: null,
      reviewed_at: null,
    };

    if (supabase) {
      const { data: existing } = await supabase
        .from('overtime_requests')
        .select('id')
        .eq('employee_id', input.employee_id)
        .eq('work_date', input.work_date)
        .in('status', ['PENDING', 'APPROVED'])
        .maybeSingle();
      if (existing) {
        throw new Error('An active overtime request already exists for this attendance date.');
      }

      const { data, error } = await supabase.from('overtime_requests').insert(record).select('*').single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'SUBMIT_OVERTIME_REQUEST', 'overtime_requests', data.id, null, record);
      return data as OvertimeRequest;
    }

    const db = loadLocalDb();
    const dup = db.overtimeRequests.find(
      (o) => o.employee_id === input.employee_id && o.work_date === input.work_date && (o.status === 'PENDING' || o.status === 'APPROVED')
    );
    if (dup) {
      throw new Error('An active overtime request already exists for this attendance date.');
    }
    const created: OvertimeRequest = { ...record, id: uid('ot'), created_at: now };
    db.overtimeRequests.unshift(created);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'SUBMIT_OVERTIME_REQUEST', 'overtime_requests', created.id, null, record);
    return created;
  },

  async reviewOvertimeRequest(
    actor: UserProfile,
    request: OvertimeRequest,
    decision: 'APPROVED' | 'REJECTED',
    approvedHours: number,
    overtimeRateApplied: number,
    remarks: string
  ): Promise<void> {
    const now = new Date().toISOString();
    const approvedAmount = decision === 'APPROVED' ? Number((approvedHours * overtimeRateApplied).toFixed(2)) : 0;

    if (supabase) {
      const { error } = await supabase
        .from('overtime_requests')
        .update({
          status: decision,
          approved_hours: decision === 'APPROVED' ? approvedHours : 0,
          overtime_rate_applied: overtimeRateApplied,
          approved_amount: approvedAmount,
          admin_remarks: remarks,
          reviewed_by: actor.id,
          reviewed_at: now,
          updated_at: now,
        })
        .eq('id', request.id);
      if (error) throw new Error(error.message);

      if (decision === 'APPROVED' && request.attendance_id) {
        await supabase
          .from('attendance')
          .update({ approved_overtime_hours: approvedHours, status: 'OVERTIME', updated_at: now })
          .eq('id', request.attendance_id);
      }
      await this.writeAuditLog(actor, `OVERTIME_${decision}`, 'overtime_requests', request.id, { status: request.status }, { decision, approvedHours, approvedAmount }, remarks);
      return;
    }

    const db = loadLocalDb();
    const idx = db.overtimeRequests.findIndex((o) => o.id === request.id);
    if (idx !== -1) {
      db.overtimeRequests[idx] = {
        ...db.overtimeRequests[idx],
        status: decision,
        approved_hours: decision === 'APPROVED' ? approvedHours : 0,
        overtime_rate_applied: overtimeRateApplied,
        approved_amount: approvedAmount,
        admin_remarks: remarks,
        reviewed_by: actor.id,
        reviewed_at: now,
      };
    }
    if (decision === 'APPROVED' && request.attendance_id) {
      const attIdx = db.attendance.findIndex((a) => a.id === request.attendance_id);
      if (attIdx !== -1) {
        db.attendance[attIdx].approved_overtime_hours = approvedHours;
        if (db.attendance[attIdx].late_minutes === 0) {
          db.attendance[attIdx].status = 'OVERTIME';
        }
        db.attendance[attIdx].paid_hours = Number((db.attendance[attIdx].regular_hours + approvedHours).toFixed(2));
      }
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, `OVERTIME_${decision}`, 'overtime_requests', request.id, { status: request.status }, { decision, approvedHours, approvedAmount }, remarks);
  },

  // ==================== ATTENDANCE CORRECTIONS ====================
  async correctAttendance(
    actor: UserProfile,
    attendance: AttendanceRecord,
    employee: Employee,
    schedule: Schedule,
    holiday: Holiday | null,
    correction: {
      actual_time_in: string | null;
      actual_time_out: string | null;
      status_override?: AttendanceRecord['status'];
      reason: string;
    }
  ): Promise<void> {
    const now = new Date().toISOString();
    const calc = calculateAttendanceMetrics({
      workDate: attendance.work_date,
      schedule,
      actualTimeIn: correction.actual_time_in,
      actualTimeOut: correction.actual_time_out,
      restDays: employee.rest_days,
      holiday,
      approvedOvertimeHours: attendance.approved_overtime_hours,
    });
    const finalStatus = correction.status_override ?? calc.status;

    const originalValues = {
      actual_time_in: attendance.actual_time_in,
      actual_time_out: attendance.actual_time_out,
      status: attendance.status,
      late_minutes: attendance.late_minutes,
      undertime_minutes: attendance.undertime_minutes,
    };
    const correctedValues = {
      actual_time_in: correction.actual_time_in,
      actual_time_out: correction.actual_time_out,
      status: finalStatus,
      late_minutes: calc.lateMinutes,
      undertime_minutes: calc.undertimeMinutes,
    };

    if (supabase) {
      await supabase.from('attendance_corrections').insert({
        attendance_id: attendance.id,
        employee_id: employee.id,
        work_date: attendance.work_date,
        original_values: originalValues,
        corrected_values: correctedValues,
        reason: correction.reason,
        corrected_by: actor.id,
      });

      const { error } = await supabase
        .from('attendance')
        .update({
          actual_time_in: correction.actual_time_in,
          actual_time_out: correction.actual_time_out,
          early_arrival_minutes: calc.earlyArrivalMinutes,
          late_minutes: calc.lateMinutes,
          undertime_minutes: calc.undertimeMinutes,
          regular_hours: calc.regularHours,
          actual_hours: calc.actualHours,
          paid_hours: calc.paidHours,
          status: finalStatus,
          is_corrected: true,
          updated_at: now,
        })
        .eq('id', attendance.id);
      if (error) throw new Error(error.message);

      await this.writeAuditLog(actor, 'ATTENDANCE_CORRECTION', 'attendance', attendance.id, originalValues, correctedValues, correction.reason);
      return;
    }

    const db = loadLocalDb();
    db.corrections.unshift({
      id: uid('cor'),
      attendance_id: attendance.id,
      employee_id: employee.id,
      work_date: attendance.work_date,
      original_values: originalValues,
      corrected_values: correctedValues,
      reason: correction.reason,
      corrected_by: actor.id,
      corrected_by_name: actor.full_name,
      created_at: now,
    });
    const idx = db.attendance.findIndex((a) => a.id === attendance.id);
    if (idx !== -1) {
      db.attendance[idx] = {
        ...db.attendance[idx],
        actual_time_in: correction.actual_time_in,
        actual_time_out: correction.actual_time_out,
        early_arrival_minutes: calc.earlyArrivalMinutes,
        late_minutes: calc.lateMinutes,
        undertime_minutes: calc.undertimeMinutes,
        regular_hours: calc.regularHours,
        actual_hours: calc.actualHours,
        paid_hours: calc.paidHours,
        status: finalStatus,
        is_corrected: true,
        updated_at: now,
      };
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'ATTENDANCE_CORRECTION', 'attendance', attendance.id, originalValues, correctedValues, correction.reason);
  },

  // ==================== HOLIDAYS ====================
  async saveHoliday(actor: UserProfile, input: Omit<Holiday, 'id' | 'created_at'>): Promise<Holiday> {
    const now = new Date().toISOString();
    if (supabase) {
      const { data, error } = await supabase.from('holidays').insert({ ...input, created_by: actor.id }).select('*').single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'ADD_HOLIDAY', 'holidays', data.id, null, input);
      return data as Holiday;
    }
    const db = loadLocalDb();
    const created: Holiday = { ...input, id: uid('hol'), created_at: now };
    db.holidays.push(created);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'ADD_HOLIDAY', 'holidays', created.id, null, input);
    return created;
  },

  async deleteHoliday(actor: UserProfile, holidayId: string): Promise<void> {
    if (supabase) {
      const { error } = await supabase.from('holidays').delete().eq('id', holidayId);
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'DELETE_HOLIDAY', 'holidays', holidayId, null, null);
      return;
    }
    const db = loadLocalDb();
    db.holidays = db.holidays.filter((h) => h.id !== holidayId);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'DELETE_HOLIDAY', 'holidays', holidayId, null, null);
  },

  // ==================== LEAVE REQUESTS ====================
  async submitLeaveRequest(
    actor: UserProfile,
    input: Omit<LeaveRequest, 'id' | 'status' | 'admin_remarks' | 'reviewed_by' | 'reviewed_at' | 'created_at'>
  ): Promise<LeaveRequest> {
    const now = new Date().toISOString();
    if (supabase) {
      const { data, error } = await supabase
        .from('leave_requests')
        .insert({ ...input, status: 'PENDING' })
        .select('*')
        .single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'SUBMIT_LEAVE', 'leave_requests', data.id, null, input);
      return data as LeaveRequest;
    }
    const db = loadLocalDb();
    const created: LeaveRequest = {
      ...input,
      id: uid('lv'),
      status: 'PENDING',
      admin_remarks: null,
      reviewed_by: null,
      reviewed_at: null,
      created_at: now,
    };
    db.leaveRequests.unshift(created);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'SUBMIT_LEAVE', 'leave_requests', created.id, null, input);
    return created;
  },

  async reviewLeaveRequest(
    actor: UserProfile,
    leaveId: string,
    decision: 'APPROVED' | 'REJECTED',
    remarks: string
  ): Promise<void> {
    const now = new Date().toISOString();
    if (supabase) {
      const { error } = await supabase
        .from('leave_requests')
        .update({ status: decision, admin_remarks: remarks, reviewed_by: actor.id, reviewed_at: now })
        .eq('id', leaveId);
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, `LEAVE_${decision}`, 'leave_requests', leaveId, null, { decision, remarks });
      return;
    }
    const db = loadLocalDb();
    const idx = db.leaveRequests.findIndex((l) => l.id === leaveId);
    if (idx !== -1) {
      db.leaveRequests[idx] = {
        ...db.leaveRequests[idx],
        status: decision,
        admin_remarks: remarks,
        reviewed_by: actor.id,
        reviewed_at: now,
      };
      saveLocalDb(db);
    }
    await this.writeAuditLog(actor, `LEAVE_${decision}`, 'leave_requests', leaveId, null, { decision, remarks });
  },

  // ==================== PAYROLL GENERATION, WORKFLOW & ADJUSTMENTS ====================
  async generatePayrollPeriod(
    actor: UserProfile,
    input: { period_name: string; start_date: string; end_date: string; pay_date: string; payroll_schedule: string },
    state: Pick<AppDatabaseState, 'employees' | 'schedules' | 'attendance' | 'overtimeRequests' | 'leaveRequests' | 'holidays' | 'companySettings'>
  ): Promise<{ period: PayrollPeriod; records: PayrollRecord[] }> {
    const now = new Date().toISOString();
    const periodId = uid('pp');
    const period: PayrollPeriod = {
      id: periodId,
      period_name: input.period_name,
      start_date: input.start_date,
      end_date: input.end_date,
      pay_date: input.pay_date,
      payroll_schedule: input.payroll_schedule,
      status: 'DRAFT',
      generated_by: actor.id,
      approved_by: null,
      finalized_by: null,
      finalized_at: null,
      paid_at: null,
      created_at: now,
    };

    const activeEmployees = state.employees.filter((e) => e.is_active);
    const computedRecords: PayrollRecord[] = activeEmployees.map((emp) => {
      const sched =
        state.schedules.find((s) => s.id === (emp.schedule_id ?? state.companySettings.default_schedule_id)) ??
        state.schedules[0];
      const empAtt = state.attendance.filter(
        (a) => a.employee_id === emp.id && a.work_date >= input.start_date && a.work_date <= input.end_date
      );
      const empOt = state.overtimeRequests.filter(
        (o) => o.employee_id === emp.id && o.work_date >= input.start_date && o.work_date <= input.end_date
      );
      const empLeave = state.leaveRequests.filter((l) => l.employee_id === emp.id);

      const computed = computeEmployeePayroll({
        payrollPeriodId: periodId,
        startDate: input.start_date,
        endDate: input.end_date,
        employee: emp,
        schedule: sched,
        attendances: empAtt,
        overtimeRequests: empOt,
        leaveRequests: empLeave,
        holidays: state.holidays,
        multipliers: state.companySettings.multipliers,
      });

      return {
        ...computed,
        id: uid('pr'),
        created_at: now,
        updated_at: now,
      };
    });

    if (supabase) {
      const { data: savedPeriod, error: pErr } = await supabase
        .from('payroll_periods')
        .insert({
          period_name: period.period_name,
          start_date: period.start_date,
          end_date: period.end_date,
          pay_date: period.pay_date,
          payroll_schedule: period.payroll_schedule,
          status: 'DRAFT',
          generated_by: actor.id,
        })
        .select('*')
        .single();
      if (pErr) throw new Error(pErr.message);

      const recordsToInsert = computedRecords.map(({ id: _id, created_at: _c, updated_at: _u, ...r }) => {
        void _id;
        void _c;
        void _u;
        return { ...r, payroll_period_id: savedPeriod.id };
      });
      const { data: savedRecs, error: rErr } = await supabase.from('payroll_records').insert(recordsToInsert).select('*');
      if (rErr) throw new Error(rErr.message);

      await this.writeAuditLog(actor, 'GENERATE_PAYROLL', 'payroll_periods', savedPeriod.id, null, { period_name: period.period_name, count: savedRecs?.length ?? 0 });
      return { period: savedPeriod as PayrollPeriod, records: (savedRecs as PayrollRecord[]) ?? [] };
    }

    const db = loadLocalDb();
    db.payrollPeriods.unshift(period);
    db.payrollRecords.unshift(...computedRecords);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'GENERATE_PAYROLL', 'payroll_periods', period.id, null, { period_name: period.period_name, count: computedRecords.length });
    return { period, records: computedRecords };
  },

  async updatePayrollPeriodStatus(
    actor: UserProfile,
    period: PayrollPeriod,
    nextStatus: PayrollPeriod['status']
  ): Promise<void> {
    const now = new Date().toISOString();
    const lockRecords = nextStatus === 'FINALIZED' || nextStatus === 'PAID';

    if (supabase) {
      const { error } = await supabase
        .from('payroll_periods')
        .update({
          status: nextStatus,
          approved_by: nextStatus === 'APPROVED' ? actor.id : period.approved_by,
          finalized_by: nextStatus === 'FINALIZED' ? actor.id : period.finalized_by,
          finalized_at: nextStatus === 'FINALIZED' ? now : period.finalized_at,
          paid_at: nextStatus === 'PAID' ? now : period.paid_at,
        })
        .eq('id', period.id);
      if (error) throw new Error(error.message);

      if (lockRecords) {
        await supabase.from('payroll_records').update({ is_locked: true, updated_at: now }).eq('payroll_period_id', period.id);
      }
      await this.writeAuditLog(actor, `PAYROLL_${nextStatus}`, 'payroll_periods', period.id, { status: period.status }, { status: nextStatus });
      return;
    }

    const db = loadLocalDb();
    const pIdx = db.payrollPeriods.findIndex((p) => p.id === period.id);
    if (pIdx !== -1) {
      db.payrollPeriods[pIdx] = {
        ...db.payrollPeriods[pIdx],
        status: nextStatus,
        approved_by: nextStatus === 'APPROVED' ? actor.id : period.approved_by,
        finalized_by: nextStatus === 'FINALIZED' ? actor.id : period.finalized_by,
        finalized_at: nextStatus === 'FINALIZED' ? now : period.finalized_at,
        paid_at: nextStatus === 'PAID' ? now : period.paid_at,
      };
    }
    if (lockRecords) {
      db.payrollRecords = db.payrollRecords.map((r) =>
        r.payroll_period_id === period.id ? { ...r, is_locked: true, updated_at: now } : r
      );
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, `PAYROLL_${nextStatus}`, 'payroll_periods', period.id, { status: period.status }, { status: nextStatus });
  },

  async addPayrollAdjustment(
    actor: UserProfile,
    record: PayrollRecord,
    adjustment: { adjustment_type: 'ADDITION' | 'DEDUCTION'; category: string; amount: number; reason: string }
  ): Promise<void> {
    if (record.is_locked) {
      throw new Error('This payroll record is finalized and locked. Create a new adjustment period for corrections.');
    }
    const delta = adjustment.adjustment_type === 'ADDITION' ? adjustment.amount : -adjustment.amount;
    const newAdjTotal = Number((record.adjustments_total + delta).toFixed(2));
    const newGross = Number((record.gross_pay + (delta > 0 ? delta : 0)).toFixed(2));
    const newNet = Number(Math.max(0, record.net_pay + delta).toFixed(2));
    const now = new Date().toISOString();

    if (supabase) {
      await supabase.from('payroll_adjustments').insert({
        payroll_record_id: record.id,
        payroll_period_id: record.payroll_period_id,
        employee_id: record.employee_id,
        ...adjustment,
        created_by: actor.id,
      });
      await supabase
        .from('payroll_records')
        .update({ adjustments_total: newAdjTotal, gross_pay: newGross, net_pay: newNet, updated_at: now })
        .eq('id', record.id);
      await this.writeAuditLog(actor, 'PAYROLL_ADJUSTMENT', 'payroll_records', record.id, { net_pay: record.net_pay }, { net_pay: newNet, adjustment }, adjustment.reason);
      return;
    }

    const db = loadLocalDb();
    db.payrollAdjustments.unshift({
      id: uid('adj'),
      payroll_record_id: record.id,
      payroll_period_id: record.payroll_period_id,
      employee_id: record.employee_id,
      ...adjustment,
      created_by: actor.id,
      created_at: now,
    });
    const rIdx = db.payrollRecords.findIndex((r) => r.id === record.id);
    if (rIdx !== -1) {
      db.payrollRecords[rIdx] = {
        ...db.payrollRecords[rIdx],
        adjustments_total: newAdjTotal,
        gross_pay: newGross,
        net_pay: newNet,
        updated_at: now,
      };
    }
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'PAYROLL_ADJUSTMENT', 'payroll_records', record.id, { net_pay: record.net_pay }, { net_pay: newNet, adjustment }, adjustment.reason);
  },

  // ==================== COMPANY SETTINGS & SCHEDULES ====================
  async updateCompanySettings(actor: UserProfile, settings: CompanySettings): Promise<CompanySettings> {
    if (supabase) {
      const { data, error } = await supabase
        .from('company_settings')
        .update({ ...settings, updated_at: new Date().toISOString() })
        .eq('id', settings.id)
        .select('*')
        .single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'UPDATE_COMPANY_SETTINGS', 'company_settings', settings.id, null, { company_name: settings.company_name });
      return data as CompanySettings;
    }
    const db = loadLocalDb();
    db.companySettings = settings;
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'UPDATE_COMPANY_SETTINGS', 'company_settings', settings.id, null, { company_name: settings.company_name });
    return settings;
  },

  async createSchedule(actor: UserProfile, input: Omit<Schedule, 'id'>): Promise<Schedule> {
    if (supabase) {
      const { data, error } = await supabase.from('schedules').insert(input).select('*').single();
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'CREATE_SCHEDULE', 'schedules', data.id, null, input);
      return data as Schedule;
    }
    const db = loadLocalDb();
    const created: Schedule = { ...input, id: uid('sch') };
    db.schedules.push(created);
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'CREATE_SCHEDULE', 'schedules', created.id, null, input);
    return created;
  },

  // ==================== USER ACCOUNTS (SUPER ADMIN) ====================
  async createUserAccount(
    actor: UserProfile,
    input: {
      email: string;
      password: string;
      full_name: string;
      role: UserRole;
      employee_id: string | null;
      employee_number: string | null;
      department: string | null;
      position: string | null;
      phone: string | null;
      permissions: UserProfile['permissions'];
    }
  ): Promise<void> {
    if (supabase) {
      const { data, error } = await supabase.functions.invoke('provision-super-admin', {
        body: { mode: 'CREATE_USER', ...input },
      });
      if (error || data?.error) throw new Error(error?.message || data?.error || 'Failed to create user account.');
      return;
    }

    const db = loadLocalDb();
    const email = input.email.trim().toLowerCase();
    if (db.profiles.some((p) => p.email.toLowerCase() === email)) {
      throw new Error('A user with that email already exists.');
    }
    const now = new Date().toISOString();
    const newProfile: UserProfile = {
      id: uid('usr'),
      email,
      full_name: input.full_name,
      avatar_url: null,
      phone: input.phone,
      address: null,
      department: input.department,
      position: input.position,
      role: input.role,
      employee_id: input.employee_id,
      employee_number: input.employee_number,
      permissions: input.permissions,
      is_active: true,
      created_at: now,
      updated_at: now,
    };
    db.profiles.unshift(newProfile);
    db.localPasswords[email] = input.password;
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'CREATE_USER_ACCOUNT', 'profiles', newProfile.id, null, { email, role: input.role });
  },

  async updateUserAccount(
    actor: UserProfile,
    userId: string,
    updates: Partial<Pick<UserProfile, 'role' | 'permissions' | 'is_active' | 'employee_id' | 'employee_number'>>
  ): Promise<void> {
    if (actor.id === userId && updates.role && updates.role !== actor.role) {
      throw new Error('Administrators cannot change their own role.');
    }
    const now = new Date().toISOString();
    if (supabase) {
      const { error } = await supabase
        .from('profiles')
        .update({ ...updates, updated_at: now })
        .eq('id', userId);
      if (error) throw new Error(error.message);
      await this.writeAuditLog(actor, 'UPDATE_USER_ACCOUNT', 'profiles', userId, null, updates);
      return;
    }
    const db = loadLocalDb();
    const idx = db.profiles.findIndex((p) => p.id === userId);
    if (idx !== -1) {
      db.profiles[idx] = { ...db.profiles[idx], ...updates, updated_at: now };
      saveLocalDb(db);
    }
    await this.writeAuditLog(actor, 'UPDATE_USER_ACCOUNT', 'profiles', userId, null, updates);
  },

  // ==================== OPTIONAL INTEGRATIONS QUEUE ====================
  async queueGoogleSheetsSync(actor: UserProfile, tab: string, recordType: string, recordId: string, payload: Record<string, unknown>) {
    const key = `${tab}:${recordType}:${recordId}:${Date.now()}`;
    if (supabase) {
      await supabase.from('integration_sync_queue').insert({
        provider: 'GOOGLE_SHEETS',
        sheet_tab: tab,
        record_type: recordType,
        record_id: recordId,
        idempotency_key: key,
        payload,
        status: 'PENDING',
      });
      await supabase.functions.invoke('sync-google-sheets', { body: { trigger: 'manual' } }).catch(() => null);
      return;
    }
    const db = loadLocalDb();
    db.syncQueue.unshift({
      id: uid('sync'),
      provider: 'GOOGLE_SHEETS',
      sheet_tab: tab,
      record_type: recordType,
      record_id: recordId,
      idempotency_key: key,
      payload,
      status: 'FAILED',
      retry_count: 1,
      last_error: 'Google Sheets credentials not configured (Supabase records remain intact).',
      synced_at: null,
      created_at: new Date().toISOString(),
    });
    saveLocalDb(db);
    await this.writeAuditLog(actor, 'QUEUE_SHEETS_SYNC', 'integration_sync_queue', recordId, null, { tab });
  },
};
