import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
  LayoutDashboard,
  Clock,
  MonitorPlay,
  UserPlus,
  Users,
  CreditCard,
  FileBarChart,
  DollarSign,
  Wallet,
  CheckSquare,
  Calendar,
  Wrench,
  CalendarDays,
  UserCog,
  Share2,
  ClipboardList,
  Settings,
  LogOut,
  Menu,
  X,
  User,
  FileText,
} from 'lucide-react';
import { ToastStack, type ToastMessage } from './components/ui/Common';
import { supabase } from './lib/supabase/client';
import { dataService, type AppDatabaseState } from './services/dataService';
import { LoginPage } from './features/auth/LoginPage';
import { DashboardPage } from './features/dashboard/DashboardPage';
import { AttendanceTerminalPage } from './features/terminal/AttendanceTerminalPage';
import { AttendanceKioskPage } from './features/terminal/AttendanceKioskPage';
import { RegisterEmployeePage } from './features/employees/RegisterEmployeePage';
import { EmployeesPage } from './features/employees/EmployeesPage';
import { EmployeeIdCardPage } from './features/employees/EmployeeIdCardPage';
import { ReportsPage } from './features/reports/ReportsPage';
import { SalaryManagementPage } from './features/salary/SalaryManagementPage';
import { PayrollPage } from './features/payroll/PayrollPage';
import { PayslipsPage } from './features/payroll/PayslipsPage';
import { MyOvertimePage, OvertimeApprovalPage } from './features/overtime/OvertimePages';
import { HolidaysPage } from './features/holidays/HolidaysPage';
import { AttendanceCorrectionsPage, LeaveManagementPage } from './features/operations/LeaveAndCorrectionsPages';
import {
  AuditLogsPage,
  CompanySettingsPage,
  IntegrationsPage,
  UserAccountsPage,
} from './features/admin/AdminPages';
import {
  MyAttendancePage,
  MyProfilePage,
  MyTimeRecordsPage,
} from './features/employee-self/EmployeeSelfServicePages';
import type { UserProfile } from './types/database';

type RouteKey =
  | 'dashboard'
  | 'terminal'
  | 'kiosk'
  | 'register_employee'
  | 'employees'
  | 'id_cards'
  | 'monitoring'
  | 'reports_daily'
  | 'reports_weekly'
  | 'reports_monthly'
  | 'salary'
  | 'payroll'
  | 'payslips'
  | 'overtime_approval'
  | 'holidays'
  | 'corrections'
  | 'leave'
  | 'users'
  | 'integrations'
  | 'audit'
  | 'settings'
  | 'my_attendance'
  | 'my_time_records'
  | 'my_overtime'
  | 'my_payslips'
  | 'my_profile';

interface NavItem {
  key: RouteKey;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}

export default function App() {
  const [authReady, setAuthReady] = useState(false);
  const [actor, setActor] = useState<UserProfile | null>(null);
  const [standaloneKiosk, setStandaloneKiosk] = useState(false);
  const [activeRoute, setActiveRoute] = useState<RouteKey>('dashboard');
  const [selectedIdCardEmpId, setSelectedIdCardEmpId] = useState<string | null>(null);
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [dbState, setDbState] = useState<Omit<AppDatabaseState, 'localPasswords'> | null>(null);

  const notify = useCallback((type: ToastMessage['type'], title: string, description?: string) => {
    const id = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, type, title, description }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4200);
  }, []);

  const loadData = useCallback(async (user: UserProfile) => {
    try {
      const state = await dataService.loadWorkspaceData(user);
      setDbState(state);
    } catch (err) {
      notify('error', 'Failed to load workspace data', (err as Error).message);
    }
  }, [notify]);

  useEffect(() => {
    let mounted = true;
    dataService
      .getCurrentProfile()
      .then(async (profile) => {
        if (!mounted) return;
        setActor(profile);
        if (profile) {
          setActiveRoute(profile.role === 'EMPLOYEE' ? 'my_attendance' : 'dashboard');
          await loadData(profile);
        } else {
          // Load settings minimally if standalone kiosk is opened
          const fallback = await dataService.loadWorkspaceData({
            id: 'kiosk',
            email: '',
            full_name: 'Kiosk',
            avatar_url: null,
            phone: null,
            address: null,
            department: null,
            position: null,
            role: 'EMPLOYEE',
            employee_id: null,
            employee_number: null,
            permissions: {
              can_edit_salary: false,
              can_manage_payroll: false,
              can_manage_holidays: false,
              can_view_reports: false,
            },
            is_active: true,
            created_at: '',
            updated_at: '',
          }).catch(() => null);
          if (mounted && fallback) setDbState(fallback);
        }
        setAuthReady(true);
      })
      .catch(() => setAuthReady(true));

    return () => {
      mounted = false;
    };
  }, [loadData]);

  // Sync Light / Dark / Colorful theme from Company Settings
  useEffect(() => {
    const activeTheme = dbState?.companySettings?.theme ?? 'light';
    document.documentElement.classList.toggle('dark', activeTheme === 'dark');
    document.documentElement.classList.toggle('colorful', activeTheme === 'colorful');
  }, [dbState?.companySettings?.theme]);

  // Real-time Supabase listener for attendance updates
  useEffect(() => {
    const client = supabase;
    if (!client || !actor) return;
    const channel = client
      .channel('attendance-live')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'attendance' }, () => {
        loadData(actor);
      })
      .subscribe();
    return () => {
      client.removeChannel(channel);
    };
  }, [actor, loadData]);

  const navItems = useMemo<NavItem[]>(() => {
    if (!actor) return [];
    if (actor.role === 'SUPER_ADMIN') {
      return [
        { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { key: 'terminal', label: 'Employee # Terminal', icon: Clock },
        { key: 'kiosk', label: 'Attendance Kiosk', icon: MonitorPlay },
        { key: 'register_employee', label: 'Register Employee', icon: UserPlus },
        { key: 'employees', label: 'Employee Management', icon: Users },
        { key: 'id_cards', label: 'Employee ID Cards', icon: CreditCard },
        { key: 'monitoring', label: 'Attendance Monitoring', icon: LayoutDashboard },
        { key: 'reports_daily', label: 'Daily Reports', icon: FileBarChart },
        { key: 'reports_weekly', label: 'Weekly Reports', icon: FileBarChart },
        { key: 'reports_monthly', label: 'Monthly Reports', icon: FileBarChart },
        { key: 'salary', label: 'Salary Management', icon: DollarSign },
        { key: 'payroll', label: 'Payroll Management', icon: Wallet },
        { key: 'payslips', label: 'Payslips & Mass Print', icon: FileText },
        { key: 'overtime_approval', label: 'Overtime Approval', icon: CheckSquare },
        { key: 'holidays', label: 'Holiday & Rest Days', icon: Calendar },
        { key: 'corrections', label: 'Attendance Corrections', icon: Wrench },
        { key: 'leave', label: 'Leave Management', icon: CalendarDays },
        { key: 'users', label: 'User Accounts', icon: UserCog },
        { key: 'integrations', label: 'Integrations', icon: Share2 },
        { key: 'audit', label: 'Audit Logs', icon: ClipboardList },
        { key: 'settings', label: 'Company Settings', icon: Settings },
      ];
    }
    if (actor.role === 'ADMIN') {
      const items: NavItem[] = [
        { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { key: 'terminal', label: 'Employee # Terminal', icon: Clock },
        { key: 'kiosk', label: 'Attendance Kiosk', icon: MonitorPlay },
        { key: 'employees', label: 'Employee Management', icon: Users },
        { key: 'monitoring', label: 'Attendance Monitoring', icon: LayoutDashboard },
        { key: 'corrections', label: 'Attendance Corrections', icon: Wrench },
        { key: 'overtime_approval', label: 'Overtime Approval', icon: CheckSquare },
        { key: 'reports_daily', label: 'Reports', icon: FileBarChart },
      ];
      if (actor.permissions.can_manage_holidays) {
        items.push({ key: 'holidays', label: 'Holiday Management', icon: Calendar });
      }
      if (actor.permissions.can_edit_salary) {
        items.push({ key: 'salary', label: 'Salary Management', icon: DollarSign });
      }
      if (actor.permissions.can_manage_payroll) {
        items.push({ key: 'payroll', label: 'Payroll', icon: Wallet });
        items.push({ key: 'payslips', label: 'Payslips & Mass Print', icon: FileText });
      }
      return items;
    }
    if (actor.role === 'HR') {
      const items: NavItem[] = [
        { key: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { key: 'employees', label: 'Employee Records', icon: Users },
        { key: 'monitoring', label: 'Attendance Monitoring', icon: LayoutDashboard },
        { key: 'leave', label: 'Leave Management', icon: CalendarDays },
        { key: 'reports_daily', label: 'Reports', icon: FileBarChart },
      ];
      if (actor.permissions.can_edit_salary) {
        items.push({ key: 'salary', label: 'Salary Management', icon: DollarSign });
      }
      if (actor.permissions.can_manage_payroll) {
        items.push({ key: 'payroll', label: 'Payroll', icon: Wallet });
      }
      return items;
    }
    return [
      { key: 'my_attendance', label: 'My Attendance', icon: LayoutDashboard },
      { key: 'my_time_records', label: 'My Time Records', icon: Clock },
      { key: 'my_overtime', label: 'My Overtime', icon: CheckSquare },
      { key: 'leave', label: 'Leave Requests', icon: CalendarDays },
      { key: 'my_payslips', label: 'My Payslips', icon: FileText },
      { key: 'my_profile', label: 'My Profile', icon: User },
    ];
  }, [actor]);

  // Enforce route permission boundaries
  const safeRoute = useMemo<RouteKey>(() => {
    if (navItems.some((n) => n.key === activeRoute)) return activeRoute;
    return navItems[0]?.key ?? 'dashboard';
  }, [navItems, activeRoute]);

  if (!authReady) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-500">
        Loading PayLedger PH...
      </div>
    );
  }

  // Standalone Kiosk or Kiosk Route (strictly isolated from admin/payroll/salary)
  if ((standaloneKiosk || (actor && safeRoute === 'kiosk')) && dbState) {
    return (
      <>
        <AttendanceKioskPage
          company={dbState.companySettings}
          onExitKiosk={() => {
            setStandaloneKiosk(false);
            if (actor) setActiveRoute('dashboard');
          }}
          onPunchRecorded={() => actor && loadData(actor)}
        />
        <ToastStack
          toasts={toasts}
          onDismiss={(id) => setToasts((p) => p.filter((x) => x.id !== id))}
        />
      </>
    );
  }

  if (!actor) {
    return (
      <>
        <LoginPage
          onSignedIn={async (profile) => {
            setActor(profile);
            setActiveRoute(profile.role === 'EMPLOYEE' ? 'my_attendance' : 'dashboard');
            await loadData(profile);
          }}
          onOpenKioskDirect={() => setStandaloneKiosk(true)}
        />
        <ToastStack
          toasts={toasts}
          onDismiss={(id) => setToasts((p) => p.filter((x) => x.id !== id))}
        />
      </>
    );
  }

  if (!dbState) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center text-sm text-slate-500">
        Synchronizing database records...
      </div>
    );
  }

  const currentEmployee = dbState.employees.find((e) => e.id === actor.employee_id) ?? null;
  const activeNavLabel = navItems.find((n) => n.key === safeRoute)?.label ?? 'Dashboard';

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 colorful:bg-transparent text-slate-900 dark:text-slate-100 flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:flex lg:w-64 lg:flex-col lg:fixed lg:inset-y-0 bg-white dark:bg-slate-900 colorful:bg-gradient-to-b colorful:from-indigo-700 colorful:via-purple-700 colorful:to-fuchsia-700 border-r border-slate-200 dark:border-slate-800 colorful:border-fuchsia-400/40 colorful:shadow-xl colorful:shadow-purple-900/20 no-print">
        <div className="h-14 px-5 flex items-center gap-2.5 border-b border-slate-200 dark:border-slate-800 colorful:border-white/20 shrink-0">
          <div className="w-7 h-7 rounded-md bg-blue-600 colorful:bg-gradient-to-br colorful:from-amber-300 colorful:via-pink-400 colorful:to-cyan-300 colorful:text-indigo-950 text-white font-bold text-xs flex items-center justify-center shadow-xs">
            PL
          </div>
          <span className="font-bold text-sm text-slate-900 dark:text-slate-100 colorful:text-white tracking-tight truncate">
            {dbState.companySettings.company_name}
          </span>
        </div>

        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-0.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const active = safeRoute === item.key;
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => setActiveRoute(item.key)}
                className={`w-full flex items-center gap-2.5 px-3 py-2 text-xs font-medium rounded-lg transition-all text-left ${
                  active
                    ? 'bg-blue-50 dark:bg-blue-950/60 colorful:bg-white/95 text-blue-700 dark:text-blue-300 colorful:text-indigo-700 colorful:shadow-md font-semibold'
                    : 'text-slate-600 dark:text-slate-400 colorful:text-indigo-100 hover:text-slate-900 dark:hover:text-slate-100 colorful:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800 colorful:hover:bg-white/15'
                }`}
              >
                <Icon
                  className={`w-4 h-4 shrink-0 ${
                    active
                      ? 'text-blue-600 dark:text-blue-400 colorful:text-fuchsia-600'
                      : 'text-slate-400 dark:text-slate-500 colorful:text-indigo-200'
                  }`}
                />
                <span className="truncate">{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="p-3 border-t border-slate-200 dark:border-slate-800 colorful:border-white/20 text-xs">
          <div className="px-2 py-1.5">
            <p className="font-semibold text-slate-900 dark:text-slate-100 colorful:text-white truncate">{actor.full_name}</p>
            <p className="text-slate-500 dark:text-slate-400 colorful:text-indigo-200 font-mono truncate">
              {actor.role} {actor.employee_number ? `· ${actor.employee_number}` : ''}
            </p>
          </div>
          <button
            type="button"
            onClick={async () => {
              await dataService.signOut();
              setActor(null);
            }}
            className="w-full mt-1 flex items-center gap-2 px-2.5 py-2 text-xs font-medium text-slate-600 dark:text-slate-300 colorful:text-rose-100 hover:text-rose-700 dark:hover:text-rose-400 colorful:hover:text-white hover:bg-rose-50 dark:hover:bg-rose-950/40 colorful:hover:bg-rose-500/40 rounded-lg"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-slate-900/40 dark:bg-black/60" onClick={() => setMobileNavOpen(false)} />
          <aside className="relative w-72 max-w-[80vw] bg-white dark:bg-slate-900 colorful:bg-gradient-to-b colorful:from-indigo-700 colorful:via-purple-700 colorful:to-fuchsia-700 h-full flex flex-col border-r border-slate-200 dark:border-slate-800 colorful:border-white/20 z-10">
            <div className="h-14 px-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-800 colorful:border-white/20">
              <span className="font-bold text-sm text-slate-900 dark:text-slate-100 colorful:text-white">PayLedger PH</span>
              <button
                type="button"
                onClick={() => setMobileNavOpen(false)}
                className="p-1 text-slate-500 dark:text-slate-400 colorful:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <nav className="flex-1 overflow-y-auto p-3 space-y-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                const active = safeRoute === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    onClick={() => {
                      setActiveRoute(item.key);
                      setMobileNavOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-xs font-medium rounded-lg ${
                      active
                        ? 'bg-blue-50 dark:bg-blue-950/60 colorful:bg-white/95 text-blue-700 dark:text-blue-300 colorful:text-indigo-700 font-semibold'
                        : 'text-slate-700 dark:text-slate-300 colorful:text-indigo-100'
                    }`}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="p-3 border-t border-slate-200 dark:border-slate-800 colorful:border-white/20">
              <button
                type="button"
                onClick={async () => {
                  await dataService.signOut();
                  setActor(null);
                }}
                className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-rose-700 dark:text-rose-400 colorful:text-rose-100"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content */}
      <div className="flex-1 lg:pl-64 flex flex-col min-w-0">
        <header className="h-14 bg-white dark:bg-slate-900 colorful:bg-gradient-to-r colorful:from-white/90 colorful:via-indigo-50/90 colorful:to-pink-50/90 colorful:backdrop-blur-md border-b border-slate-200 dark:border-slate-800 colorful:border-indigo-200/70 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 no-print">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileNavOpen(true)}
              className="lg:hidden p-1.5 text-slate-600 dark:text-slate-300 colorful:text-indigo-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
              aria-label="Open navigation"
            >
              <Menu className="w-5 h-5" />
            </button>
            <div className="text-xs text-slate-500 dark:text-slate-400 colorful:text-indigo-700/80 flex items-center gap-2 truncate">
              <span className="font-medium text-slate-900 dark:text-slate-100 colorful:text-indigo-950 truncate">{activeNavLabel}</span>
              <span aria-hidden="true">·</span>
              <span className="hidden sm:inline">
                {dataService.isLiveSupabase() ? 'Supabase PostgreSQL' : 'Local Preview Database'}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            {(actor.role === 'SUPER_ADMIN' || actor.role === 'ADMIN') && (
              <button
                type="button"
                onClick={() => setActiveRoute('kiosk')}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 dark:text-slate-200 colorful:text-white bg-white dark:bg-slate-800 colorful:bg-gradient-to-r colorful:from-indigo-600 colorful:via-purple-600 colorful:to-pink-600 border border-slate-200 dark:border-slate-700 colorful:border-transparent hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 colorful:shadow-md"
              >
                <MonitorPlay className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400 colorful:text-amber-200" />
                ATTENDANCE KIOSK
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-[1440px] w-full mx-auto">
          {(safeRoute === 'dashboard' || safeRoute === 'monitoring') && (
            <DashboardPage
              actor={actor}
              employees={dbState.employees}
              attendance={dbState.attendance}
              overtimeRequests={dbState.overtimeRequests}
              leaveRequests={dbState.leaveRequests}
              onOpenTerminal={() => setActiveRoute('terminal')}
            />
          )}

          {safeRoute === 'terminal' && (
            <AttendanceTerminalPage
              company={dbState.companySettings}
              employees={dbState.employees}
              onPunchRecorded={() => loadData(actor)}
            />
          )}

          {safeRoute === 'register_employee' && (
            <RegisterEmployeePage
              actor={actor}
              company={dbState.companySettings}
              employees={dbState.employees}
              schedules={dbState.schedules}
              onSuccess={() => {
                loadData(actor);
                setActiveRoute('employees');
              }}
              onNotify={notify}
            />
          )}

          {safeRoute === 'employees' && (
            <EmployeesPage
              actor={actor}
              employees={dbState.employees}
              schedules={dbState.schedules}
              onReload={() => loadData(actor)}
              onOpenIdCard={(empId) => {
                setSelectedIdCardEmpId(empId);
                setActiveRoute('id_cards');
              }}
              onOpenRegister={() => setActiveRoute('register_employee')}
              onNotify={notify}
            />
          )}

          {safeRoute === 'id_cards' && (
            <EmployeeIdCardPage
              actor={actor}
              company={dbState.companySettings}
              employees={dbState.employees}
              credentials={dbState.credentials}
              initialEmployeeId={selectedIdCardEmpId}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {(safeRoute === 'reports_daily' || safeRoute === 'reports_weekly' || safeRoute === 'reports_monthly') && (
            <ReportsPage
              key={safeRoute}
              actor={actor}
              employees={dbState.employees}
              attendance={dbState.attendance}
              leaveRequests={dbState.leaveRequests}
              holidays={dbState.holidays}
              initialMode={
                safeRoute === 'reports_weekly' ? 'WEEKLY' : safeRoute === 'reports_monthly' ? 'MONTHLY' : 'DAILY'
              }
            />
          )}

          {safeRoute === 'salary' && (
            <SalaryManagementPage
              actor={actor}
              employees={dbState.employees}
              salaryHistory={dbState.salaryHistory}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'payroll' && (
            <PayrollPage
              actor={actor}
              company={dbState.companySettings}
              employees={dbState.employees}
              schedules={dbState.schedules}
              attendance={dbState.attendance}
              overtimeRequests={dbState.overtimeRequests}
              leaveRequests={dbState.leaveRequests}
              holidays={dbState.holidays}
              payrollPeriods={dbState.payrollPeriods}
              payrollRecords={dbState.payrollRecords}
              onReload={() => loadData(actor)}
              onNotify={notify}
              onOpenPayslips={() => setActiveRoute('payslips')}
            />
          )}

          {(safeRoute === 'payslips' || safeRoute === 'my_payslips') && (
            <PayslipsPage
              actor={actor}
              company={dbState.companySettings}
              payrollPeriods={dbState.payrollPeriods}
              payrollRecords={dbState.payrollRecords}
            />
          )}

          {safeRoute === 'overtime_approval' && (
            <OvertimeApprovalPage
              actor={actor}
              employees={dbState.employees}
              overtimeRequests={dbState.overtimeRequests}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'holidays' && (
            <HolidaysPage
              actor={actor}
              company={dbState.companySettings}
              holidays={dbState.holidays}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'corrections' && (
            <AttendanceCorrectionsPage
              actor={actor}
              employees={dbState.employees}
              schedules={dbState.schedules}
              holidays={dbState.holidays}
              attendance={dbState.attendance}
              corrections={dbState.corrections}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'leave' && (
            <LeaveManagementPage
              actor={actor}
              employees={dbState.employees}
              leaveRequests={dbState.leaveRequests}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'users' && (
            <UserAccountsPage
              actor={actor}
              profiles={dbState.profiles}
              employees={dbState.employees}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'integrations' && (
            <IntegrationsPage
              actor={actor}
              syncQueue={dbState.syncQueue}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'audit' && <AuditLogsPage auditLogs={dbState.auditLogs} />}

          {safeRoute === 'settings' && (
            <CompanySettingsPage
              actor={actor}
              company={dbState.companySettings}
              schedules={dbState.schedules}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'my_attendance' && (
            <MyAttendancePage employee={currentEmployee} attendance={dbState.attendance} />
          )}

          {safeRoute === 'my_time_records' && (
            <MyTimeRecordsPage
              actor={actor}
              employee={currentEmployee}
              attendance={dbState.attendance}
              overtimeRequests={dbState.overtimeRequests}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'my_overtime' && (
            <MyOvertimePage
              actor={actor}
              employee={currentEmployee}
              attendance={dbState.attendance}
              overtimeRequests={dbState.overtimeRequests}
              onReload={() => loadData(actor)}
              onNotify={notify}
            />
          )}

          {safeRoute === 'my_profile' && (
            <MyProfilePage
              actor={actor}
              employee={currentEmployee}
              onProfileUpdated={(updated) => setActor(updated)}
              onNotify={notify}
            />
          )}
        </main>
      </div>

      <ToastStack
        toasts={toasts}
        onDismiss={(id) => setToasts((p) => p.filter((x) => x.id !== id))}
      />
    </div>
  );
}
